Copy both GoogleMapsExtras.jar and GoogleMapsExtras.xml to your b4a additional libraries folder.

(GoogleMapsExtras.html is for information/reference only).

IMPORTANT
=========
Please ensure that your b4a additional libraries folder contains the latest version of the Google Play services library (google-play-services.jar).
Run the Android SDK Manager utility and check whether or not you have the latest version, update if necessary and copy the latest version to your b4a additional libraries folder.
