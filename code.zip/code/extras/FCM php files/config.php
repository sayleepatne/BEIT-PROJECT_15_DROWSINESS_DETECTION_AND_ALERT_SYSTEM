<?php 
	define('DB_USERNAME','root');
	define('DB_PASSWORD','');
	define('DB_NAME','farmerdelivery');
	define('DB_HOST','localhost');
	
	//defined a new constant for firebase api key
	define('FIREBASE_API_KEY', 'AAAAADco8TE:APA91bE7PEwnYlmq_jOaG2tKXNfRMYYfgzxeKmkuF0pCqWEa0d19eQGB9dZINWAUGWcX6eOBqsMrPo4goJ1n5M7-RbIi6tsi_7QKrdDbQotycS9n6ENF7GEbCf_Fd-ViIVbOA4CTpIoA');