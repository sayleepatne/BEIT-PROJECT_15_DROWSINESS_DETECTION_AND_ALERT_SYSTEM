package com.mitguide.android;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class main_subs_0 {


public static RemoteObject  _activity_create(RemoteObject _firsttime) throws Exception{
try {
		Debug.PushSubsStack("Activity_Create (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,48);
if (RapidSub.canDelegate("activity_create")) { return com.mitguide.android.main.remoteMe.runUserSub(false, "main","activity_create", _firsttime);}
Debug.locals.put("FirstTime", _firsttime);
 BA.debugLineNum = 48;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
Debug.ShouldStop(32768);
 BA.debugLineNum = 49;BA.debugLine="Activity.LoadLayout(\"login\")";
Debug.ShouldStop(65536);
main.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(RemoteObject.createImmutable("login")),main.mostCurrent.activityBA);
 BA.debugLineNum = 50;BA.debugLine="d_mode = 0";
Debug.ShouldStop(131072);
main._d_mode = BA.numberCast(int.class, 0);
 BA.debugLineNum = 51;BA.debugLine="Label4.Visible = False";
Debug.ShouldStop(262144);
main.mostCurrent._label4.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 52;BA.debugLine="txtmobile.Visible = False";
Debug.ShouldStop(524288);
main.mostCurrent._txtmobile.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 53;BA.debugLine="If FirstTime Then";
Debug.ShouldStop(1048576);
if (_firsttime.<Boolean>get().booleanValue()) { 
 BA.debugLineNum = 54;BA.debugLine="SQL1.Initialize(File.DirDefaultExternal, \"test1.";
Debug.ShouldStop(2097152);
main._sql1.runVoidMethod ("Initialize",(Object)(main.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirDefaultExternal")),(Object)(BA.ObjectToString("test1.db")),(Object)(main.mostCurrent.__c.getField(true,"True")));
 };
 BA.debugLineNum = 56;BA.debugLine="CreateTables";
Debug.ShouldStop(8388608);
_createtables();
 BA.debugLineNum = 57;BA.debugLine="End Sub";
Debug.ShouldStop(16777216);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_pause(RemoteObject _userclosed) throws Exception{
try {
		Debug.PushSubsStack("Activity_Pause (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,129);
if (RapidSub.canDelegate("activity_pause")) { return com.mitguide.android.main.remoteMe.runUserSub(false, "main","activity_pause", _userclosed);}
Debug.locals.put("UserClosed", _userclosed);
 BA.debugLineNum = 129;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
Debug.ShouldStop(1);
 BA.debugLineNum = 131;BA.debugLine="End Sub";
Debug.ShouldStop(4);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_resume() throws Exception{
try {
		Debug.PushSubsStack("Activity_Resume (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,124);
if (RapidSub.canDelegate("activity_resume")) { return com.mitguide.android.main.remoteMe.runUserSub(false, "main","activity_resume");}
 BA.debugLineNum = 124;BA.debugLine="Sub Activity_Resume";
Debug.ShouldStop(134217728);
 BA.debugLineNum = 125;BA.debugLine="txtlogin.Text = \"\"";
Debug.ShouldStop(268435456);
main.mostCurrent._txtlogin.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 126;BA.debugLine="txtpassword.Text = \"\"";
Debug.ShouldStop(536870912);
main.mostCurrent._txtpassword.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 127;BA.debugLine="End Sub";
Debug.ShouldStop(1073741824);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _cmdcancel_click() throws Exception{
try {
		Debug.PushSubsStack("cmdcancel_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,215);
if (RapidSub.canDelegate("cmdcancel_click")) { return com.mitguide.android.main.remoteMe.runUserSub(false, "main","cmdcancel_click");}
 BA.debugLineNum = 215;BA.debugLine="Sub cmdcancel_Click";
Debug.ShouldStop(4194304);
 BA.debugLineNum = 219;BA.debugLine="If d_mode = 0 Then";
Debug.ShouldStop(67108864);
if (RemoteObject.solveBoolean("=",main._d_mode,BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 220;BA.debugLine="Activity.Finish";
Debug.ShouldStop(134217728);
main.mostCurrent._activity.runVoidMethod ("Finish");
 }else {
 BA.debugLineNum = 222;BA.debugLine="txtlogin.Text = \"\"";
Debug.ShouldStop(536870912);
main.mostCurrent._txtlogin.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 223;BA.debugLine="txtpassword.Text = \"\"";
Debug.ShouldStop(1073741824);
main.mostCurrent._txtpassword.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 224;BA.debugLine="txtmobile.Text = \"\"";
Debug.ShouldStop(-2147483648);
main.mostCurrent._txtmobile.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 225;BA.debugLine="d_mode = 0";
Debug.ShouldStop(1);
main._d_mode = BA.numberCast(int.class, 0);
 BA.debugLineNum = 226;BA.debugLine="Label4.Visible = False";
Debug.ShouldStop(2);
main.mostCurrent._label4.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 227;BA.debugLine="txtmobile.Visible = False";
Debug.ShouldStop(4);
main.mostCurrent._txtmobile.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 228;BA.debugLine="cmdlogin.Text = \"Login\"";
Debug.ShouldStop(8);
main.mostCurrent._cmdlogin.runMethod(true,"setText",BA.ObjectToCharSequence("Login"));
 BA.debugLineNum = 229;BA.debugLine="cmdcancel.Text = \"Cancel\"";
Debug.ShouldStop(16);
main.mostCurrent._cmdcancel.runMethod(true,"setText",BA.ObjectToCharSequence("Cancel"));
 BA.debugLineNum = 230;BA.debugLine="cmdforgot.Visible = True";
Debug.ShouldStop(32);
main.mostCurrent._cmdforgot.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 231;BA.debugLine="cmdregister.Visible = True";
Debug.ShouldStop(64);
main.mostCurrent._cmdregister.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 232;BA.debugLine="Label2.Visible = True";
Debug.ShouldStop(128);
main.mostCurrent._label2.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 233;BA.debugLine="txtlogin.Visible = True";
Debug.ShouldStop(256);
main.mostCurrent._txtlogin.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 234;BA.debugLine="cmdlogin.Visible = True";
Debug.ShouldStop(512);
main.mostCurrent._cmdlogin.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 235;BA.debugLine="Label3.Visible = True";
Debug.ShouldStop(1024);
main.mostCurrent._label3.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 236;BA.debugLine="txtpassword.Visible = True";
Debug.ShouldStop(2048);
main.mostCurrent._txtpassword.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 };
 BA.debugLineNum = 238;BA.debugLine="End Sub";
Debug.ShouldStop(8192);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _cmdcancel_longclick() throws Exception{
try {
		Debug.PushSubsStack("cmdcancel_LongClick (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,320);
if (RapidSub.canDelegate("cmdcancel_longclick")) { return com.mitguide.android.main.remoteMe.runUserSub(false, "main","cmdcancel_longclick");}
 BA.debugLineNum = 320;BA.debugLine="Sub cmdcancel_LongClick";
Debug.ShouldStop(-2147483648);
 BA.debugLineNum = 321;BA.debugLine="StartActivity(maps)";
Debug.ShouldStop(1);
main.mostCurrent.__c.runVoidMethod ("StartActivity",main.processBA,(Object)((main.mostCurrent._maps.getObject())));
 BA.debugLineNum = 322;BA.debugLine="End Sub";
Debug.ShouldStop(2);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _cmdforgot_click() throws Exception{
try {
		Debug.PushSubsStack("cmdforgot_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,257);
if (RapidSub.canDelegate("cmdforgot_click")) { return com.mitguide.android.main.remoteMe.runUserSub(false, "main","cmdforgot_click");}
 BA.debugLineNum = 257;BA.debugLine="Sub cmdforgot_Click";
Debug.ShouldStop(1);
 BA.debugLineNum = 258;BA.debugLine="If txtlogin.Text = \"\"  Then";
Debug.ShouldStop(2);
if (RemoteObject.solveBoolean("=",main.mostCurrent._txtlogin.runMethod(true,"getText"),BA.ObjectToString(""))) { 
 BA.debugLineNum = 259;BA.debugLine="Msgbox(\"Enter Valid Username\",\"Alert!!!\")";
Debug.ShouldStop(4);
main.mostCurrent.__c.runVoidMethodAndSync ("Msgbox",(Object)(BA.ObjectToCharSequence("Enter Valid Username")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("Alert!!!"))),main.mostCurrent.activityBA);
 }else {
 BA.debugLineNum = 262;BA.debugLine="LogTable1";
Debug.ShouldStop(32);
_logtable1();
 BA.debugLineNum = 263;BA.debugLine="If d_use = 0 Then";
Debug.ShouldStop(64);
if (RemoteObject.solveBoolean("=",main._d_use,BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 264;BA.debugLine="If txtlogin.Text = d_login Then";
Debug.ShouldStop(128);
if (RemoteObject.solveBoolean("=",main.mostCurrent._txtlogin.runMethod(true,"getText"),main._d_login)) { 
 BA.debugLineNum = 265;BA.debugLine="ran_no = Rnd(1000,9999)";
Debug.ShouldStop(256);
main._ran_no = main.mostCurrent.__c.runMethod(true,"Rnd",(Object)(BA.numberCast(int.class, 1000)),(Object)(BA.numberCast(int.class, 9999)));
 BA.debugLineNum = 266;BA.debugLine="Log(ran_no)";
Debug.ShouldStop(512);
main.mostCurrent.__c.runVoidMethod ("LogImpl","71114121",BA.NumberToString(main._ran_no),0);
 BA.debugLineNum = 267;BA.debugLine="Sms1.Send(d_mobile,\"OTP: \" & ran_no)";
Debug.ShouldStop(1024);
main._sms1.runVoidMethod ("Send",(Object)(main._d_mobile),(Object)(RemoteObject.concat(RemoteObject.createImmutable("OTP: "),main._ran_no)));
 BA.debugLineNum = 268;BA.debugLine="ToastMessageShow(\"OTP sent.\",False)";
Debug.ShouldStop(2048);
main.mostCurrent.__c.runVoidMethod ("ToastMessageShow",(Object)(BA.ObjectToCharSequence("OTP sent.")),(Object)(main.mostCurrent.__c.getField(true,"False")));
 BA.debugLineNum = 269;BA.debugLine="txtlogin.Text = \"\"";
Debug.ShouldStop(4096);
main.mostCurrent._txtlogin.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 270;BA.debugLine="txtpassword.Text = \"\"";
Debug.ShouldStop(8192);
main.mostCurrent._txtpassword.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 271;BA.debugLine="txtmobile.Text = \"\"";
Debug.ShouldStop(16384);
main.mostCurrent._txtmobile.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 272;BA.debugLine="Label2.Visible = False";
Debug.ShouldStop(32768);
main.mostCurrent._label2.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 273;BA.debugLine="txtlogin.Visible = False";
Debug.ShouldStop(65536);
main.mostCurrent._txtlogin.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 274;BA.debugLine="Label3.Visible = False";
Debug.ShouldStop(131072);
main.mostCurrent._label3.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 275;BA.debugLine="txtpassword.Visible = False";
Debug.ShouldStop(262144);
main.mostCurrent._txtpassword.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 276;BA.debugLine="cmdregister.Visible = False";
Debug.ShouldStop(524288);
main.mostCurrent._cmdregister.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 277;BA.debugLine="cmdforgot.Visible = False";
Debug.ShouldStop(1048576);
main.mostCurrent._cmdforgot.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 278;BA.debugLine="Label4.Visible = True";
Debug.ShouldStop(2097152);
main.mostCurrent._label4.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 279;BA.debugLine="txtmobile.Visible = True";
Debug.ShouldStop(4194304);
main.mostCurrent._txtmobile.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 280;BA.debugLine="Label4.Text = \"OTP:\"";
Debug.ShouldStop(8388608);
main.mostCurrent._label4.runMethod(true,"setText",BA.ObjectToCharSequence("OTP:"));
 BA.debugLineNum = 281;BA.debugLine="ToastMessageShow(\"Enter OTP\",False)";
Debug.ShouldStop(16777216);
main.mostCurrent.__c.runVoidMethod ("ToastMessageShow",(Object)(BA.ObjectToCharSequence("Enter OTP")),(Object)(main.mostCurrent.__c.getField(true,"False")));
 BA.debugLineNum = 282;BA.debugLine="d_mode = 2";
Debug.ShouldStop(33554432);
main._d_mode = BA.numberCast(int.class, 2);
 BA.debugLineNum = 283;BA.debugLine="cmdlogin.Text = \"Enter\"";
Debug.ShouldStop(67108864);
main.mostCurrent._cmdlogin.runMethod(true,"setText",BA.ObjectToCharSequence("Enter"));
 }else {
 BA.debugLineNum = 285;BA.debugLine="Msgbox 	(\"Login ID is Incorrect\",\"Alert!\")";
Debug.ShouldStop(268435456);
main.mostCurrent.__c.runVoidMethodAndSync ("Msgbox",(Object)(BA.ObjectToCharSequence("Login ID is Incorrect")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("Alert!"))),main.mostCurrent.activityBA);
 };
 };
 };
 BA.debugLineNum = 291;BA.debugLine="End Sub";
Debug.ShouldStop(4);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _cmdlogin_click() throws Exception{
try {
		Debug.PushSubsStack("cmdlogin_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,133);
if (RapidSub.canDelegate("cmdlogin_click")) { return com.mitguide.android.main.remoteMe.runUserSub(false, "main","cmdlogin_click");}
 BA.debugLineNum = 133;BA.debugLine="Sub cmdlogin_Click";
Debug.ShouldStop(16);
 BA.debugLineNum = 134;BA.debugLine="If d_mode = 0 Then";
Debug.ShouldStop(32);
if (RemoteObject.solveBoolean("=",main._d_mode,BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 135;BA.debugLine="LogTable1";
Debug.ShouldStop(64);
_logtable1();
 BA.debugLineNum = 136;BA.debugLine="Log (\"Login:\")";
Debug.ShouldStop(128);
main.mostCurrent.__c.runVoidMethod ("LogImpl","7917507",RemoteObject.createImmutable("Login:"),0);
 BA.debugLineNum = 137;BA.debugLine="Log (d_login)";
Debug.ShouldStop(256);
main.mostCurrent.__c.runVoidMethod ("LogImpl","7917508",main._d_login,0);
 BA.debugLineNum = 138;BA.debugLine="Log (\"Password:\")";
Debug.ShouldStop(512);
main.mostCurrent.__c.runVoidMethod ("LogImpl","7917509",RemoteObject.createImmutable("Password:"),0);
 BA.debugLineNum = 139;BA.debugLine="Log (d_pass)";
Debug.ShouldStop(1024);
main.mostCurrent.__c.runVoidMethod ("LogImpl","7917510",main._d_pass,0);
 BA.debugLineNum = 140;BA.debugLine="Log (\"Mobile:\")";
Debug.ShouldStop(2048);
main.mostCurrent.__c.runVoidMethod ("LogImpl","7917511",RemoteObject.createImmutable("Mobile:"),0);
 BA.debugLineNum = 141;BA.debugLine="Log (d_mobile)";
Debug.ShouldStop(4096);
main.mostCurrent.__c.runVoidMethod ("LogImpl","7917512",main._d_mobile,0);
 BA.debugLineNum = 142;BA.debugLine="If d_use = 0 Then";
Debug.ShouldStop(8192);
if (RemoteObject.solveBoolean("=",main._d_use,BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 143;BA.debugLine="If txtlogin.Text = d_login Then";
Debug.ShouldStop(16384);
if (RemoteObject.solveBoolean("=",main.mostCurrent._txtlogin.runMethod(true,"getText"),main._d_login)) { 
 BA.debugLineNum = 144;BA.debugLine="If txtpassword.Text = d_pass Then";
Debug.ShouldStop(32768);
if (RemoteObject.solveBoolean("=",main.mostCurrent._txtpassword.runMethod(true,"getText"),main._d_pass)) { 
 BA.debugLineNum = 145;BA.debugLine="maps.u_name = d_login";
Debug.ShouldStop(65536);
main.mostCurrent._maps._u_name /*RemoteObject*/  = main._d_login;
 BA.debugLineNum = 146;BA.debugLine="StartActivity(maps)";
Debug.ShouldStop(131072);
main.mostCurrent.__c.runVoidMethod ("StartActivity",main.processBA,(Object)((main.mostCurrent._maps.getObject())));
 }else {
 BA.debugLineNum = 148;BA.debugLine="Msgbox 	(\"Password Incorrect\",\"Alert!\")";
Debug.ShouldStop(524288);
main.mostCurrent.__c.runVoidMethodAndSync ("Msgbox",(Object)(BA.ObjectToCharSequence("Password Incorrect")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("Alert!"))),main.mostCurrent.activityBA);
 };
 }else {
 BA.debugLineNum = 151;BA.debugLine="Msgbox 	(\"Login ID is Incorrect\",\"Alert!\")";
Debug.ShouldStop(4194304);
main.mostCurrent.__c.runVoidMethodAndSync ("Msgbox",(Object)(BA.ObjectToCharSequence("Login ID is Incorrect")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("Alert!"))),main.mostCurrent.activityBA);
 };
 };
 }else 
{ BA.debugLineNum = 154;BA.debugLine="Else If d_mode = 1 Then";
Debug.ShouldStop(33554432);
if (RemoteObject.solveBoolean("=",main._d_mode,BA.numberCast(double.class, 1))) { 
 BA.debugLineNum = 155;BA.debugLine="If txtlogin.Text = \"\" Or txtpassword.Text = \"\" O";
Debug.ShouldStop(67108864);
if (RemoteObject.solveBoolean("=",main.mostCurrent._txtlogin.runMethod(true,"getText"),BA.ObjectToString("")) || RemoteObject.solveBoolean("=",main.mostCurrent._txtpassword.runMethod(true,"getText"),BA.ObjectToString("")) || RemoteObject.solveBoolean("=",main.mostCurrent._txtmobile.runMethod(true,"getText"),BA.ObjectToString(""))) { 
 BA.debugLineNum = 156;BA.debugLine="Msgbox(\"Enter Proper Details\",\"Alert!!!\")";
Debug.ShouldStop(134217728);
main.mostCurrent.__c.runVoidMethodAndSync ("Msgbox",(Object)(BA.ObjectToCharSequence("Enter Proper Details")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("Alert!!!"))),main.mostCurrent.activityBA);
 }else {
 BA.debugLineNum = 158;BA.debugLine="SQL1.ExecNonQuery(\"INSERT INTO table3 VALUES('\"";
Debug.ShouldStop(536870912);
main._sql1.runVoidMethod ("ExecNonQuery",(Object)(RemoteObject.concat(RemoteObject.createImmutable("INSERT INTO table3 VALUES('"),main.mostCurrent._txtlogin.runMethod(true,"getText"),RemoteObject.createImmutable("')"))));
 BA.debugLineNum = 159;BA.debugLine="SQL1.ExecNonQuery(\"INSERT INTO table4 VALUES('\"";
Debug.ShouldStop(1073741824);
main._sql1.runVoidMethod ("ExecNonQuery",(Object)(RemoteObject.concat(RemoteObject.createImmutable("INSERT INTO table4 VALUES('"),main.mostCurrent._txtpassword.runMethod(true,"getText"),RemoteObject.createImmutable("')"))));
 BA.debugLineNum = 160;BA.debugLine="SQL1.ExecNonQuery(\"INSERT INTO table5 VALUES('\"";
Debug.ShouldStop(-2147483648);
main._sql1.runVoidMethod ("ExecNonQuery",(Object)(RemoteObject.concat(RemoteObject.createImmutable("INSERT INTO table5 VALUES('"),main.mostCurrent._txtmobile.runMethod(true,"getText"),RemoteObject.createImmutable("')"))));
 BA.debugLineNum = 161;BA.debugLine="ToastMessageShow(\"Registration Completed.\",Fals";
Debug.ShouldStop(1);
main.mostCurrent.__c.runVoidMethod ("ToastMessageShow",(Object)(BA.ObjectToCharSequence("Registration Completed.")),(Object)(main.mostCurrent.__c.getField(true,"False")));
 BA.debugLineNum = 162;BA.debugLine="d_mode = 0";
Debug.ShouldStop(2);
main._d_mode = BA.numberCast(int.class, 0);
 BA.debugLineNum = 163;BA.debugLine="Label4.Visible = False";
Debug.ShouldStop(4);
main.mostCurrent._label4.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 164;BA.debugLine="txtmobile.Visible = False";
Debug.ShouldStop(8);
main.mostCurrent._txtmobile.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 165;BA.debugLine="cmdlogin.Text = \"Login\"";
Debug.ShouldStop(16);
main.mostCurrent._cmdlogin.runMethod(true,"setText",BA.ObjectToCharSequence("Login"));
 BA.debugLineNum = 166;BA.debugLine="cmdcancel.Text = \"Cancel\"";
Debug.ShouldStop(32);
main.mostCurrent._cmdcancel.runMethod(true,"setText",BA.ObjectToCharSequence("Cancel"));
 BA.debugLineNum = 167;BA.debugLine="cmdforgot.Visible = True";
Debug.ShouldStop(64);
main.mostCurrent._cmdforgot.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 168;BA.debugLine="cmdregister.Visible = True";
Debug.ShouldStop(128);
main.mostCurrent._cmdregister.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 169;BA.debugLine="txtlogin.Text = \"\"";
Debug.ShouldStop(256);
main.mostCurrent._txtlogin.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 170;BA.debugLine="txtpassword.Text = \"\"";
Debug.ShouldStop(512);
main.mostCurrent._txtpassword.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 171;BA.debugLine="txtmobile.Text = \"\"";
Debug.ShouldStop(1024);
main.mostCurrent._txtmobile.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 };
 }else 
{ BA.debugLineNum = 173;BA.debugLine="Else If d_mode = 2 Then";
Debug.ShouldStop(4096);
if (RemoteObject.solveBoolean("=",main._d_mode,BA.numberCast(double.class, 2))) { 
 BA.debugLineNum = 174;BA.debugLine="If txtmobile.Text = ran_no Then";
Debug.ShouldStop(8192);
if (RemoteObject.solveBoolean("=",main.mostCurrent._txtmobile.runMethod(true,"getText"),BA.NumberToString(main._ran_no))) { 
 BA.debugLineNum = 175;BA.debugLine="d_mode = 3";
Debug.ShouldStop(16384);
main._d_mode = BA.numberCast(int.class, 3);
 BA.debugLineNum = 176;BA.debugLine="txtlogin.Text = \"\"";
Debug.ShouldStop(32768);
main.mostCurrent._txtlogin.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 177;BA.debugLine="txtpassword.Text = \"\"";
Debug.ShouldStop(65536);
main.mostCurrent._txtpassword.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 178;BA.debugLine="txtmobile.Text = \"\"";
Debug.ShouldStop(131072);
main.mostCurrent._txtmobile.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 179;BA.debugLine="Label2.Visible = False";
Debug.ShouldStop(262144);
main.mostCurrent._label2.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 180;BA.debugLine="txtlogin.Visible = False";
Debug.ShouldStop(524288);
main.mostCurrent._txtlogin.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 181;BA.debugLine="Label3.Visible = True";
Debug.ShouldStop(1048576);
main.mostCurrent._label3.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 182;BA.debugLine="txtpassword.Visible = True";
Debug.ShouldStop(2097152);
main.mostCurrent._txtpassword.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 183;BA.debugLine="Label4.Visible = False";
Debug.ShouldStop(4194304);
main.mostCurrent._label4.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 184;BA.debugLine="txtmobile.Visible = False";
Debug.ShouldStop(8388608);
main.mostCurrent._txtmobile.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 185;BA.debugLine="cmdlogin.Text = \"Update\"";
Debug.ShouldStop(16777216);
main.mostCurrent._cmdlogin.runMethod(true,"setText",BA.ObjectToCharSequence("Update"));
 BA.debugLineNum = 186;BA.debugLine="cmdcancel.Text = \"Cancel\"";
Debug.ShouldStop(33554432);
main.mostCurrent._cmdcancel.runMethod(true,"setText",BA.ObjectToCharSequence("Cancel"));
 BA.debugLineNum = 187;BA.debugLine="cmdforgot.Visible = False";
Debug.ShouldStop(67108864);
main.mostCurrent._cmdforgot.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 188;BA.debugLine="cmdregister.Visible = False";
Debug.ShouldStop(134217728);
main.mostCurrent._cmdregister.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 189;BA.debugLine="ToastMessageShow(\"Enter New Password\",False)";
Debug.ShouldStop(268435456);
main.mostCurrent.__c.runVoidMethod ("ToastMessageShow",(Object)(BA.ObjectToCharSequence("Enter New Password")),(Object)(main.mostCurrent.__c.getField(true,"False")));
 }else {
 BA.debugLineNum = 191;BA.debugLine="Msgbox(\"INVALID OTP\",\"Alert!!!\")";
Debug.ShouldStop(1073741824);
main.mostCurrent.__c.runVoidMethodAndSync ("Msgbox",(Object)(BA.ObjectToCharSequence("INVALID OTP")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("Alert!!!"))),main.mostCurrent.activityBA);
 };
 }else 
{ BA.debugLineNum = 193;BA.debugLine="Else If d_mode = 3 Then";
Debug.ShouldStop(1);
if (RemoteObject.solveBoolean("=",main._d_mode,BA.numberCast(double.class, 3))) { 
 BA.debugLineNum = 194;BA.debugLine="SQL1.ExecNonQuery(\"INSERT INTO table4 VALUES('\"";
Debug.ShouldStop(2);
main._sql1.runVoidMethod ("ExecNonQuery",(Object)(RemoteObject.concat(RemoteObject.createImmutable("INSERT INTO table4 VALUES('"),main.mostCurrent._txtpassword.runMethod(true,"getText"),RemoteObject.createImmutable("')"))));
 BA.debugLineNum = 195;BA.debugLine="ToastMessageShow(\"Password Updated.\",True)";
Debug.ShouldStop(4);
main.mostCurrent.__c.runVoidMethod ("ToastMessageShow",(Object)(BA.ObjectToCharSequence("Password Updated.")),(Object)(main.mostCurrent.__c.getField(true,"True")));
 BA.debugLineNum = 196;BA.debugLine="txtlogin.Text = \"\"";
Debug.ShouldStop(8);
main.mostCurrent._txtlogin.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 197;BA.debugLine="txtpassword.Text = \"\"";
Debug.ShouldStop(16);
main.mostCurrent._txtpassword.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 198;BA.debugLine="txtmobile.Text = \"\"";
Debug.ShouldStop(32);
main.mostCurrent._txtmobile.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 199;BA.debugLine="d_mode = 0";
Debug.ShouldStop(64);
main._d_mode = BA.numberCast(int.class, 0);
 BA.debugLineNum = 200;BA.debugLine="Label4.Visible = False";
Debug.ShouldStop(128);
main.mostCurrent._label4.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 201;BA.debugLine="txtmobile.Visible = False";
Debug.ShouldStop(256);
main.mostCurrent._txtmobile.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 202;BA.debugLine="cmdlogin.Text = \"Login\"";
Debug.ShouldStop(512);
main.mostCurrent._cmdlogin.runMethod(true,"setText",BA.ObjectToCharSequence("Login"));
 BA.debugLineNum = 203;BA.debugLine="cmdcancel.Text = \"Cancel\"";
Debug.ShouldStop(1024);
main.mostCurrent._cmdcancel.runMethod(true,"setText",BA.ObjectToCharSequence("Cancel"));
 BA.debugLineNum = 204;BA.debugLine="cmdforgot.Visible = True";
Debug.ShouldStop(2048);
main.mostCurrent._cmdforgot.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 205;BA.debugLine="cmdregister.Visible = True";
Debug.ShouldStop(4096);
main.mostCurrent._cmdregister.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 206;BA.debugLine="Label2.Visible = True";
Debug.ShouldStop(8192);
main.mostCurrent._label2.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 207;BA.debugLine="cmdlogin.Visible = True";
Debug.ShouldStop(16384);
main.mostCurrent._cmdlogin.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 208;BA.debugLine="Label3.Visible = True";
Debug.ShouldStop(32768);
main.mostCurrent._label3.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 209;BA.debugLine="txtpassword.Visible = True";
Debug.ShouldStop(65536);
main.mostCurrent._txtpassword.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 210;BA.debugLine="txtlogin.Visible = True";
Debug.ShouldStop(131072);
main.mostCurrent._txtlogin.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 }}}}
;
 BA.debugLineNum = 213;BA.debugLine="End Sub";
Debug.ShouldStop(1048576);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _cmdregister_click() throws Exception{
try {
		Debug.PushSubsStack("cmdregister_Click (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,293);
if (RapidSub.canDelegate("cmdregister_click")) { return com.mitguide.android.main.remoteMe.runUserSub(false, "main","cmdregister_click");}
 BA.debugLineNum = 293;BA.debugLine="Sub cmdregister_Click";
Debug.ShouldStop(16);
 BA.debugLineNum = 294;BA.debugLine="If d_mode = 0 Then";
Debug.ShouldStop(32);
if (RemoteObject.solveBoolean("=",main._d_mode,BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 295;BA.debugLine="txtlogin.Text = \"\"";
Debug.ShouldStop(64);
main.mostCurrent._txtlogin.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 296;BA.debugLine="txtpassword.Text = \"\"";
Debug.ShouldStop(128);
main.mostCurrent._txtpassword.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 297;BA.debugLine="txtmobile.Text = \"\"";
Debug.ShouldStop(256);
main.mostCurrent._txtmobile.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 298;BA.debugLine="d_mode = 1";
Debug.ShouldStop(512);
main._d_mode = BA.numberCast(int.class, 1);
 BA.debugLineNum = 299;BA.debugLine="Label4.Visible = True";
Debug.ShouldStop(1024);
main.mostCurrent._label4.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 300;BA.debugLine="Label4.Text = \"Mobile:\"";
Debug.ShouldStop(2048);
main.mostCurrent._label4.runMethod(true,"setText",BA.ObjectToCharSequence("Mobile:"));
 BA.debugLineNum = 301;BA.debugLine="txtmobile.Visible = True";
Debug.ShouldStop(4096);
main.mostCurrent._txtmobile.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 302;BA.debugLine="cmdlogin.Text = \"Register\"";
Debug.ShouldStop(8192);
main.mostCurrent._cmdlogin.runMethod(true,"setText",BA.ObjectToCharSequence("Register"));
 BA.debugLineNum = 303;BA.debugLine="cmdcancel.Text = \"Back\"";
Debug.ShouldStop(16384);
main.mostCurrent._cmdcancel.runMethod(true,"setText",BA.ObjectToCharSequence("Back"));
 BA.debugLineNum = 304;BA.debugLine="cmdforgot.Visible = False";
Debug.ShouldStop(32768);
main.mostCurrent._cmdforgot.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 305;BA.debugLine="cmdregister.Visible = False";
Debug.ShouldStop(65536);
main.mostCurrent._cmdregister.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 }else {
 BA.debugLineNum = 307;BA.debugLine="d_mode = 0";
Debug.ShouldStop(262144);
main._d_mode = BA.numberCast(int.class, 0);
 BA.debugLineNum = 308;BA.debugLine="txtlogin.Text = \"\"";
Debug.ShouldStop(524288);
main.mostCurrent._txtlogin.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 309;BA.debugLine="txtpassword.Text = \"\"";
Debug.ShouldStop(1048576);
main.mostCurrent._txtpassword.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 310;BA.debugLine="txtmobile.Text = \"\"";
Debug.ShouldStop(2097152);
main.mostCurrent._txtmobile.runMethodAndSync(true,"setText",BA.ObjectToCharSequence(""));
 BA.debugLineNum = 311;BA.debugLine="Label4.Visible = False";
Debug.ShouldStop(4194304);
main.mostCurrent._label4.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 312;BA.debugLine="txtmobile.Visible = False";
Debug.ShouldStop(8388608);
main.mostCurrent._txtmobile.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 313;BA.debugLine="cmdlogin.Text = \"Login\"";
Debug.ShouldStop(16777216);
main.mostCurrent._cmdlogin.runMethod(true,"setText",BA.ObjectToCharSequence("Login"));
 BA.debugLineNum = 314;BA.debugLine="cmdcancel.Text = \"Cancel\"";
Debug.ShouldStop(33554432);
main.mostCurrent._cmdcancel.runMethod(true,"setText",BA.ObjectToCharSequence("Cancel"));
 BA.debugLineNum = 315;BA.debugLine="cmdforgot.Visible = True";
Debug.ShouldStop(67108864);
main.mostCurrent._cmdforgot.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 316;BA.debugLine="cmdregister.Visible = True";
Debug.ShouldStop(134217728);
main.mostCurrent._cmdregister.runMethod(true,"setVisible",main.mostCurrent.__c.getField(true,"True"));
 };
 BA.debugLineNum = 318;BA.debugLine="End Sub";
Debug.ShouldStop(536870912);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _createtables() throws Exception{
try {
		Debug.PushSubsStack("CreateTables (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,115);
if (RapidSub.canDelegate("createtables")) { return com.mitguide.android.main.remoteMe.runUserSub(false, "main","createtables");}
 BA.debugLineNum = 115;BA.debugLine="Sub CreateTables";
Debug.ShouldStop(262144);
 BA.debugLineNum = 116;BA.debugLine="SQL1.ExecNonQuery(\"CREATE TABLE IF NOT EXISTS tab";
Debug.ShouldStop(524288);
main._sql1.runVoidMethod ("ExecNonQuery",(Object)(RemoteObject.createImmutable("CREATE TABLE IF NOT EXISTS table3 (mob3 TEXT)")));
 BA.debugLineNum = 117;BA.debugLine="SQL1.ExecNonQuery(\"CREATE TABLE IF NOT EXISTS tab";
Debug.ShouldStop(1048576);
main._sql1.runVoidMethod ("ExecNonQuery",(Object)(RemoteObject.createImmutable("CREATE TABLE IF NOT EXISTS table4 (mob4 TEXT)")));
 BA.debugLineNum = 118;BA.debugLine="SQL1.ExecNonQuery(\"CREATE TABLE IF NOT EXISTS tab";
Debug.ShouldStop(2097152);
main._sql1.runVoidMethod ("ExecNonQuery",(Object)(RemoteObject.createImmutable("CREATE TABLE IF NOT EXISTS table5 (mob5 TEXT)")));
 BA.debugLineNum = 121;BA.debugLine="End Sub";
Debug.ShouldStop(16777216);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _delay(RemoteObject _nmillisecond) throws Exception{
try {
		Debug.PushSubsStack("Delay (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,242);
if (RapidSub.canDelegate("delay")) { return com.mitguide.android.main.remoteMe.runUserSub(false, "main","delay", _nmillisecond);}
RemoteObject _nbegintime = RemoteObject.createImmutable(0L);
RemoteObject _nendtime = RemoteObject.createImmutable(0L);
Debug.locals.put("nMilliSecond", _nmillisecond);
 BA.debugLineNum = 242;BA.debugLine="Sub Delay(nMilliSecond As Long)";
Debug.ShouldStop(131072);
 BA.debugLineNum = 243;BA.debugLine="Dim nBeginTime As Long";
Debug.ShouldStop(262144);
_nbegintime = RemoteObject.createImmutable(0L);Debug.locals.put("nBeginTime", _nbegintime);
 BA.debugLineNum = 244;BA.debugLine="Dim nEndTime As Long";
Debug.ShouldStop(524288);
_nendtime = RemoteObject.createImmutable(0L);Debug.locals.put("nEndTime", _nendtime);
 BA.debugLineNum = 245;BA.debugLine="nEndTime = DateTime.Now + nMilliSecond";
Debug.ShouldStop(1048576);
_nendtime = RemoteObject.solve(new RemoteObject[] {main.mostCurrent.__c.getField(false,"DateTime").runMethod(true,"getNow"),_nmillisecond}, "+",1, 2);Debug.locals.put("nEndTime", _nendtime);
 BA.debugLineNum = 246;BA.debugLine="nBeginTime = DateTime.Now";
Debug.ShouldStop(2097152);
_nbegintime = main.mostCurrent.__c.getField(false,"DateTime").runMethod(true,"getNow");Debug.locals.put("nBeginTime", _nbegintime);
 BA.debugLineNum = 247;BA.debugLine="Do While nBeginTime < nEndTime";
Debug.ShouldStop(4194304);
while (RemoteObject.solveBoolean("<",_nbegintime,BA.numberCast(double.class, _nendtime))) {
 BA.debugLineNum = 248;BA.debugLine="nBeginTime = DateTime.Now";
Debug.ShouldStop(8388608);
_nbegintime = main.mostCurrent.__c.getField(false,"DateTime").runMethod(true,"getNow");Debug.locals.put("nBeginTime", _nbegintime);
 BA.debugLineNum = 249;BA.debugLine="Log(nBeginTime)";
Debug.ShouldStop(16777216);
main.mostCurrent.__c.runVoidMethod ("LogImpl","71048583",BA.NumberToString(_nbegintime),0);
 BA.debugLineNum = 250;BA.debugLine="If nEndTime < nBeginTime Then";
Debug.ShouldStop(33554432);
if (RemoteObject.solveBoolean("<",_nendtime,BA.numberCast(double.class, _nbegintime))) { 
 BA.debugLineNum = 251;BA.debugLine="Return";
Debug.ShouldStop(67108864);
if (true) return RemoteObject.createImmutable("");
 };
 BA.debugLineNum = 253;BA.debugLine="DoEvents";
Debug.ShouldStop(268435456);
main.mostCurrent.__c.runVoidMethodAndSync ("DoEvents");
 }
;
 BA.debugLineNum = 255;BA.debugLine="End Sub";
Debug.ShouldStop(1073741824);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _globals() throws Exception{
 //BA.debugLineNum = 31;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 34;BA.debugLine="Dim Label1 As Label";
main.mostCurrent._label1 = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 35;BA.debugLine="Dim Label2 As Label";
main.mostCurrent._label2 = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 36;BA.debugLine="Dim Label3 As Label";
main.mostCurrent._label3 = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 37;BA.debugLine="Dim txtlogin As EditText";
main.mostCurrent._txtlogin = RemoteObject.createNew ("anywheresoftware.b4a.objects.EditTextWrapper");
 //BA.debugLineNum = 38;BA.debugLine="Dim txtpassword As EditText";
main.mostCurrent._txtpassword = RemoteObject.createNew ("anywheresoftware.b4a.objects.EditTextWrapper");
 //BA.debugLineNum = 39;BA.debugLine="Dim cmdlogin As Button";
main.mostCurrent._cmdlogin = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 40;BA.debugLine="Dim cmdcancel As Button";
main.mostCurrent._cmdcancel = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 41;BA.debugLine="Private cmdforgot As Button";
main.mostCurrent._cmdforgot = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 42;BA.debugLine="Private cmdregister As Button";
main.mostCurrent._cmdregister = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 43;BA.debugLine="Private Label4 As Label";
main.mostCurrent._label4 = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 44;BA.debugLine="Private txtmobile As EditText";
main.mostCurrent._txtmobile = RemoteObject.createNew ("anywheresoftware.b4a.objects.EditTextWrapper");
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _logtable1() throws Exception{
try {
		Debug.PushSubsStack("LogTable1 (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,59);
if (RapidSub.canDelegate("logtable1")) { return com.mitguide.android.main.remoteMe.runUserSub(false, "main","logtable1");}
RemoteObject _cursor1 = RemoteObject.declareNull("anywheresoftware.b4a.sql.SQL.CursorWrapper");
int _i = 0;
 BA.debugLineNum = 59;BA.debugLine="Sub LogTable1";
Debug.ShouldStop(67108864);
 BA.debugLineNum = 60;BA.debugLine="Dim Cursor1 As Cursor";
Debug.ShouldStop(134217728);
_cursor1 = RemoteObject.createNew ("anywheresoftware.b4a.sql.SQL.CursorWrapper");Debug.locals.put("Cursor1", _cursor1);
 BA.debugLineNum = 61;BA.debugLine="Cursor1 = SQL1.ExecQuery(\"SELECT mob3 FROM table3";
Debug.ShouldStop(268435456);
_cursor1.setObject(main._sql1.runMethod(false,"ExecQuery",(Object)(RemoteObject.createImmutable("SELECT mob3 FROM table3"))));
 BA.debugLineNum = 62;BA.debugLine="If Cursor1.RowCount > 0 Then";
Debug.ShouldStop(536870912);
if (RemoteObject.solveBoolean(">",_cursor1.runMethod(true,"getRowCount"),BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 63;BA.debugLine="d_use = 0";
Debug.ShouldStop(1073741824);
main._d_use = BA.numberCast(int.class, 0);
 BA.debugLineNum = 64;BA.debugLine="For i = 0 To Cursor1.RowCount - 1";
Debug.ShouldStop(-2147483648);
{
final int step5 = 1;
final int limit5 = RemoteObject.solve(new RemoteObject[] {_cursor1.runMethod(true,"getRowCount"),RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
_i = 0 ;
for (;(step5 > 0 && _i <= limit5) || (step5 < 0 && _i >= limit5) ;_i = ((int)(0 + _i + step5))  ) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 65;BA.debugLine="Cursor1.Position = i";
Debug.ShouldStop(1);
_cursor1.runMethod(true,"setPosition",BA.numberCast(int.class, _i));
 BA.debugLineNum = 66;BA.debugLine="Log(\"************************\")";
Debug.ShouldStop(2);
main.mostCurrent.__c.runVoidMethod ("LogImpl","7720903",RemoteObject.createImmutable("************************"),0);
 BA.debugLineNum = 67;BA.debugLine="Log(Cursor1.GetString(\"mob3\"))";
Debug.ShouldStop(4);
main.mostCurrent.__c.runVoidMethod ("LogImpl","7720904",_cursor1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("mob3"))),0);
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 71;BA.debugLine="d_login = Cursor1.GetString(\"mob3\")";
Debug.ShouldStop(64);
main._d_login = _cursor1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("mob3")));
 BA.debugLineNum = 72;BA.debugLine="Cursor1.Close";
Debug.ShouldStop(128);
_cursor1.runVoidMethod ("Close");
 BA.debugLineNum = 74;BA.debugLine="Cursor1 = SQL1.ExecQuery(\"SELECT mob4 FROM table4";
Debug.ShouldStop(512);
_cursor1.setObject(main._sql1.runMethod(false,"ExecQuery",(Object)(RemoteObject.createImmutable("SELECT mob4 FROM table4"))));
 BA.debugLineNum = 75;BA.debugLine="For i = 0 To Cursor1.RowCount - 1";
Debug.ShouldStop(1024);
{
final int step13 = 1;
final int limit13 = RemoteObject.solve(new RemoteObject[] {_cursor1.runMethod(true,"getRowCount"),RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
_i = 0 ;
for (;(step13 > 0 && _i <= limit13) || (step13 < 0 && _i >= limit13) ;_i = ((int)(0 + _i + step13))  ) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 76;BA.debugLine="Cursor1.Position = i";
Debug.ShouldStop(2048);
_cursor1.runMethod(true,"setPosition",BA.numberCast(int.class, _i));
 BA.debugLineNum = 77;BA.debugLine="Log(\"************************\")";
Debug.ShouldStop(4096);
main.mostCurrent.__c.runVoidMethod ("LogImpl","7720914",RemoteObject.createImmutable("************************"),0);
 BA.debugLineNum = 78;BA.debugLine="Log(Cursor1.GetString(\"mob4\"))";
Debug.ShouldStop(8192);
main.mostCurrent.__c.runVoidMethod ("LogImpl","7720915",_cursor1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("mob4"))),0);
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 82;BA.debugLine="d_pass = Cursor1.GetString(\"mob4\")";
Debug.ShouldStop(131072);
main._d_pass = _cursor1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("mob4")));
 BA.debugLineNum = 83;BA.debugLine="Cursor1.Close";
Debug.ShouldStop(262144);
_cursor1.runVoidMethod ("Close");
 BA.debugLineNum = 85;BA.debugLine="Cursor1 = SQL1.ExecQuery(\"SELECT mob5 FROM table5";
Debug.ShouldStop(1048576);
_cursor1.setObject(main._sql1.runMethod(false,"ExecQuery",(Object)(RemoteObject.createImmutable("SELECT mob5 FROM table5"))));
 BA.debugLineNum = 86;BA.debugLine="For i = 0 To Cursor1.RowCount - 1";
Debug.ShouldStop(2097152);
{
final int step21 = 1;
final int limit21 = RemoteObject.solve(new RemoteObject[] {_cursor1.runMethod(true,"getRowCount"),RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
_i = 0 ;
for (;(step21 > 0 && _i <= limit21) || (step21 < 0 && _i >= limit21) ;_i = ((int)(0 + _i + step21))  ) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 87;BA.debugLine="Cursor1.Position = i";
Debug.ShouldStop(4194304);
_cursor1.runMethod(true,"setPosition",BA.numberCast(int.class, _i));
 BA.debugLineNum = 88;BA.debugLine="Log(\"************************\")";
Debug.ShouldStop(8388608);
main.mostCurrent.__c.runVoidMethod ("LogImpl","7720925",RemoteObject.createImmutable("************************"),0);
 BA.debugLineNum = 89;BA.debugLine="Log(Cursor1.GetString(\"mob5\"))";
Debug.ShouldStop(16777216);
main.mostCurrent.__c.runVoidMethod ("LogImpl","7720926",_cursor1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("mob5"))),0);
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 93;BA.debugLine="d_mobile = Cursor1.GetString(\"mob5\")";
Debug.ShouldStop(268435456);
main._d_mobile = _cursor1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("mob5")));
 BA.debugLineNum = 94;BA.debugLine="Cursor1.Close";
Debug.ShouldStop(536870912);
_cursor1.runVoidMethod ("Close");
 }else {
 BA.debugLineNum = 96;BA.debugLine="d_use = 1";
Debug.ShouldStop(-2147483648);
main._d_use = BA.numberCast(int.class, 1);
 BA.debugLineNum = 97;BA.debugLine="Msgbox(\"No Entries of User found\",\"Alert!!!\")";
Debug.ShouldStop(1);
main.mostCurrent.__c.runVoidMethodAndSync ("Msgbox",(Object)(BA.ObjectToCharSequence("No Entries of User found")),(Object)(BA.ObjectToCharSequence(RemoteObject.createImmutable("Alert!!!"))),main.mostCurrent.activityBA);
 };
 BA.debugLineNum = 99;BA.debugLine="End Sub";
Debug.ShouldStop(4);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _logtable2() throws Exception{
try {
		Debug.PushSubsStack("LogTable2 (main) ","main",0,main.mostCurrent.activityBA,main.mostCurrent,101);
if (RapidSub.canDelegate("logtable2")) { return com.mitguide.android.main.remoteMe.runUserSub(false, "main","logtable2");}
RemoteObject _cursor1 = RemoteObject.declareNull("anywheresoftware.b4a.sql.SQL.CursorWrapper");
int _i = 0;
 BA.debugLineNum = 101;BA.debugLine="Sub LogTable2";
Debug.ShouldStop(16);
 BA.debugLineNum = 102;BA.debugLine="Dim Cursor1 As Cursor";
Debug.ShouldStop(32);
_cursor1 = RemoteObject.createNew ("anywheresoftware.b4a.sql.SQL.CursorWrapper");Debug.locals.put("Cursor1", _cursor1);
 BA.debugLineNum = 103;BA.debugLine="Cursor1 = SQL1.ExecQuery(\"SELECT mob2 FROM table2";
Debug.ShouldStop(64);
_cursor1.setObject(main._sql1.runMethod(false,"ExecQuery",(Object)(RemoteObject.createImmutable("SELECT mob2 FROM table2"))));
 BA.debugLineNum = 104;BA.debugLine="For i = 0 To Cursor1.RowCount - 1";
Debug.ShouldStop(128);
{
final int step3 = 1;
final int limit3 = RemoteObject.solve(new RemoteObject[] {_cursor1.runMethod(true,"getRowCount"),RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
_i = 0 ;
for (;(step3 > 0 && _i <= limit3) || (step3 < 0 && _i >= limit3) ;_i = ((int)(0 + _i + step3))  ) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 105;BA.debugLine="Cursor1.Position = i";
Debug.ShouldStop(256);
_cursor1.runMethod(true,"setPosition",BA.numberCast(int.class, _i));
 BA.debugLineNum = 106;BA.debugLine="Log(\"************************\")";
Debug.ShouldStop(512);
main.mostCurrent.__c.runVoidMethod ("LogImpl","7786437",RemoteObject.createImmutable("************************"),0);
 BA.debugLineNum = 107;BA.debugLine="Log(Cursor1.GetString(\"mob2\"))";
Debug.ShouldStop(1024);
main.mostCurrent.__c.runVoidMethod ("LogImpl","7786438",_cursor1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("mob2"))),0);
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 112;BA.debugLine="Cursor1.Close";
Debug.ShouldStop(32768);
_cursor1.runVoidMethod ("Close");
 BA.debugLineNum = 113;BA.debugLine="End Sub";
Debug.ShouldStop(65536);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main_subs_0._process_globals();
starter_subs_0._process_globals();
maps_subs_0._process_globals();
main.myClass = BA.getDeviceClass ("com.mitguide.android.main");
starter.myClass = BA.getDeviceClass ("com.mitguide.android.starter");
maps.myClass = BA.getDeviceClass ("com.mitguide.android.maps");
camex2.myClass = BA.getDeviceClass ("com.mitguide.android.camex2");
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 16;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 19;BA.debugLine="Dim API_KEY1 As String";
main._api_key1 = RemoteObject.createImmutable("");
 //BA.debugLineNum = 20;BA.debugLine="Dim SQL1 As SQL";
main._sql1 = RemoteObject.createNew ("anywheresoftware.b4a.sql.SQL");
 //BA.debugLineNum = 21;BA.debugLine="Dim d_login As String";
main._d_login = RemoteObject.createImmutable("");
 //BA.debugLineNum = 22;BA.debugLine="Dim d_pass As String";
main._d_pass = RemoteObject.createImmutable("");
 //BA.debugLineNum = 23;BA.debugLine="Dim d_mobile As String";
main._d_mobile = RemoteObject.createImmutable("");
 //BA.debugLineNum = 24;BA.debugLine="Dim d_mode As Int";
main._d_mode = RemoteObject.createImmutable(0);
 //BA.debugLineNum = 25;BA.debugLine="Dim Sms1 As PhoneSms";
main._sms1 = RemoteObject.createNew ("anywheresoftware.b4a.phone.Phone.PhoneSms");
 //BA.debugLineNum = 26;BA.debugLine="Dim phone1 As PhoneCalls";
main._phone1 = RemoteObject.createNew ("anywheresoftware.b4a.phone.Phone.PhoneCalls");
 //BA.debugLineNum = 27;BA.debugLine="Dim d_use As Int";
main._d_use = RemoteObject.createImmutable(0);
 //BA.debugLineNum = 28;BA.debugLine="Dim ran_no As Int";
main._ran_no = RemoteObject.createImmutable(0);
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
}