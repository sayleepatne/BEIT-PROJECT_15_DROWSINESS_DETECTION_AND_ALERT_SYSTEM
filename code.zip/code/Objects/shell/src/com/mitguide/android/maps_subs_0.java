package com.mitguide.android;

import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.*;

public class maps_subs_0 {


public static RemoteObject  _activity_create(RemoteObject _firsttime) throws Exception{
try {
		Debug.PushSubsStack("Activity_Create (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,64);
if (RapidSub.canDelegate("activity_create")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","activity_create", _firsttime);}
Debug.locals.put("FirstTime", _firsttime);
 BA.debugLineNum = 64;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
Debug.ShouldStop(-2147483648);
 BA.debugLineNum = 67;BA.debugLine="Activity.LoadLayout(\"1\")";
Debug.ShouldStop(4);
maps.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(RemoteObject.createImmutable("1")),maps.mostCurrent.activityBA);
 BA.debugLineNum = 68;BA.debugLine="p_status = 0";
Debug.ShouldStop(8);
maps._p_status = BA.numberCast(int.class, 0);
 BA.debugLineNum = 69;BA.debugLine="p_drowsiness = 0";
Debug.ShouldStop(16);
maps._p_drowsiness = BA.numberCast(int.class, 0);
 BA.debugLineNum = 70;BA.debugLine="VideoFileDir = rp.GetSafeDirDefaultExternal(\"\")";
Debug.ShouldStop(32);
maps._videofiledir = maps._rp.runMethod(true,"GetSafeDirDefaultExternal",(Object)(RemoteObject.createImmutable("")));
 BA.debugLineNum = 71;BA.debugLine="VideoFileName = \"1.mp4\"";
Debug.ShouldStop(64);
maps._videofilename = BA.ObjectToString("1.mp4");
 BA.debugLineNum = 72;BA.debugLine="Activity.LoadLayout(\"1\")";
Debug.ShouldStop(128);
maps.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(RemoteObject.createImmutable("1")),maps.mostCurrent.activityBA);
 BA.debugLineNum = 73;BA.debugLine="Activity.LoadLayout(\"StillPicture\")";
Debug.ShouldStop(256);
maps.mostCurrent._activity.runMethodAndSync(false,"LoadLayout",(Object)(RemoteObject.createImmutable("StillPicture")),maps.mostCurrent.activityBA);
 BA.debugLineNum = 74;BA.debugLine="cam.Initialize(pnlCamera)";
Debug.ShouldStop(512);
maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_initialize" /*RemoteObject*/ ,maps.mostCurrent.activityBA,(Object)(maps.mostCurrent._pnlcamera));
 BA.debugLineNum = 75;BA.debugLine="Log(cam.SupportedHardwareLevel)";
Debug.ShouldStop(1024);
maps.mostCurrent.__c.runVoidMethod ("LogImpl","71441803",maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_getsupportedhardwarelevel" /*RemoteObject*/ ),0);
 BA.debugLineNum = 76;BA.debugLine="buttons = Array(btnScene, btnAutoExposure, btnEff";
Debug.ShouldStop(2048);
maps.mostCurrent._buttons = maps.mostCurrent.__c.runMethod(false, "ArrayToList", (Object)(RemoteObject.createNewArray("Object",new int[] {5},new Object[] {(maps.mostCurrent._btnscene.getObject()),(maps.mostCurrent._btnautoexposure.getObject()),(maps.mostCurrent._btneffects.getObject()),(maps.mostCurrent._btnfocus.getObject()),(maps.mostCurrent._btnmode.getObject())})));
 BA.debugLineNum = 77;BA.debugLine="SetState(False, False, VideoMode)";
Debug.ShouldStop(4096);
_setstate(maps.mostCurrent.__c.getField(true,"False"),maps.mostCurrent.__c.getField(true,"False"),maps._videomode);
 BA.debugLineNum = 78;BA.debugLine="sf.Initialize";
Debug.ShouldStop(8192);
maps.mostCurrent._sf.runVoidMethod ("_vv5",maps.processBA);
 BA.debugLineNum = 79;BA.debugLine="lv1.SingleLineLayout.Label.TextSize = 15";
Debug.ShouldStop(16384);
maps.mostCurrent._lv1.runMethod(false,"getSingleLineLayout").getField(false,"Label").runMethod(true,"setTextSize",BA.numberCast(float.class, 15));
 BA.debugLineNum = 80;BA.debugLine="lv1.SingleLineLayout.Label.TextColor = Colors.Whi";
Debug.ShouldStop(32768);
maps.mostCurrent._lv1.runMethod(false,"getSingleLineLayout").getField(false,"Label").runMethod(true,"setTextColor",maps.mostCurrent.__c.getField(false,"Colors").getField(true,"White"));
 BA.debugLineNum = 81;BA.debugLine="lv1.TwoLinesLayout.Label.TextSize = 15";
Debug.ShouldStop(65536);
maps.mostCurrent._lv1.runMethod(false,"getTwoLinesLayout").getField(false,"Label").runMethod(true,"setTextSize",BA.numberCast(float.class, 15));
 BA.debugLineNum = 82;BA.debugLine="lv1.TwoLinesLayout.Label.TextColor = Colors.white";
Debug.ShouldStop(131072);
maps.mostCurrent._lv1.runMethod(false,"getTwoLinesLayout").getField(false,"Label").runMethod(true,"setTextColor",maps.mostCurrent.__c.getField(false,"Colors").getField(true,"White"));
 BA.debugLineNum = 83;BA.debugLine="Label14.Text = \"Welcome \" & u_name";
Debug.ShouldStop(262144);
maps.mostCurrent._label14.runMethod(true,"setText",BA.ObjectToCharSequence(RemoteObject.concat(RemoteObject.createImmutable("Welcome "),maps._u_name)));
 BA.debugLineNum = 84;BA.debugLine="If FirstTime Then";
Debug.ShouldStop(524288);
if (_firsttime.<Boolean>get().booleanValue()) { 
 BA.debugLineNum = 86;BA.debugLine="SQL1.Initialize(File.DirDefaultExternal, \"test1.";
Debug.ShouldStop(2097152);
maps._sql1.runVoidMethod ("Initialize",(Object)(maps.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirDefaultExternal")),(Object)(BA.ObjectToString("test1.db")),(Object)(maps.mostCurrent.__c.getField(true,"True")));
 BA.debugLineNum = 87;BA.debugLine="GPS1.Initialize(\"GPS\")";
Debug.ShouldStop(4194304);
maps._gps1.runVoidMethod ("Initialize",(Object)(RemoteObject.createImmutable("GPS")));
 BA.debugLineNum = 89;BA.debugLine="SQL1.Initialize(File.DirDefaultExternal, \"test1.";
Debug.ShouldStop(16777216);
maps._sql1.runVoidMethod ("Initialize",(Object)(maps.mostCurrent.__c.getField(false,"File").runMethod(true,"getDirDefaultExternal")),(Object)(BA.ObjectToString("test1.db")),(Object)(maps.mostCurrent.__c.getField(true,"True")));
 BA.debugLineNum = 92;BA.debugLine="Timer1.Initialize(\"Timer1\", 5000)";
Debug.ShouldStop(134217728);
maps._timer1.runVoidMethod ("Initialize",maps.processBA,(Object)(BA.ObjectToString("Timer1")),(Object)(BA.numberCast(long.class, 5000)));
 BA.debugLineNum = 93;BA.debugLine="Timer2.Initialize(\"Timer2\", 500)";
Debug.ShouldStop(268435456);
maps._timer2.runVoidMethod ("Initialize",maps.processBA,(Object)(BA.ObjectToString("Timer2")),(Object)(BA.numberCast(long.class, 500)));
 BA.debugLineNum = 94;BA.debugLine="Timer1.Enabled = False";
Debug.ShouldStop(536870912);
maps._timer1.runMethod(true,"setEnabled",maps.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 100;BA.debugLine="number1 = \"7039322836\" 'AMit";
Debug.ShouldStop(8);
maps._number1 = BA.ObjectToString("7039322836");
 BA.debugLineNum = 101;BA.debugLine="number2 = \"9702584005\" 'Rohit";
Debug.ShouldStop(16);
maps._number2 = BA.ObjectToString("9702584005");
 };
 BA.debugLineNum = 103;BA.debugLine="CreateTables";
Debug.ShouldStop(64);
_createtables();
 BA.debugLineNum = 104;BA.debugLine="TTS1.Initialize(\"TTS1\")";
Debug.ShouldStop(128);
maps._tts1.runVoidMethod ("Initialize",maps.processBA,(Object)(RemoteObject.createImmutable("TTS1")));
 BA.debugLineNum = 108;BA.debugLine="Timer2.Enabled = False";
Debug.ShouldStop(2048);
maps._timer2.runMethod(true,"setEnabled",maps.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 114;BA.debugLine="End Sub";
Debug.ShouldStop(131072);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_pause(RemoteObject _userclosed) throws Exception{
try {
		Debug.PushSubsStack("Activity_Pause (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,189);
if (RapidSub.canDelegate("activity_pause")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","activity_pause", _userclosed);}
Debug.locals.put("UserClosed", _userclosed);
 BA.debugLineNum = 189;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
Debug.ShouldStop(268435456);
 BA.debugLineNum = 190;BA.debugLine="pw.ReleaseKeepAlive";
Debug.ShouldStop(536870912);
maps._pw.runVoidMethod ("ReleaseKeepAlive");
 BA.debugLineNum = 191;BA.debugLine="cam.Stop";
Debug.ShouldStop(1073741824);
maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_stop" /*RemoteObject*/ );
 BA.debugLineNum = 192;BA.debugLine="End Sub";
Debug.ShouldStop(-2147483648);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _activity_resume() throws Exception{
try {
		Debug.PushSubsStack("Activity_Resume (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,185);
if (RapidSub.canDelegate("activity_resume")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","activity_resume");}
 BA.debugLineNum = 185;BA.debugLine="Sub Activity_Resume";
Debug.ShouldStop(16777216);
 BA.debugLineNum = 186;BA.debugLine="OpenCamera(frontCamera)";
Debug.ShouldStop(33554432);
_opencamera(maps._frontcamera);
 BA.debugLineNum = 187;BA.debugLine="End Sub";
Debug.ShouldStop(67108864);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _barzoom_valuechanged(RemoteObject _value,RemoteObject _userchanged) throws Exception{
try {
		Debug.PushSubsStack("barZoom_ValueChanged (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,449);
if (RapidSub.canDelegate("barzoom_valuechanged")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","barzoom_valuechanged", _value, _userchanged);}
RemoteObject _originalsize = RemoteObject.declareNull("anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper");
RemoteObject _zoom = RemoteObject.createImmutable(0f);
RemoteObject _crop = RemoteObject.declareNull("anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper");
RemoteObject _newwidth = RemoteObject.createImmutable(0);
RemoteObject _newheight = RemoteObject.createImmutable(0);
Debug.locals.put("Value", _value);
Debug.locals.put("UserChanged", _userchanged);
 BA.debugLineNum = 449;BA.debugLine="Sub barZoom_ValueChanged (Value As Int, UserChange";
Debug.ShouldStop(1);
 BA.debugLineNum = 450;BA.debugLine="Dim OriginalSize As Rect = cam.ActiveArraySize";
Debug.ShouldStop(2);
_originalsize = RemoteObject.createNew ("anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper");
_originalsize = maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_getactivearraysize" /*RemoteObject*/ );Debug.locals.put("OriginalSize", _originalsize);Debug.locals.put("OriginalSize", _originalsize);
 BA.debugLineNum = 451;BA.debugLine="Dim Zoom As Float = 1 + Value / 100 * (cam.MaxDig";
Debug.ShouldStop(4);
_zoom = BA.numberCast(float.class, RemoteObject.solve(new RemoteObject[] {RemoteObject.createImmutable(1),_value,RemoteObject.createImmutable(100),(RemoteObject.solve(new RemoteObject[] {maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_getmaxdigitalzoom" /*RemoteObject*/ ),RemoteObject.createImmutable(1)}, "-",1, 0))}, "+/*",1, 0));Debug.locals.put("Zoom", _zoom);Debug.locals.put("Zoom", _zoom);
 BA.debugLineNum = 452;BA.debugLine="Dim Crop As Rect";
Debug.ShouldStop(8);
_crop = RemoteObject.createNew ("anywheresoftware.b4a.objects.drawable.CanvasWrapper.RectWrapper");Debug.locals.put("Crop", _crop);
 BA.debugLineNum = 453;BA.debugLine="Dim NewWidth As Int = OriginalSize.Width / Zoom";
Debug.ShouldStop(16);
_newwidth = BA.numberCast(int.class, RemoteObject.solve(new RemoteObject[] {_originalsize.runMethod(true,"getWidth"),_zoom}, "/",0, 0));Debug.locals.put("NewWidth", _newwidth);Debug.locals.put("NewWidth", _newwidth);
 BA.debugLineNum = 454;BA.debugLine="Dim NewHeight As Int = OriginalSize.Height / Zoom";
Debug.ShouldStop(32);
_newheight = BA.numberCast(int.class, RemoteObject.solve(new RemoteObject[] {_originalsize.runMethod(true,"getHeight"),_zoom}, "/",0, 0));Debug.locals.put("NewHeight", _newheight);Debug.locals.put("NewHeight", _newheight);
 BA.debugLineNum = 455;BA.debugLine="Crop.Initialize(OriginalSize.CenterX - NewWidth /";
Debug.ShouldStop(64);
_crop.runVoidMethod ("Initialize",(Object)(BA.numberCast(int.class, RemoteObject.solve(new RemoteObject[] {_originalsize.runMethod(true,"getCenterX"),_newwidth,RemoteObject.createImmutable(2)}, "-/",1, 0))),(Object)(BA.numberCast(int.class, RemoteObject.solve(new RemoteObject[] {_originalsize.runMethod(true,"getCenterY"),_newheight,RemoteObject.createImmutable(2)}, "-/",1, 0))),(Object)(BA.numberCast(int.class, RemoteObject.solve(new RemoteObject[] {_originalsize.runMethod(true,"getCenterX"),_newwidth,RemoteObject.createImmutable(2)}, "+/",1, 0))),(Object)(BA.numberCast(int.class, RemoteObject.solve(new RemoteObject[] {_originalsize.runMethod(true,"getCenterY"),_newheight,RemoteObject.createImmutable(2)}, "+/",1, 0))));
 BA.debugLineNum = 457;BA.debugLine="cam.PreviewCropRegion = Crop";
Debug.ShouldStop(256);
maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_setpreviewcropregion",_crop);
 BA.debugLineNum = 458;BA.debugLine="cam.StartPreview(MyTaskIndex, VideoMode)";
Debug.ShouldStop(512);
maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_startpreview" /*RemoteObject*/ ,(Object)(maps._mytaskindex),(Object)(maps._videomode));
 BA.debugLineNum = 459;BA.debugLine="End Sub";
Debug.ShouldStop(1024);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _btnautoexposure_click() throws Exception{
try {
		Debug.PushSubsStack("btnAutoExposure_Click (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,406);
if (RapidSub.canDelegate("btnautoexposure_click")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","btnautoexposure_click");}
RemoteObject _flashes = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
RemoteObject _i = RemoteObject.createImmutable(0);
 BA.debugLineNum = 406;BA.debugLine="Sub btnAutoExposure_Click";
Debug.ShouldStop(2097152);
 BA.debugLineNum = 407;BA.debugLine="Dim flashes As List = cam.SupportedAutoExposureMo";
Debug.ShouldStop(4194304);
_flashes = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");
_flashes = maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_getsupportedautoexposuremodes" /*RemoteObject*/ );Debug.locals.put("flashes", _flashes);Debug.locals.put("flashes", _flashes);
 BA.debugLineNum = 408;BA.debugLine="Dim i As Int = flashes.IndexOf(cam.AutoExposureMo";
Debug.ShouldStop(8388608);
_i = _flashes.runMethod(true,"IndexOf",(Object)((maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_getautoexposuremode" /*RemoteObject*/ ))));Debug.locals.put("i", _i);Debug.locals.put("i", _i);
 BA.debugLineNum = 409;BA.debugLine="i = (i + 1) Mod flashes.Size";
Debug.ShouldStop(16777216);
_i = RemoteObject.solve(new RemoteObject[] {(RemoteObject.solve(new RemoteObject[] {_i,RemoteObject.createImmutable(1)}, "+",1, 1)),_flashes.runMethod(true,"getSize")}, "%",0, 1);Debug.locals.put("i", _i);
 BA.debugLineNum = 410;BA.debugLine="cam.AutoExposureMode = flashes.Get(i)";
Debug.ShouldStop(33554432);
maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_setautoexposuremode" /*RemoteObject*/ ,BA.ObjectToString(_flashes.runMethod(false,"Get",(Object)(_i))));
 BA.debugLineNum = 411;BA.debugLine="btnAutoExposure.Text = flashes.Get(i)";
Debug.ShouldStop(67108864);
maps.mostCurrent._btnautoexposure.runMethod(true,"setText",BA.ObjectToCharSequence(_flashes.runMethod(false,"Get",(Object)(_i))));
 BA.debugLineNum = 412;BA.debugLine="cam.StartPreview(MyTaskIndex, VideoMode)";
Debug.ShouldStop(134217728);
maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_startpreview" /*RemoteObject*/ ,(Object)(maps._mytaskindex),(Object)(maps._videomode));
 BA.debugLineNum = 413;BA.debugLine="End Sub";
Debug.ShouldStop(268435456);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _btncamera_click() throws Exception{
try {
		Debug.PushSubsStack("btnCamera_Click (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,232);
if (RapidSub.canDelegate("btncamera_click")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","btncamera_click");}
 BA.debugLineNum = 232;BA.debugLine="Sub btnCamera_Click";
Debug.ShouldStop(128);
 BA.debugLineNum = 233;BA.debugLine="frontCamera = Not(frontCamera)";
Debug.ShouldStop(256);
maps._frontcamera = maps.mostCurrent.__c.runMethod(true,"Not",(Object)(maps._frontcamera));
 BA.debugLineNum = 234;BA.debugLine="OpenCamera(frontCamera)";
Debug.ShouldStop(512);
_opencamera(maps._frontcamera);
 BA.debugLineNum = 235;BA.debugLine="End Sub";
Debug.ShouldStop(1024);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _btneffects_click() throws Exception{
try {
		Debug.PushSubsStack("btnEffects_Click (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,388);
if (RapidSub.canDelegate("btneffects_click")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","btneffects_click");}
RemoteObject _effects = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
RemoteObject _i = RemoteObject.createImmutable(0);
 BA.debugLineNum = 388;BA.debugLine="Sub btnEffects_Click";
Debug.ShouldStop(8);
 BA.debugLineNum = 389;BA.debugLine="Dim effects As List = cam.SupportedEffectModes";
Debug.ShouldStop(16);
_effects = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");
_effects = maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_getsupportedeffectmodes" /*RemoteObject*/ );Debug.locals.put("effects", _effects);Debug.locals.put("effects", _effects);
 BA.debugLineNum = 390;BA.debugLine="Dim i As Int = effects.IndexOf(cam.EffectMode)";
Debug.ShouldStop(32);
_i = _effects.runMethod(true,"IndexOf",(Object)((maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_geteffectmode" /*RemoteObject*/ ))));Debug.locals.put("i", _i);Debug.locals.put("i", _i);
 BA.debugLineNum = 391;BA.debugLine="i = (i + 1) Mod effects.Size";
Debug.ShouldStop(64);
_i = RemoteObject.solve(new RemoteObject[] {(RemoteObject.solve(new RemoteObject[] {_i,RemoteObject.createImmutable(1)}, "+",1, 1)),_effects.runMethod(true,"getSize")}, "%",0, 1);Debug.locals.put("i", _i);
 BA.debugLineNum = 392;BA.debugLine="cam.EffectMode = effects.Get(i)";
Debug.ShouldStop(128);
maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_seteffectmode" /*RemoteObject*/ ,BA.ObjectToString(_effects.runMethod(false,"Get",(Object)(_i))));
 BA.debugLineNum = 393;BA.debugLine="btnEffects.Text = effects.Get(i)";
Debug.ShouldStop(256);
maps.mostCurrent._btneffects.runMethod(true,"setText",BA.ObjectToCharSequence(_effects.runMethod(false,"Get",(Object)(_i))));
 BA.debugLineNum = 394;BA.debugLine="cam.StartPreview(MyTaskIndex, VideoMode)";
Debug.ShouldStop(512);
maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_startpreview" /*RemoteObject*/ ,(Object)(maps._mytaskindex),(Object)(maps._videomode));
 BA.debugLineNum = 395;BA.debugLine="End Sub";
Debug.ShouldStop(1024);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _btnfocus_click() throws Exception{
try {
		Debug.PushSubsStack("btnFocus_Click (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,415);
if (RapidSub.canDelegate("btnfocus_click")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","btnfocus_click");}
RemoteObject _focuses = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
RemoteObject _i = RemoteObject.createImmutable(0);
 BA.debugLineNum = 415;BA.debugLine="Sub btnFocus_Click";
Debug.ShouldStop(1073741824);
 BA.debugLineNum = 416;BA.debugLine="Dim focuses As List = cam.SupportedFocusModes";
Debug.ShouldStop(-2147483648);
_focuses = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");
_focuses = maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_getsupportedfocusmodes" /*RemoteObject*/ );Debug.locals.put("focuses", _focuses);Debug.locals.put("focuses", _focuses);
 BA.debugLineNum = 417;BA.debugLine="Dim i As Int = focuses.IndexOf(cam.FocusMode)";
Debug.ShouldStop(1);
_i = _focuses.runMethod(true,"IndexOf",(Object)((maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_getfocusmode" /*RemoteObject*/ ))));Debug.locals.put("i", _i);Debug.locals.put("i", _i);
 BA.debugLineNum = 418;BA.debugLine="i = (i + 1) Mod focuses.Size";
Debug.ShouldStop(2);
_i = RemoteObject.solve(new RemoteObject[] {(RemoteObject.solve(new RemoteObject[] {_i,RemoteObject.createImmutable(1)}, "+",1, 1)),_focuses.runMethod(true,"getSize")}, "%",0, 1);Debug.locals.put("i", _i);
 BA.debugLineNum = 419;BA.debugLine="cam.FocusMode = focuses.Get(i)";
Debug.ShouldStop(4);
maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_setfocusmode" /*RemoteObject*/ ,BA.ObjectToString(_focuses.runMethod(false,"Get",(Object)(_i))));
 BA.debugLineNum = 420;BA.debugLine="btnFocus.Text = focuses.Get(i)";
Debug.ShouldStop(8);
maps.mostCurrent._btnfocus.runMethod(true,"setText",BA.ObjectToCharSequence(_focuses.runMethod(false,"Get",(Object)(_i))));
 BA.debugLineNum = 421;BA.debugLine="cam.StartPreview(MyTaskIndex, VideoMode)";
Debug.ShouldStop(16);
maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_startpreview" /*RemoteObject*/ ,(Object)(maps._mytaskindex),(Object)(maps._videomode));
 BA.debugLineNum = 422;BA.debugLine="End Sub";
Debug.ShouldStop(32);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static void  _btnmode_click() throws Exception{
try {
		Debug.PushSubsStack("btnMode_Click (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,237);
if (RapidSub.canDelegate("btnmode_click")) { com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","btnmode_click"); return;}
ResumableSub_btnMode_Click rsub = new ResumableSub_btnMode_Click(null);
rsub.resume(null, null);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static class ResumableSub_btnMode_Click extends BA.ResumableSub {
public ResumableSub_btnMode_Click(com.mitguide.android.maps parent) {
this.parent = parent;
}
java.util.LinkedHashMap<String, Object> rsLocals = new java.util.LinkedHashMap<String, Object>();
com.mitguide.android.maps parent;
RemoteObject _permission = RemoteObject.createImmutable("");
RemoteObject _result = RemoteObject.createImmutable(false);

@Override
public void resume(BA ba, RemoteObject result) throws Exception{
try {
		Debug.PushSubsStack("btnMode_Click (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,237);
Debug.locals = rsLocals;Debug.currentSubFrame.locals = rsLocals;

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 BA.debugLineNum = 238;BA.debugLine="VideoMode = Not(VideoMode)";
Debug.ShouldStop(8192);
parent._videomode = parent.mostCurrent.__c.runMethod(true,"Not",(Object)(parent._videomode));
 BA.debugLineNum = 239;BA.debugLine="If VideoMode Then";
Debug.ShouldStop(16384);
if (true) break;

case 1:
//if
this.state = 8;
if (parent._videomode.<Boolean>get().booleanValue()) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 BA.debugLineNum = 240;BA.debugLine="rp.CheckAndRequest(rp.PERMISSION_RECORD_AUDIO)";
Debug.ShouldStop(32768);
parent._rp.runVoidMethod ("CheckAndRequest",maps.processBA,(Object)(parent._rp.getField(true,"PERMISSION_RECORD_AUDIO")));
 BA.debugLineNum = 241;BA.debugLine="Wait For Activity_PermissionResult (Permission A";
Debug.ShouldStop(65536);
parent.mostCurrent.__c.runVoidMethod ("WaitFor","activity_permissionresult", maps.processBA, anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this, "maps", "btnmode_click"), null);
this.state = 9;
return;
case 9:
//C
this.state = 4;
_permission = (RemoteObject) result.getArrayElement(true,RemoteObject.createImmutable(0));Debug.locals.put("Permission", _permission);
_result = (RemoteObject) result.getArrayElement(true,RemoteObject.createImmutable(1));Debug.locals.put("Result", _result);
;
 BA.debugLineNum = 242;BA.debugLine="If Result = False Then";
Debug.ShouldStop(131072);
if (true) break;

case 4:
//if
this.state = 7;
if (RemoteObject.solveBoolean("=",_result,parent.mostCurrent.__c.getField(true,"False"))) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 BA.debugLineNum = 243;BA.debugLine="ToastMessageShow(\"No permission!\", True)";
Debug.ShouldStop(262144);
parent.mostCurrent.__c.runVoidMethod ("ToastMessageShow",(Object)(BA.ObjectToCharSequence("No permission!")),(Object)(parent.mostCurrent.__c.getField(true,"True")));
 BA.debugLineNum = 244;BA.debugLine="VideoMode = False";
Debug.ShouldStop(524288);
parent._videomode = parent.mostCurrent.__c.getField(true,"False");
 if (true) break;

case 7:
//C
this.state = 8;
;
 if (true) break;

case 8:
//C
this.state = -1;
;
 BA.debugLineNum = 247;BA.debugLine="SetState(openstate, busystate, VideoMode)";
Debug.ShouldStop(4194304);
_setstate(parent._openstate,parent._busystate,parent._videomode);
 BA.debugLineNum = 248;BA.debugLine="PrepareSurface";
Debug.ShouldStop(8388608);
_preparesurface();
 BA.debugLineNum = 249;BA.debugLine="End Sub";
Debug.ShouldStop(16777216);
if (true) break;

            }
        }
    }
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}
public static void  _activity_permissionresult(RemoteObject _permission,RemoteObject _result) throws Exception{
}
public static RemoteObject  _btnrecord_click() throws Exception{
try {
		Debug.PushSubsStack("btnRecord_Click (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,265);
if (RapidSub.canDelegate("btnrecord_click")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","btnrecord_click");}
RemoteObject _btnrecordtext = RemoteObject.createImmutable("");
 BA.debugLineNum = 265;BA.debugLine="Sub btnRecord_Click";
Debug.ShouldStop(256);
 BA.debugLineNum = 266;BA.debugLine="Dim btnRecordText As String";
Debug.ShouldStop(512);
_btnrecordtext = RemoteObject.createImmutable("");Debug.locals.put("btnRecordText", _btnrecordtext);
 BA.debugLineNum = 270;BA.debugLine="If p_status = 0 Then";
Debug.ShouldStop(8192);
if (RemoteObject.solveBoolean("=",maps._p_status,BA.numberCast(double.class, 0))) { 
 BA.debugLineNum = 271;BA.debugLine="p_status = 1";
Debug.ShouldStop(16384);
maps._p_status = BA.numberCast(int.class, 1);
 BA.debugLineNum = 272;BA.debugLine="SetState(openstate, True, VideoMode)";
Debug.ShouldStop(32768);
_setstate(maps._openstate,maps.mostCurrent.__c.getField(true,"True"),maps._videomode);
 BA.debugLineNum = 273;BA.debugLine="Timer1.Enabled = True";
Debug.ShouldStop(65536);
maps._timer1.runMethod(true,"setEnabled",maps.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 274;BA.debugLine="ToastMessageShow(\"Process Started.\",True)";
Debug.ShouldStop(131072);
maps.mostCurrent.__c.runVoidMethod ("ToastMessageShow",(Object)(BA.ObjectToCharSequence("Process Started.")),(Object)(maps.mostCurrent.__c.getField(true,"True")));
 BA.debugLineNum = 276;BA.debugLine="btnRecordText = Chr(0xF04D)";
Debug.ShouldStop(524288);
_btnrecordtext = BA.ObjectToString(maps.mostCurrent.__c.runMethod(true,"Chr",(Object)(BA.numberCast(int.class, 0xf04d))));Debug.locals.put("btnRecordText", _btnrecordtext);
 BA.debugLineNum = 277;BA.debugLine="btnRecord.Text = btnRecordText";
Debug.ShouldStop(1048576);
maps.mostCurrent._btnrecord.runMethod(true,"setText",BA.ObjectToCharSequence(_btnrecordtext));
 }else {
 BA.debugLineNum = 279;BA.debugLine="p_status = 0";
Debug.ShouldStop(4194304);
maps._p_status = BA.numberCast(int.class, 0);
 BA.debugLineNum = 280;BA.debugLine="SetState(openstate, False, VideoMode)";
Debug.ShouldStop(8388608);
_setstate(maps._openstate,maps.mostCurrent.__c.getField(true,"False"),maps._videomode);
 BA.debugLineNum = 281;BA.debugLine="Timer1.Enabled = False";
Debug.ShouldStop(16777216);
maps._timer1.runMethod(true,"setEnabled",maps.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 282;BA.debugLine="ToastMessageShow(\"Process Stopped.\",True)";
Debug.ShouldStop(33554432);
maps.mostCurrent.__c.runVoidMethod ("ToastMessageShow",(Object)(BA.ObjectToCharSequence("Process Stopped.")),(Object)(maps.mostCurrent.__c.getField(true,"True")));
 BA.debugLineNum = 283;BA.debugLine="btnRecordText = Chr(0xF03D)";
Debug.ShouldStop(67108864);
_btnrecordtext = BA.ObjectToString(maps.mostCurrent.__c.runMethod(true,"Chr",(Object)(BA.numberCast(int.class, 0xf03d))));Debug.locals.put("btnRecordText", _btnrecordtext);
 BA.debugLineNum = 284;BA.debugLine="btnRecord.Text = btnRecordText";
Debug.ShouldStop(134217728);
maps.mostCurrent._btnrecord.runMethod(true,"setText",BA.ObjectToCharSequence(_btnrecordtext));
 };
 BA.debugLineNum = 286;BA.debugLine="End Sub";
Debug.ShouldStop(536870912);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _btnscene_click() throws Exception{
try {
		Debug.PushSubsStack("btnScene_Click (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,397);
if (RapidSub.canDelegate("btnscene_click")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","btnscene_click");}
RemoteObject _scenes = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
RemoteObject _i = RemoteObject.createImmutable(0);
 BA.debugLineNum = 397;BA.debugLine="Sub btnScene_Click";
Debug.ShouldStop(4096);
 BA.debugLineNum = 398;BA.debugLine="Dim scenes As List = cam.SupportedSceneModes";
Debug.ShouldStop(8192);
_scenes = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");
_scenes = maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_getsupportedscenemodes" /*RemoteObject*/ );Debug.locals.put("scenes", _scenes);Debug.locals.put("scenes", _scenes);
 BA.debugLineNum = 399;BA.debugLine="Dim i As Int = scenes.IndexOf(cam.SceneMode)";
Debug.ShouldStop(16384);
_i = _scenes.runMethod(true,"IndexOf",(Object)((maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_getscenemode" /*RemoteObject*/ ))));Debug.locals.put("i", _i);Debug.locals.put("i", _i);
 BA.debugLineNum = 400;BA.debugLine="i = (i + 1) Mod scenes.Size";
Debug.ShouldStop(32768);
_i = RemoteObject.solve(new RemoteObject[] {(RemoteObject.solve(new RemoteObject[] {_i,RemoteObject.createImmutable(1)}, "+",1, 1)),_scenes.runMethod(true,"getSize")}, "%",0, 1);Debug.locals.put("i", _i);
 BA.debugLineNum = 401;BA.debugLine="cam.SceneMode = scenes.Get(i)";
Debug.ShouldStop(65536);
maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_setscenemode" /*RemoteObject*/ ,BA.ObjectToString(_scenes.runMethod(false,"Get",(Object)(_i))));
 BA.debugLineNum = 402;BA.debugLine="btnScene.Text = scenes.Get(i)";
Debug.ShouldStop(131072);
maps.mostCurrent._btnscene.runMethod(true,"setText",BA.ObjectToCharSequence(_scenes.runMethod(false,"Get",(Object)(_i))));
 BA.debugLineNum = 403;BA.debugLine="cam.StartPreview(MyTaskIndex, VideoMode)";
Debug.ShouldStop(262144);
maps.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_startpreview" /*RemoteObject*/ ,(Object)(maps._mytaskindex),(Object)(maps._videomode));
 BA.debugLineNum = 404;BA.debugLine="End Sub";
Debug.ShouldStop(524288);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static void  _capturevideo() throws Exception{
try {
		Debug.PushSubsStack("CaptureVideo (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,288);
if (RapidSub.canDelegate("capturevideo")) { com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","capturevideo"); return;}
ResumableSub_CaptureVideo rsub = new ResumableSub_CaptureVideo(null);
rsub.resume(null, null);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static class ResumableSub_CaptureVideo extends BA.ResumableSub {
public ResumableSub_CaptureVideo(com.mitguide.android.maps parent) {
this.parent = parent;
}
java.util.LinkedHashMap<String, Object> rsLocals = new java.util.LinkedHashMap<String, Object>();
com.mitguide.android.maps parent;
RemoteObject _success = RemoteObject.createImmutable(false);

@Override
public void resume(BA ba, RemoteObject result) throws Exception{
try {
		Debug.PushSubsStack("CaptureVideo (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,288);
Debug.locals = rsLocals;Debug.currentSubFrame.locals = rsLocals;

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 BA.debugLineNum = 289;BA.debugLine="Try";
Debug.ShouldStop(1);
if (true) break;

case 1:
//try
this.state = 12;
this.catchState = 11;
this.state = 3;
if (true) break;

case 3:
//C
this.state = 4;
this.catchState = 11;
 BA.debugLineNum = 290;BA.debugLine="SetState(openstate, True, VideoMode)";
Debug.ShouldStop(2);
_setstate(parent._openstate,parent.mostCurrent.__c.getField(true,"True"),parent._videomode);
 BA.debugLineNum = 291;BA.debugLine="If cam.RecordingVideo = False Then";
Debug.ShouldStop(4);
if (true) break;

case 4:
//if
this.state = 9;
if (RemoteObject.solveBoolean("=",parent.mostCurrent._cam.getField(true,"_recordingvideo" /*RemoteObject*/ ),parent.mostCurrent.__c.getField(true,"False"))) { 
this.state = 6;
}else {
this.state = 8;
}if (true) break;

case 6:
//C
this.state = 9;
 BA.debugLineNum = 292;BA.debugLine="cam.StartVideoRecording (MyTaskIndex)";
Debug.ShouldStop(8);
parent.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_startvideorecording" /*RemoteObject*/ ,(Object)(parent._mytaskindex));
 if (true) break;

case 8:
//C
this.state = 9;
 BA.debugLineNum = 294;BA.debugLine="cam.StopVideoRecording (MyTaskIndex)";
Debug.ShouldStop(32);
parent.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_stopvideorecording" /*RemoteObject*/ ,(Object)(parent._mytaskindex));
 BA.debugLineNum = 295;BA.debugLine="File.Copy(VideoFileDir, \"temp-\" & VideoFileName";
Debug.ShouldStop(64);
parent.mostCurrent.__c.getField(false,"File").runVoidMethod ("Copy",(Object)(parent._videofiledir),(Object)(RemoteObject.concat(RemoteObject.createImmutable("temp-"),parent._videofilename)),(Object)(parent._videofiledir),(Object)(parent._videofilename));
 BA.debugLineNum = 296;BA.debugLine="ToastMessageShow($\"Video file saved: $1.2{File.";
Debug.ShouldStop(128);
parent.mostCurrent.__c.runVoidMethod ("ToastMessageShow",(Object)(BA.ObjectToCharSequence((RemoteObject.concat(RemoteObject.createImmutable("Video file saved: "),parent.mostCurrent.__c.runMethod(true,"SmartStringFormatter",(Object)(BA.ObjectToString("1.2")),(Object)((RemoteObject.solve(new RemoteObject[] {parent.mostCurrent.__c.getField(false,"File").runMethod(true,"Size",(Object)(parent._videofiledir),(Object)(parent._videofilename)),RemoteObject.createImmutable(1024),RemoteObject.createImmutable(1024)}, "//",0, 0)))),RemoteObject.createImmutable(" MB"))))),(Object)(parent.mostCurrent.__c.getField(true,"True")));
 BA.debugLineNum = 297;BA.debugLine="Wait For (PrepareSurface) Complete (Success As";
Debug.ShouldStop(256);
parent.mostCurrent.__c.runVoidMethod ("WaitFor","complete", maps.processBA, anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this, "maps", "capturevideo"), _preparesurface());
this.state = 13;
return;
case 13:
//C
this.state = 9;
_success = (RemoteObject) result.getArrayElement(true,RemoteObject.createImmutable(0));Debug.locals.put("Success", _success);
;
 BA.debugLineNum = 298;BA.debugLine="SetState(openstate, False, VideoMode)";
Debug.ShouldStop(512);
_setstate(parent._openstate,parent.mostCurrent.__c.getField(true,"False"),parent._videomode);
 if (true) break;

case 9:
//C
this.state = 12;
;
 Debug.CheckDeviceExceptions();
if (true) break;

case 11:
//C
this.state = 12;
this.catchState = 0;
 BA.debugLineNum = 302;BA.debugLine="HandleError(LastException)";
Debug.ShouldStop(8192);
_handleerror(parent.mostCurrent.__c.runMethod(false,"LastException",maps.mostCurrent.activityBA));
 if (true) break;
if (true) break;

case 12:
//C
this.state = -1;
this.catchState = 0;
;
 BA.debugLineNum = 304;BA.debugLine="End Sub";
Debug.ShouldStop(32768);
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
BA.rdebugUtils.runVoidMethod("setLastException",maps.processBA, e0.toString());}
            }
        }
    }
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}
public static void  _complete(RemoteObject _success) throws Exception{
}
public static RemoteObject  _createtables() throws Exception{
try {
		Debug.PushSubsStack("CreateTables (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,144);
if (RapidSub.canDelegate("createtables")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","createtables");}
 BA.debugLineNum = 144;BA.debugLine="Sub CreateTables";
Debug.ShouldStop(32768);
 BA.debugLineNum = 145;BA.debugLine="SQL1.ExecNonQuery(\"CREATE TABLE IF NOT EXISTS tab";
Debug.ShouldStop(65536);
maps._sql1.runVoidMethod ("ExecNonQuery",(Object)(RemoteObject.createImmutable("CREATE TABLE IF NOT EXISTS table1 (mob1 TEXT)")));
 BA.debugLineNum = 146;BA.debugLine="SQL1.ExecNonQuery(\"CREATE TABLE IF NOT EXISTS tab";
Debug.ShouldStop(131072);
maps._sql1.runVoidMethod ("ExecNonQuery",(Object)(RemoteObject.createImmutable("CREATE TABLE IF NOT EXISTS table2 (mob2 TEXT)")));
 BA.debugLineNum = 149;BA.debugLine="End Sub";
Debug.ShouldStop(1048576);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _delay(RemoteObject _nmillisecond) throws Exception{
try {
		Debug.PushSubsStack("Delay (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,461);
if (RapidSub.canDelegate("delay")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","delay", _nmillisecond);}
RemoteObject _nbegintime = RemoteObject.createImmutable(0L);
RemoteObject _nendtime = RemoteObject.createImmutable(0L);
Debug.locals.put("nMilliSecond", _nmillisecond);
 BA.debugLineNum = 461;BA.debugLine="Sub Delay(nMilliSecond As Long)";
Debug.ShouldStop(4096);
 BA.debugLineNum = 462;BA.debugLine="Dim nBeginTime As Long";
Debug.ShouldStop(8192);
_nbegintime = RemoteObject.createImmutable(0L);Debug.locals.put("nBeginTime", _nbegintime);
 BA.debugLineNum = 463;BA.debugLine="Dim nEndTime As Long";
Debug.ShouldStop(16384);
_nendtime = RemoteObject.createImmutable(0L);Debug.locals.put("nEndTime", _nendtime);
 BA.debugLineNum = 464;BA.debugLine="nEndTime = DateTime.Now + nMilliSecond";
Debug.ShouldStop(32768);
_nendtime = RemoteObject.solve(new RemoteObject[] {maps.mostCurrent.__c.getField(false,"DateTime").runMethod(true,"getNow"),_nmillisecond}, "+",1, 2);Debug.locals.put("nEndTime", _nendtime);
 BA.debugLineNum = 465;BA.debugLine="nBeginTime = DateTime.Now";
Debug.ShouldStop(65536);
_nbegintime = maps.mostCurrent.__c.getField(false,"DateTime").runMethod(true,"getNow");Debug.locals.put("nBeginTime", _nbegintime);
 BA.debugLineNum = 466;BA.debugLine="Do While nBeginTime < nEndTime";
Debug.ShouldStop(131072);
while (RemoteObject.solveBoolean("<",_nbegintime,BA.numberCast(double.class, _nendtime))) {
 BA.debugLineNum = 467;BA.debugLine="nBeginTime = DateTime.Now";
Debug.ShouldStop(262144);
_nbegintime = maps.mostCurrent.__c.getField(false,"DateTime").runMethod(true,"getNow");Debug.locals.put("nBeginTime", _nbegintime);
 BA.debugLineNum = 468;BA.debugLine="Log(nBeginTime)";
Debug.ShouldStop(524288);
maps.mostCurrent.__c.runVoidMethod ("LogImpl","73211271",BA.NumberToString(_nbegintime),0);
 BA.debugLineNum = 469;BA.debugLine="If nEndTime < nBeginTime Then";
Debug.ShouldStop(1048576);
if (RemoteObject.solveBoolean("<",_nendtime,BA.numberCast(double.class, _nbegintime))) { 
 BA.debugLineNum = 470;BA.debugLine="Return";
Debug.ShouldStop(2097152);
if (true) return RemoteObject.createImmutable("");
 };
 BA.debugLineNum = 472;BA.debugLine="DoEvents";
Debug.ShouldStop(8388608);
maps.mostCurrent.__c.runVoidMethodAndSync ("DoEvents");
 }
;
 BA.debugLineNum = 474;BA.debugLine="End Sub";
Debug.ShouldStop(33554432);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _fv1_face_found(RemoteObject _landmarks) throws Exception{
try {
		Debug.PushSubsStack("fv1_face_found (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,342);
if (RapidSub.canDelegate("fv1_face_found")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","fv1_face_found", _landmarks);}
RemoteObject _mylist = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
RemoteObject _i = RemoteObject.createImmutable(0);
RemoteObject _left_eye = RemoteObject.createImmutable(0);
RemoteObject _right_eye = RemoteObject.createImmutable(0);
RemoteObject _happy = RemoteObject.createImmutable(0);
RemoteObject _lm = RemoteObject.createImmutable(0);
Debug.locals.put("LandMarks", _landmarks);
 BA.debugLineNum = 342;BA.debugLine="Sub fv1_face_found(LandMarks As Object)";
Debug.ShouldStop(2097152);
 BA.debugLineNum = 344;BA.debugLine="Dim mylist As List";
Debug.ShouldStop(8388608);
_mylist = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");Debug.locals.put("mylist", _mylist);
 BA.debugLineNum = 345;BA.debugLine="mylist = LandMarks";
Debug.ShouldStop(16777216);
_mylist.setObject(_landmarks);
 BA.debugLineNum = 346;BA.debugLine="Dim i As Int";
Debug.ShouldStop(33554432);
_i = RemoteObject.createImmutable(0);Debug.locals.put("i", _i);
 BA.debugLineNum = 347;BA.debugLine="Dim left_eye As Int";
Debug.ShouldStop(67108864);
_left_eye = RemoteObject.createImmutable(0);Debug.locals.put("left_eye", _left_eye);
 BA.debugLineNum = 348;BA.debugLine="Dim right_eye As Int";
Debug.ShouldStop(134217728);
_right_eye = RemoteObject.createImmutable(0);Debug.locals.put("right_eye", _right_eye);
 BA.debugLineNum = 349;BA.debugLine="Dim happy As Int";
Debug.ShouldStop(268435456);
_happy = RemoteObject.createImmutable(0);Debug.locals.put("happy", _happy);
 BA.debugLineNum = 350;BA.debugLine="Dim lm As Int = sf.Val(mylist.Get(mylist.Size - 1";
Debug.ShouldStop(536870912);
_lm = BA.numberCast(int.class, maps.mostCurrent._sf.runMethod(true,"_vvvvv1",(Object)(BA.ObjectToString(_mylist.runMethod(false,"Get",(Object)(RemoteObject.solve(new RemoteObject[] {_mylist.runMethod(true,"getSize"),RemoteObject.createImmutable(1)}, "-",1, 1)))))));Debug.locals.put("lm", _lm);Debug.locals.put("lm", _lm);
 BA.debugLineNum = 351;BA.debugLine="lv1.AddSingleLine(\"face ID = \" & mylist.Get(mylis";
Debug.ShouldStop(1073741824);
maps.mostCurrent._lv1.runVoidMethod ("AddSingleLine",(Object)(BA.ObjectToCharSequence(RemoteObject.concat(RemoteObject.createImmutable("face ID = "),_mylist.runMethod(false,"Get",(Object)(RemoteObject.solve(new RemoteObject[] {_mylist.runMethod(true,"getSize"),RemoteObject.createImmutable(2)}, "-",1, 1)))))));
 BA.debugLineNum = 352;BA.debugLine="For i = 0 To lm - 1";
Debug.ShouldStop(-2147483648);
{
final int step9 = 1;
final int limit9 = RemoteObject.solve(new RemoteObject[] {_lm,RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
_i = BA.numberCast(int.class, 0) ;
for (;(step9 > 0 && _i.<Integer>get().intValue() <= limit9) || (step9 < 0 && _i.<Integer>get().intValue() >= limit9) ;_i = RemoteObject.createImmutable((int)(0 + _i.<Integer>get().intValue() + step9))  ) {
Debug.locals.put("i", _i);
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 355;BA.debugLine="Log (mylist.Get(i+2))";
Debug.ShouldStop(4);
maps.mostCurrent.__c.runVoidMethod ("LogImpl","72686989",BA.ObjectToString(_mylist.runMethod(false,"Get",(Object)(RemoteObject.solve(new RemoteObject[] {_i,RemoteObject.createImmutable(2)}, "+",1, 1)))),0);
 BA.debugLineNum = 356;BA.debugLine="Log (mylist.Get(i+3))";
Debug.ShouldStop(8);
maps.mostCurrent.__c.runVoidMethod ("LogImpl","72686990",BA.ObjectToString(_mylist.runMethod(false,"Get",(Object)(RemoteObject.solve(new RemoteObject[] {_i,RemoteObject.createImmutable(3)}, "+",1, 1)))),0);
 BA.debugLineNum = 357;BA.debugLine="Log (mylist.Get(i+4))";
Debug.ShouldStop(16);
maps.mostCurrent.__c.runVoidMethod ("LogImpl","72686991",BA.ObjectToString(_mylist.runMethod(false,"Get",(Object)(RemoteObject.solve(new RemoteObject[] {_i,RemoteObject.createImmutable(4)}, "+",1, 1)))),0);
 BA.debugLineNum = 358;BA.debugLine="Log (mylist.Get(i+6))";
Debug.ShouldStop(32);
maps.mostCurrent.__c.runVoidMethod ("LogImpl","72686992",BA.ObjectToString(_mylist.runMethod(false,"Get",(Object)(RemoteObject.solve(new RemoteObject[] {_i,RemoteObject.createImmutable(6)}, "+",1, 1)))),0);
 BA.debugLineNum = 359;BA.debugLine="left_eye = mylist.Get(i+2) * 100";
Debug.ShouldStop(64);
_left_eye = BA.numberCast(int.class, RemoteObject.solve(new RemoteObject[] {BA.numberCast(double.class, _mylist.runMethod(false,"Get",(Object)(RemoteObject.solve(new RemoteObject[] {_i,RemoteObject.createImmutable(2)}, "+",1, 1)))),RemoteObject.createImmutable(100)}, "*",0, 0));Debug.locals.put("left_eye", _left_eye);
 BA.debugLineNum = 360;BA.debugLine="right_eye = mylist.Get(i+3) * 100";
Debug.ShouldStop(128);
_right_eye = BA.numberCast(int.class, RemoteObject.solve(new RemoteObject[] {BA.numberCast(double.class, _mylist.runMethod(false,"Get",(Object)(RemoteObject.solve(new RemoteObject[] {_i,RemoteObject.createImmutable(3)}, "+",1, 1)))),RemoteObject.createImmutable(100)}, "*",0, 0));Debug.locals.put("right_eye", _right_eye);
 BA.debugLineNum = 361;BA.debugLine="happy = mylist.Get(i+4) * 100";
Debug.ShouldStop(256);
_happy = BA.numberCast(int.class, RemoteObject.solve(new RemoteObject[] {BA.numberCast(double.class, _mylist.runMethod(false,"Get",(Object)(RemoteObject.solve(new RemoteObject[] {_i,RemoteObject.createImmutable(4)}, "+",1, 1)))),RemoteObject.createImmutable(100)}, "*",0, 0));Debug.locals.put("happy", _happy);
 BA.debugLineNum = 362;BA.debugLine="Log (left_eye)";
Debug.ShouldStop(512);
maps.mostCurrent.__c.runVoidMethod ("LogImpl","72686996",BA.NumberToString(_left_eye),0);
 BA.debugLineNum = 363;BA.debugLine="Log (right_eye)";
Debug.ShouldStop(1024);
maps.mostCurrent.__c.runVoidMethod ("LogImpl","72686997",BA.NumberToString(_right_eye),0);
 BA.debugLineNum = 364;BA.debugLine="Log (happy)";
Debug.ShouldStop(2048);
maps.mostCurrent.__c.runVoidMethod ("LogImpl","72686998",BA.NumberToString(_happy),0);
 BA.debugLineNum = 365;BA.debugLine="Label2.Text = left_eye & \" %\"";
Debug.ShouldStop(4096);
maps.mostCurrent._label2.runMethod(true,"setText",BA.ObjectToCharSequence(RemoteObject.concat(_left_eye,RemoteObject.createImmutable(" %"))));
 BA.debugLineNum = 366;BA.debugLine="Label3.Text = right_eye & \" %\"";
Debug.ShouldStop(8192);
maps.mostCurrent._label3.runMethod(true,"setText",BA.ObjectToCharSequence(RemoteObject.concat(_right_eye,RemoteObject.createImmutable(" %"))));
 BA.debugLineNum = 367;BA.debugLine="Label9.Text = mylist.Get(i+6)";
Debug.ShouldStop(16384);
maps.mostCurrent._label9.runMethod(true,"setText",BA.ObjectToCharSequence(_mylist.runMethod(false,"Get",(Object)(RemoteObject.solve(new RemoteObject[] {_i,RemoteObject.createImmutable(6)}, "+",1, 1)))));
 BA.debugLineNum = 368;BA.debugLine="Label12.Text = happy & \" %\"";
Debug.ShouldStop(32768);
maps.mostCurrent._label12.runMethod(true,"setText",BA.ObjectToCharSequence(RemoteObject.concat(_happy,RemoteObject.createImmutable(" %"))));
 BA.debugLineNum = 369;BA.debugLine="If (left_eye < 50) Or (right_eye < 50) Then";
Debug.ShouldStop(65536);
if (RemoteObject.solveBoolean(".",BA.ObjectToBoolean((RemoteObject.solveBoolean("<",_left_eye,BA.numberCast(double.class, 50))))) || RemoteObject.solveBoolean(".",BA.ObjectToBoolean((RemoteObject.solveBoolean("<",_right_eye,BA.numberCast(double.class, 50)))))) { 
 BA.debugLineNum = 370;BA.debugLine="p_drowsiness = p_drowsiness + 1";
Debug.ShouldStop(131072);
maps._p_drowsiness = RemoteObject.solve(new RemoteObject[] {maps._p_drowsiness,RemoteObject.createImmutable(1)}, "+",1, 1);
 BA.debugLineNum = 371;BA.debugLine="If p_drowsiness = 2 Then";
Debug.ShouldStop(262144);
if (RemoteObject.solveBoolean("=",maps._p_drowsiness,BA.numberCast(double.class, 2))) { 
 BA.debugLineNum = 372;BA.debugLine="Label1.Text = \"Drowsiness Status: Detected\"";
Debug.ShouldStop(524288);
maps.mostCurrent._label1.runMethod(true,"setText",BA.ObjectToCharSequence("Drowsiness Status: Detected"));
 BA.debugLineNum = 373;BA.debugLine="TTS1.Speak(\"Alert! Drowsiness Detected!!!\",Fals";
Debug.ShouldStop(1048576);
maps._tts1.runVoidMethod ("Speak",(Object)(BA.ObjectToString("Alert! Drowsiness Detected!!!")),(Object)(maps.mostCurrent.__c.getField(true,"False")));
 }else {
 BA.debugLineNum = 375;BA.debugLine="Label1.Text = \"Drowsiness Status: Not Detected\"";
Debug.ShouldStop(4194304);
maps.mostCurrent._label1.runMethod(true,"setText",BA.ObjectToCharSequence("Drowsiness Status: Not Detected"));
 };
 }else {
 BA.debugLineNum = 378;BA.debugLine="p_drowsiness = 0";
Debug.ShouldStop(33554432);
maps._p_drowsiness = BA.numberCast(int.class, 0);
 BA.debugLineNum = 379;BA.debugLine="Label1.Text = \"Drowsiness Status: Not Detected\"";
Debug.ShouldStop(67108864);
maps.mostCurrent._label1.runMethod(true,"setText",BA.ObjectToCharSequence("Drowsiness Status: Not Detected"));
 };
 BA.debugLineNum = 382;BA.debugLine="End Sub";
Debug.ShouldStop(536870912);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _globals() throws Exception{
 //BA.debugLineNum = 31;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 34;BA.debugLine="Private cam As CamEx2";
maps.mostCurrent._cam = RemoteObject.createNew ("com.mitguide.android.camex2");
 //BA.debugLineNum = 35;BA.debugLine="Private pnlCamera As Panel";
maps.mostCurrent._pnlcamera = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");
 //BA.debugLineNum = 36;BA.debugLine="Private pnlPicture As Panel";
maps.mostCurrent._pnlpicture = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");
 //BA.debugLineNum = 37;BA.debugLine="Private pnlBackground As Panel";
maps.mostCurrent._pnlbackground = RemoteObject.createNew ("anywheresoftware.b4a.objects.PanelWrapper");
 //BA.debugLineNum = 38;BA.debugLine="Private btnEffects As Button";
maps.mostCurrent._btneffects = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 39;BA.debugLine="Private btnScene As Button";
maps.mostCurrent._btnscene = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 40;BA.debugLine="Private buttons As List";
maps.mostCurrent._buttons = RemoteObject.createNew ("anywheresoftware.b4a.objects.collections.List");
 //BA.debugLineNum = 41;BA.debugLine="Private btnAutoExposure As Button";
maps.mostCurrent._btnautoexposure = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 42;BA.debugLine="Private btnFocus As Button";
maps.mostCurrent._btnfocus = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 43;BA.debugLine="Private ProgressBar1 As ProgressBar";
maps.mostCurrent._progressbar1 = RemoteObject.createNew ("anywheresoftware.b4a.objects.ProgressBarWrapper");
 //BA.debugLineNum = 44;BA.debugLine="Private openstate, busystate As Boolean";
maps._openstate = RemoteObject.createImmutable(false);
maps._busystate = RemoteObject.createImmutable(false);
 //BA.debugLineNum = 45;BA.debugLine="Private btnRecord As Button";
maps.mostCurrent._btnrecord = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 46;BA.debugLine="Private btnMode As Button";
maps.mostCurrent._btnmode = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 47;BA.debugLine="Private btnCamera As Button";
maps.mostCurrent._btncamera = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
 //BA.debugLineNum = 48;BA.debugLine="Private barZoom As SeekBar";
maps.mostCurrent._barzoom = RemoteObject.createNew ("anywheresoftware.b4a.objects.SeekBarWrapper");
 //BA.debugLineNum = 49;BA.debugLine="Dim bm As Bitmap";
maps.mostCurrent._bm = RemoteObject.createNew ("anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper");
 //BA.debugLineNum = 51;BA.debugLine="Private fv1 As AndroidVisionFaceView";
maps.mostCurrent._fv1 = RemoteObject.createNew ("photowrapper.photoWrapper");
 //BA.debugLineNum = 52;BA.debugLine="Private lv1 As ListView";
maps.mostCurrent._lv1 = RemoteObject.createNew ("anywheresoftware.b4a.objects.ListViewWrapper");
 //BA.debugLineNum = 53;BA.debugLine="Dim sf As StringFunctions";
maps.mostCurrent._sf = RemoteObject.createNew ("ADR.stringdemo.stringfunctions");
 //BA.debugLineNum = 54;BA.debugLine="Private Label1 As Label";
maps.mostCurrent._label1 = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 55;BA.debugLine="Private Label2 As Label";
maps.mostCurrent._label2 = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 56;BA.debugLine="Private Label3 As Label";
maps.mostCurrent._label3 = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 57;BA.debugLine="Private Label10 As Label";
maps.mostCurrent._label10 = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 58;BA.debugLine="Private Label13 As Label";
maps.mostCurrent._label13 = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 59;BA.debugLine="Private Label9 As Label";
maps.mostCurrent._label9 = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 60;BA.debugLine="Private Label12 As Label";
maps.mostCurrent._label12 = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 61;BA.debugLine="Private Label14 As Label";
maps.mostCurrent._label14 = RemoteObject.createNew ("anywheresoftware.b4a.objects.LabelWrapper");
 //BA.debugLineNum = 62;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _handleerror(RemoteObject _error) throws Exception{
try {
		Debug.PushSubsStack("HandleError (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,306);
if (RapidSub.canDelegate("handleerror")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","handleerror", _error);}
Debug.locals.put("Error", _error);
 BA.debugLineNum = 306;BA.debugLine="Sub HandleError (Error As Exception)";
Debug.ShouldStop(131072);
 BA.debugLineNum = 307;BA.debugLine="Log(\"Error: \" & Error)";
Debug.ShouldStop(262144);
maps.mostCurrent.__c.runVoidMethod ("LogImpl","72555905",RemoteObject.concat(RemoteObject.createImmutable("Error: "),_error),0);
 BA.debugLineNum = 308;BA.debugLine="ToastMessageShow(Error, True)";
Debug.ShouldStop(524288);
maps.mostCurrent.__c.runVoidMethod ("ToastMessageShow",(Object)(BA.ObjectToCharSequence(_error.getObject())),(Object)(maps.mostCurrent.__c.getField(true,"True")));
 BA.debugLineNum = 309;BA.debugLine="OpenCamera(frontCamera)";
Debug.ShouldStop(1048576);
_opencamera(maps._frontcamera);
 BA.debugLineNum = 310;BA.debugLine="End Sub";
Debug.ShouldStop(2097152);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _logtable1() throws Exception{
try {
		Debug.PushSubsStack("LogTable1 (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,116);
if (RapidSub.canDelegate("logtable1")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","logtable1");}
RemoteObject _cursor1 = RemoteObject.declareNull("anywheresoftware.b4a.sql.SQL.CursorWrapper");
int _i = 0;
 BA.debugLineNum = 116;BA.debugLine="Sub LogTable1";
Debug.ShouldStop(524288);
 BA.debugLineNum = 117;BA.debugLine="Dim Cursor1 As Cursor";
Debug.ShouldStop(1048576);
_cursor1 = RemoteObject.createNew ("anywheresoftware.b4a.sql.SQL.CursorWrapper");Debug.locals.put("Cursor1", _cursor1);
 BA.debugLineNum = 118;BA.debugLine="Cursor1 = SQL1.ExecQuery(\"SELECT mob1 FROM table1";
Debug.ShouldStop(2097152);
_cursor1.setObject(maps._sql1.runMethod(false,"ExecQuery",(Object)(RemoteObject.createImmutable("SELECT mob1 FROM table1"))));
 BA.debugLineNum = 119;BA.debugLine="For i = 0 To Cursor1.RowCount - 1";
Debug.ShouldStop(4194304);
{
final int step3 = 1;
final int limit3 = RemoteObject.solve(new RemoteObject[] {_cursor1.runMethod(true,"getRowCount"),RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
_i = 0 ;
for (;(step3 > 0 && _i <= limit3) || (step3 < 0 && _i >= limit3) ;_i = ((int)(0 + _i + step3))  ) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 120;BA.debugLine="Cursor1.Position = i";
Debug.ShouldStop(8388608);
_cursor1.runMethod(true,"setPosition",BA.numberCast(int.class, _i));
 BA.debugLineNum = 121;BA.debugLine="Log(\"************************\")";
Debug.ShouldStop(16777216);
maps.mostCurrent.__c.runVoidMethod ("LogImpl","71507333",RemoteObject.createImmutable("************************"),0);
 BA.debugLineNum = 122;BA.debugLine="Log(Cursor1.GetString(\"mob1\"))";
Debug.ShouldStop(33554432);
maps.mostCurrent.__c.runVoidMethod ("LogImpl","71507334",_cursor1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("mob1"))),0);
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 126;BA.debugLine="number1 = Cursor1.GetString(\"mob1\")";
Debug.ShouldStop(536870912);
maps._number1 = _cursor1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("mob1")));
 BA.debugLineNum = 127;BA.debugLine="Cursor1.Close";
Debug.ShouldStop(1073741824);
_cursor1.runVoidMethod ("Close");
 BA.debugLineNum = 128;BA.debugLine="End Sub";
Debug.ShouldStop(-2147483648);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _logtable2() throws Exception{
try {
		Debug.PushSubsStack("LogTable2 (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,130);
if (RapidSub.canDelegate("logtable2")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","logtable2");}
RemoteObject _cursor1 = RemoteObject.declareNull("anywheresoftware.b4a.sql.SQL.CursorWrapper");
int _i = 0;
 BA.debugLineNum = 130;BA.debugLine="Sub LogTable2";
Debug.ShouldStop(2);
 BA.debugLineNum = 131;BA.debugLine="Dim Cursor1 As Cursor";
Debug.ShouldStop(4);
_cursor1 = RemoteObject.createNew ("anywheresoftware.b4a.sql.SQL.CursorWrapper");Debug.locals.put("Cursor1", _cursor1);
 BA.debugLineNum = 132;BA.debugLine="Cursor1 = SQL1.ExecQuery(\"SELECT mob2 FROM table2";
Debug.ShouldStop(8);
_cursor1.setObject(maps._sql1.runMethod(false,"ExecQuery",(Object)(RemoteObject.createImmutable("SELECT mob2 FROM table2"))));
 BA.debugLineNum = 133;BA.debugLine="For i = 0 To Cursor1.RowCount - 1";
Debug.ShouldStop(16);
{
final int step3 = 1;
final int limit3 = RemoteObject.solve(new RemoteObject[] {_cursor1.runMethod(true,"getRowCount"),RemoteObject.createImmutable(1)}, "-",1, 1).<Integer>get().intValue();
_i = 0 ;
for (;(step3 > 0 && _i <= limit3) || (step3 < 0 && _i >= limit3) ;_i = ((int)(0 + _i + step3))  ) {
Debug.locals.put("i", _i);
 BA.debugLineNum = 134;BA.debugLine="Cursor1.Position = i";
Debug.ShouldStop(32);
_cursor1.runMethod(true,"setPosition",BA.numberCast(int.class, _i));
 BA.debugLineNum = 135;BA.debugLine="Log(\"************************\")";
Debug.ShouldStop(64);
maps.mostCurrent.__c.runVoidMethod ("LogImpl","71572869",RemoteObject.createImmutable("************************"),0);
 BA.debugLineNum = 136;BA.debugLine="Log(Cursor1.GetString(\"mob2\"))";
Debug.ShouldStop(128);
maps.mostCurrent.__c.runVoidMethod ("LogImpl","71572870",_cursor1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("mob2"))),0);
 }
}Debug.locals.put("i", _i);
;
 BA.debugLineNum = 140;BA.debugLine="number2 = Cursor1.GetString(\"mob2\")";
Debug.ShouldStop(2048);
maps._number2 = _cursor1.runMethod(true,"GetString",(Object)(RemoteObject.createImmutable("mob2")));
 BA.debugLineNum = 141;BA.debugLine="Cursor1.Close";
Debug.ShouldStop(4096);
_cursor1.runVoidMethod ("Close");
 BA.debugLineNum = 142;BA.debugLine="End Sub";
Debug.ShouldStop(8192);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _mnunavi_click() throws Exception{
try {
		Debug.PushSubsStack("mnunavi_Click (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,167);
if (RapidSub.canDelegate("mnunavi_click")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","mnunavi_click");}
 BA.debugLineNum = 167;BA.debugLine="Sub mnunavi_Click";
Debug.ShouldStop(64);
 BA.debugLineNum = 175;BA.debugLine="End Sub";
Debug.ShouldStop(16384);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _mnunumber1_click() throws Exception{
try {
		Debug.PushSubsStack("mnunumber1_Click (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,151);
if (RapidSub.canDelegate("mnunumber1_click")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","mnunumber1_click");}
 BA.debugLineNum = 151;BA.debugLine="Sub mnunumber1_Click";
Debug.ShouldStop(4194304);
 BA.debugLineNum = 153;BA.debugLine="End Sub";
Debug.ShouldStop(16777216);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _mnuschool_click() throws Exception{
try {
		Debug.PushSubsStack("mnuschool_Click (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,162);
if (RapidSub.canDelegate("mnuschool_click")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","mnuschool_click");}
 BA.debugLineNum = 162;BA.debugLine="Sub mnuschool_Click";
Debug.ShouldStop(2);
 BA.debugLineNum = 165;BA.debugLine="End Sub";
Debug.ShouldStop(16);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static void  _opencamera(RemoteObject _front) throws Exception{
try {
		Debug.PushSubsStack("OpenCamera (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,196);
if (RapidSub.canDelegate("opencamera")) { com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","opencamera", _front); return;}
ResumableSub_OpenCamera rsub = new ResumableSub_OpenCamera(null,_front);
rsub.resume(null, null);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static class ResumableSub_OpenCamera extends BA.ResumableSub {
public ResumableSub_OpenCamera(com.mitguide.android.maps parent,RemoteObject _front) {
this.parent = parent;
this._front = _front;
}
java.util.LinkedHashMap<String, Object> rsLocals = new java.util.LinkedHashMap<String, Object>();
com.mitguide.android.maps parent;
RemoteObject _front;
RemoteObject _permission = RemoteObject.createImmutable("");
RemoteObject _result = RemoteObject.createImmutable(false);
RemoteObject _taskindex = RemoteObject.createImmutable(0);
RemoteObject _success = RemoteObject.createImmutable(false);

@Override
public void resume(BA ba, RemoteObject result) throws Exception{
try {
		Debug.PushSubsStack("OpenCamera (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,196);
Debug.locals = rsLocals;Debug.currentSubFrame.locals = rsLocals;

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
Debug.locals.put("front", _front);
 BA.debugLineNum = 197;BA.debugLine="rp.CheckAndRequest(rp.PERMISSION_CAMERA)";
Debug.ShouldStop(16);
parent._rp.runVoidMethod ("CheckAndRequest",maps.processBA,(Object)(parent._rp.getField(true,"PERMISSION_CAMERA")));
 BA.debugLineNum = 198;BA.debugLine="Wait For Activity_PermissionResult (Permission As";
Debug.ShouldStop(32);
parent.mostCurrent.__c.runVoidMethod ("WaitFor","activity_permissionresult", maps.processBA, anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this, "maps", "opencamera"), null);
this.state = 13;
return;
case 13:
//C
this.state = 1;
_permission = (RemoteObject) result.getArrayElement(true,RemoteObject.createImmutable(0));Debug.locals.put("Permission", _permission);
_result = (RemoteObject) result.getArrayElement(true,RemoteObject.createImmutable(1));Debug.locals.put("Result", _result);
;
 BA.debugLineNum = 199;BA.debugLine="If Result = False Then";
Debug.ShouldStop(64);
if (true) break;

case 1:
//if
this.state = 4;
if (RemoteObject.solveBoolean("=",_result,parent.mostCurrent.__c.getField(true,"False"))) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 BA.debugLineNum = 200;BA.debugLine="ToastMessageShow(\"No permission!\", True)";
Debug.ShouldStop(128);
parent.mostCurrent.__c.runVoidMethod ("ToastMessageShow",(Object)(BA.ObjectToCharSequence("No permission!")),(Object)(parent.mostCurrent.__c.getField(true,"True")));
 BA.debugLineNum = 201;BA.debugLine="Return";
Debug.ShouldStop(256);
if (true) return ;
 if (true) break;

case 4:
//C
this.state = 5;
;
 BA.debugLineNum = 204;BA.debugLine="SetState(False, False, VideoMode)";
Debug.ShouldStop(2048);
_setstate(parent.mostCurrent.__c.getField(true,"False"),parent.mostCurrent.__c.getField(true,"False"),parent._videomode);
 BA.debugLineNum = 205;BA.debugLine="Wait For (cam.OpenCamera(front)) Complete (TaskIn";
Debug.ShouldStop(4096);
parent.mostCurrent.__c.runVoidMethod ("WaitFor","complete", maps.processBA, anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this, "maps", "opencamera"), parent.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_opencamera" /*RemoteObject*/ ,(Object)(_front)));
this.state = 14;
return;
case 14:
//C
this.state = 5;
_taskindex = (RemoteObject) result.getArrayElement(true,RemoteObject.createImmutable(0));Debug.locals.put("TaskIndex", _taskindex);
;
 BA.debugLineNum = 206;BA.debugLine="If TaskIndex > 0 Then";
Debug.ShouldStop(8192);
if (true) break;

case 5:
//if
this.state = 8;
if (RemoteObject.solveBoolean(">",_taskindex,BA.numberCast(double.class, 0))) { 
this.state = 7;
}if (true) break;

case 7:
//C
this.state = 8;
 BA.debugLineNum = 207;BA.debugLine="MyTaskIndex = TaskIndex 'hold this index. It wil";
Debug.ShouldStop(16384);
parent._mytaskindex = _taskindex;
 BA.debugLineNum = 208;BA.debugLine="Wait For(PrepareSurface) Complete (Success As Bo";
Debug.ShouldStop(32768);
parent.mostCurrent.__c.runVoidMethod ("WaitFor","complete", maps.processBA, anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this, "maps", "opencamera"), _preparesurface());
this.state = 15;
return;
case 15:
//C
this.state = 8;
_success = (RemoteObject) result.getArrayElement(true,RemoteObject.createImmutable(0));Debug.locals.put("Success", _success);
;
 if (true) break;

case 8:
//C
this.state = 9;
;
 BA.debugLineNum = 210;BA.debugLine="Log(\"Start success: \" & Success)";
Debug.ShouldStop(131072);
parent.mostCurrent.__c.runVoidMethod ("LogImpl","72097166",RemoteObject.concat(RemoteObject.createImmutable("Start success: "),_success),0);
 BA.debugLineNum = 211;BA.debugLine="SetState(Success, False, VideoMode)";
Debug.ShouldStop(262144);
_setstate(_success,parent.mostCurrent.__c.getField(true,"False"),parent._videomode);
 BA.debugLineNum = 212;BA.debugLine="If Success = False Then";
Debug.ShouldStop(524288);
if (true) break;

case 9:
//if
this.state = 12;
if (RemoteObject.solveBoolean("=",_success,parent.mostCurrent.__c.getField(true,"False"))) { 
this.state = 11;
}if (true) break;

case 11:
//C
this.state = 12;
 BA.debugLineNum = 213;BA.debugLine="ToastMessageShow(\"Failed to open camera\", True)";
Debug.ShouldStop(1048576);
parent.mostCurrent.__c.runVoidMethod ("ToastMessageShow",(Object)(BA.ObjectToCharSequence("Failed to open camera")),(Object)(parent.mostCurrent.__c.getField(true,"True")));
 if (true) break;

case 12:
//C
this.state = -1;
;
 BA.debugLineNum = 215;BA.debugLine="End Sub";
Debug.ShouldStop(4194304);
if (true) break;

            }
        }
    }
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}
public static RemoteObject  _pnlpicture_click() throws Exception{
try {
		Debug.PushSubsStack("pnlPicture_Click (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,384);
if (RapidSub.canDelegate("pnlpicture_click")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","pnlpicture_click");}
 BA.debugLineNum = 384;BA.debugLine="Sub pnlPicture_Click";
Debug.ShouldStop(-2147483648);
 BA.debugLineNum = 385;BA.debugLine="pnlBackground.Visible = False";
Debug.ShouldStop(1);
maps.mostCurrent._pnlbackground.runMethod(true,"setVisible",maps.mostCurrent.__c.getField(true,"False"));
 BA.debugLineNum = 386;BA.debugLine="End Sub";
Debug.ShouldStop(2);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _preparesurface() throws Exception{
try {
		Debug.PushSubsStack("PrepareSurface (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,216);
if (RapidSub.canDelegate("preparesurface")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","preparesurface");}
ResumableSub_PrepareSurface rsub = new ResumableSub_PrepareSurface(null);
rsub.remoteResumableSub = anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSubForFilter();
rsub.resume(null, null);
return RemoteObject.declareNull("anywheresoftware.b4a.AbsObjectWrapper").runMethod(false, "ConvertToWrapper", RemoteObject.createNew("anywheresoftware.b4a.keywords.Common.ResumableSubWrapper"), rsub.remoteResumableSub);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static class ResumableSub_PrepareSurface extends BA.ResumableSub {
public ResumableSub_PrepareSurface(com.mitguide.android.maps parent) {
this.parent = parent;
}
java.util.LinkedHashMap<String, Object> rsLocals = new java.util.LinkedHashMap<String, Object>();
com.mitguide.android.maps parent;
RemoteObject _success = RemoteObject.createImmutable(false);

@Override
public void resume(BA ba, RemoteObject result) throws Exception{
try {
		Debug.PushSubsStack("PrepareSurface (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,216);
Debug.locals = rsLocals;Debug.currentSubFrame.locals = rsLocals;

    while (true) {
        switch (state) {
            case -1:
{
parent.mostCurrent.__c.runVoidMethod ("ReturnFromResumableSub",this.remoteResumableSub,RemoteObject.createImmutable(null));return;}
case 0:
//C
this.state = 1;
 BA.debugLineNum = 217;BA.debugLine="SetState(False, busystate, VideoMode)";
Debug.ShouldStop(16777216);
_setstate(parent.mostCurrent.__c.getField(true,"False"),parent._busystate,parent._videomode);
 BA.debugLineNum = 219;BA.debugLine="If VideoMode Then";
Debug.ShouldStop(67108864);
if (true) break;

case 1:
//if
this.state = 6;
if (parent._videomode.<Boolean>get().booleanValue()) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 BA.debugLineNum = 220;BA.debugLine="cam.PreviewSize.Initialize(640, 480)";
Debug.ShouldStop(134217728);
parent.mostCurrent._cam.getField(false,"_previewsize" /*RemoteObject*/ ).runVoidMethod ("Initialize",(Object)(BA.numberCast(int.class, 640)),(Object)(BA.numberCast(int.class, 480)));
 BA.debugLineNum = 222;BA.debugLine="Wait For (cam.PrepareSurfaceForVideo(MyTaskIndex";
Debug.ShouldStop(536870912);
parent.mostCurrent.__c.runVoidMethod ("WaitFor","complete", maps.processBA, anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this, "maps", "preparesurface"), parent.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_preparesurfaceforvideo" /*RemoteObject*/ ,(Object)(parent._mytaskindex),(Object)(parent._videofiledir),(Object)(RemoteObject.concat(RemoteObject.createImmutable("temp-"),parent._videofilename))));
this.state = 12;
return;
case 12:
//C
this.state = 6;
_success = (RemoteObject) result.getArrayElement(true,RemoteObject.createImmutable(0));Debug.locals.put("Success", _success);
;
 if (true) break;

case 5:
//C
this.state = 6;
 BA.debugLineNum = 224;BA.debugLine="cam.PreviewSize.Initialize(1920, 1080)";
Debug.ShouldStop(-2147483648);
parent.mostCurrent._cam.getField(false,"_previewsize" /*RemoteObject*/ ).runVoidMethod ("Initialize",(Object)(BA.numberCast(int.class, 1920)),(Object)(BA.numberCast(int.class, 1080)));
 BA.debugLineNum = 225;BA.debugLine="Wait For (cam.PrepareSurface(MyTaskIndex)) Compl";
Debug.ShouldStop(1);
parent.mostCurrent.__c.runVoidMethod ("WaitFor","complete", maps.processBA, anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this, "maps", "preparesurface"), parent.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_preparesurface" /*RemoteObject*/ ,(Object)(parent._mytaskindex)));
this.state = 13;
return;
case 13:
//C
this.state = 6;
_success = (RemoteObject) result.getArrayElement(true,RemoteObject.createImmutable(0));Debug.locals.put("Success", _success);
;
 if (true) break;
;
 BA.debugLineNum = 227;BA.debugLine="If Success Then cam.StartPreview(MyTaskIndex, Vid";
Debug.ShouldStop(4);

case 6:
//if
this.state = 11;
if (_success.<Boolean>get().booleanValue()) { 
this.state = 8;
;}if (true) break;

case 8:
//C
this.state = 11;
parent.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_startpreview" /*RemoteObject*/ ,(Object)(parent._mytaskindex),(Object)(parent._videomode));
if (true) break;

case 11:
//C
this.state = -1;
;
 BA.debugLineNum = 228;BA.debugLine="SetState(Success, busystate, VideoMode)";
Debug.ShouldStop(8);
_setstate(_success,parent._busystate,parent._videomode);
 BA.debugLineNum = 229;BA.debugLine="Return Success";
Debug.ShouldStop(16);
if (true) {
parent.mostCurrent.__c.runVoidMethod ("ReturnFromResumableSub",this.remoteResumableSub,(_success));return;};
 BA.debugLineNum = 230;BA.debugLine="End Sub";
Debug.ShouldStop(32);
if (true) break;

            }
        }
    }
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}
public static RemoteObject  _process_globals() throws Exception{
 //BA.debugLineNum = 7;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 10;BA.debugLine="Private frontCamera As Boolean = True";
maps._frontcamera = maps.mostCurrent.__c.getField(true,"True");
 //BA.debugLineNum = 11;BA.debugLine="Private VideoMode As Boolean = False";
maps._videomode = maps.mostCurrent.__c.getField(true,"False");
 //BA.debugLineNum = 12;BA.debugLine="Private VideoFileDir, VideoFileName As String";
maps._videofiledir = RemoteObject.createImmutable("");
maps._videofilename = RemoteObject.createImmutable("");
 //BA.debugLineNum = 13;BA.debugLine="Private MyTaskIndex As Int";
maps._mytaskindex = RemoteObject.createImmutable(0);
 //BA.debugLineNum = 14;BA.debugLine="Private rp As RuntimePermissions";
maps._rp = RemoteObject.createNew ("anywheresoftware.b4a.objects.RuntimePermissions");
 //BA.debugLineNum = 15;BA.debugLine="Dim pw As PhoneWakeState";
maps._pw = RemoteObject.createNew ("anywheresoftware.b4a.phone.Phone.PhoneWakeState");
 //BA.debugLineNum = 16;BA.debugLine="Dim SQL1 As SQL";
maps._sql1 = RemoteObject.createNew ("anywheresoftware.b4a.sql.SQL");
 //BA.debugLineNum = 17;BA.debugLine="Dim GPS1 As GPS";
maps._gps1 = RemoteObject.createNew ("anywheresoftware.b4a.gps.GPS");
 //BA.debugLineNum = 18;BA.debugLine="Dim TTS1 As TTS";
maps._tts1 = RemoteObject.createNew ("anywheresoftware.b4a.obejcts.TTS");
 //BA.debugLineNum = 19;BA.debugLine="Dim Timer1 As Timer";
maps._timer1 = RemoteObject.createNew ("anywheresoftware.b4a.objects.Timer");
 //BA.debugLineNum = 20;BA.debugLine="Dim Timer2 As Timer";
maps._timer2 = RemoteObject.createNew ("anywheresoftware.b4a.objects.Timer");
 //BA.debugLineNum = 21;BA.debugLine="Dim SQL1 As SQL";
maps._sql1 = RemoteObject.createNew ("anywheresoftware.b4a.sql.SQL");
 //BA.debugLineNum = 22;BA.debugLine="Dim number1 As String";
maps._number1 = RemoteObject.createImmutable("");
 //BA.debugLineNum = 23;BA.debugLine="Dim number2 As String";
maps._number2 = RemoteObject.createImmutable("");
 //BA.debugLineNum = 24;BA.debugLine="Dim Sms1 As PhoneSms";
maps._sms1 = RemoteObject.createNew ("anywheresoftware.b4a.phone.Phone.PhoneSms");
 //BA.debugLineNum = 25;BA.debugLine="Dim phone1 As PhoneCalls";
maps._phone1 = RemoteObject.createNew ("anywheresoftware.b4a.phone.Phone.PhoneCalls");
 //BA.debugLineNum = 26;BA.debugLine="Dim u_name As String";
maps._u_name = RemoteObject.createImmutable("");
 //BA.debugLineNum = 27;BA.debugLine="Dim p_status As Int";
maps._p_status = RemoteObject.createImmutable(0);
 //BA.debugLineNum = 28;BA.debugLine="Dim p_drowsiness As Int";
maps._p_drowsiness = RemoteObject.createImmutable(0);
 //BA.debugLineNum = 29;BA.debugLine="End Sub";
return RemoteObject.createImmutable("");
}
public static RemoteObject  _setstate(RemoteObject _open,RemoteObject _busy,RemoteObject _video) throws Exception{
try {
		Debug.PushSubsStack("SetState (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,425);
if (RapidSub.canDelegate("setstate")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","setstate", _open, _busy, _video);}
RemoteObject _b = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
RemoteObject _btnrecordtext = RemoteObject.createImmutable("");
Debug.locals.put("Open", _open);
Debug.locals.put("Busy", _busy);
Debug.locals.put("Video", _video);
 BA.debugLineNum = 425;BA.debugLine="Sub SetState(Open As Boolean, Busy As Boolean, Vid";
Debug.ShouldStop(256);
 BA.debugLineNum = 426;BA.debugLine="For Each b As Button In buttons";
Debug.ShouldStop(512);
_b = RemoteObject.createNew ("anywheresoftware.b4a.objects.ButtonWrapper");
{
final RemoteObject group1 = maps.mostCurrent._buttons;
final int groupLen1 = group1.runMethod(true,"getSize").<Integer>get()
;int index1 = 0;
;
for (; index1 < groupLen1;index1++){
_b.setObject(group1.runMethod(false,"Get",index1));
Debug.locals.put("b", _b);
 BA.debugLineNum = 427;BA.debugLine="b.Visible = Open And Not(Busy)";
Debug.ShouldStop(1024);
_b.runMethod(true,"setVisible",BA.ObjectToBoolean(RemoteObject.solveBoolean(".",_open) && RemoteObject.solveBoolean(".",maps.mostCurrent.__c.runMethod(true,"Not",(Object)(_busy)))));
 }
}Debug.locals.put("b", _b);
;
 BA.debugLineNum = 429;BA.debugLine="btnCamera.Visible = Not(Busy)";
Debug.ShouldStop(4096);
maps.mostCurrent._btncamera.runMethod(true,"setVisible",maps.mostCurrent.__c.runMethod(true,"Not",(Object)(_busy)));
 BA.debugLineNum = 430;BA.debugLine="btnRecord.Visible = Open And (Video Or Not(Busy))";
Debug.ShouldStop(8192);
maps.mostCurrent._btnrecord.runMethod(true,"setVisible",BA.ObjectToBoolean(RemoteObject.solveBoolean(".",_open) && RemoteObject.solveBoolean(".",BA.ObjectToBoolean((RemoteObject.solveBoolean(".",_video) || RemoteObject.solveBoolean(".",maps.mostCurrent.__c.runMethod(true,"Not",(Object)(_busy))))))));
 BA.debugLineNum = 431;BA.debugLine="openstate = Open";
Debug.ShouldStop(16384);
maps._openstate = _open;
 BA.debugLineNum = 432;BA.debugLine="ProgressBar1.Visible = Busy";
Debug.ShouldStop(32768);
maps.mostCurrent._progressbar1.runMethod(true,"setVisible",_busy);
 BA.debugLineNum = 433;BA.debugLine="busystate = Busy";
Debug.ShouldStop(65536);
maps._busystate = _busy;
 BA.debugLineNum = 434;BA.debugLine="VideoMode = Video";
Debug.ShouldStop(131072);
maps._videomode = _video;
 BA.debugLineNum = 435;BA.debugLine="barZoom.Visible = Open";
Debug.ShouldStop(262144);
maps.mostCurrent._barzoom.runMethod(true,"setVisible",_open);
 BA.debugLineNum = 436;BA.debugLine="Dim btnRecordText As String";
Debug.ShouldStop(524288);
_btnrecordtext = RemoteObject.createImmutable("");Debug.locals.put("btnRecordText", _btnrecordtext);
 BA.debugLineNum = 437;BA.debugLine="If VideoMode Then";
Debug.ShouldStop(1048576);
if (maps._videomode.<Boolean>get().booleanValue()) { 
 BA.debugLineNum = 438;BA.debugLine="If Busy Then";
Debug.ShouldStop(2097152);
if (_busy.<Boolean>get().booleanValue()) { 
 BA.debugLineNum = 439;BA.debugLine="btnRecordText = Chr(0xF04D)";
Debug.ShouldStop(4194304);
_btnrecordtext = BA.ObjectToString(maps.mostCurrent.__c.runMethod(true,"Chr",(Object)(BA.numberCast(int.class, 0xf04d))));Debug.locals.put("btnRecordText", _btnrecordtext);
 }else {
 BA.debugLineNum = 441;BA.debugLine="btnRecordText = Chr(0xF03D)";
Debug.ShouldStop(16777216);
_btnrecordtext = BA.ObjectToString(maps.mostCurrent.__c.runMethod(true,"Chr",(Object)(BA.numberCast(int.class, 0xf03d))));Debug.locals.put("btnRecordText", _btnrecordtext);
 };
 }else {
 BA.debugLineNum = 444;BA.debugLine="btnRecordText = Chr(0xF030)";
Debug.ShouldStop(134217728);
_btnrecordtext = BA.ObjectToString(maps.mostCurrent.__c.runMethod(true,"Chr",(Object)(BA.numberCast(int.class, 0xf030))));Debug.locals.put("btnRecordText", _btnrecordtext);
 };
 BA.debugLineNum = 446;BA.debugLine="btnRecord.Text = btnRecordText";
Debug.ShouldStop(536870912);
maps.mostCurrent._btnrecord.runMethod(true,"setText",BA.ObjectToCharSequence(_btnrecordtext));
 BA.debugLineNum = 447;BA.debugLine="End Sub";
Debug.ShouldStop(1073741824);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static void  _takepicture() throws Exception{
try {
		Debug.PushSubsStack("TakePicture (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,312);
if (RapidSub.canDelegate("takepicture")) { com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","takepicture"); return;}
ResumableSub_TakePicture rsub = new ResumableSub_TakePicture(null);
rsub.resume(null, null);
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static class ResumableSub_TakePicture extends BA.ResumableSub {
public ResumableSub_TakePicture(com.mitguide.android.maps parent) {
this.parent = parent;
}
java.util.LinkedHashMap<String, Object> rsLocals = new java.util.LinkedHashMap<String, Object>();
com.mitguide.android.maps parent;
RemoteObject _data = null;
RemoteObject _bmp = RemoteObject.declareNull("anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper");

@Override
public void resume(BA ba, RemoteObject result) throws Exception{
try {
		Debug.PushSubsStack("TakePicture (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,312);
Debug.locals = rsLocals;Debug.currentSubFrame.locals = rsLocals;

    while (true) {
try {

        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 BA.debugLineNum = 313;BA.debugLine="Try";
Debug.ShouldStop(16777216);
if (true) break;

case 1:
//try
this.state = 6;
this.catchState = 5;
this.state = 3;
if (true) break;

case 3:
//C
this.state = 6;
this.catchState = 5;
 BA.debugLineNum = 315;BA.debugLine="Wait For(cam.FocusAndTakePicture(MyTaskIndex)) C";
Debug.ShouldStop(67108864);
parent.mostCurrent.__c.runVoidMethod ("WaitFor","complete", maps.processBA, anywheresoftware.b4a.pc.PCResumableSub.createDebugResumeSub(this, "maps", "takepicture"), parent.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_focusandtakepicture" /*RemoteObject*/ ,(Object)(parent._mytaskindex)));
this.state = 7;
return;
case 7:
//C
this.state = 6;
_data = (RemoteObject) result.getArrayElement(false,RemoteObject.createImmutable(0));Debug.locals.put("Data", _data);
;
 BA.debugLineNum = 317;BA.debugLine="cam.DataToFile(Data, VideoFileDir, \"1.jpg\")";
Debug.ShouldStop(268435456);
parent.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_datatofile" /*RemoteObject*/ ,(Object)(_data),(Object)(parent._videofiledir),(Object)(RemoteObject.createImmutable("1.jpg")));
 BA.debugLineNum = 318;BA.debugLine="Dim bmp As Bitmap = cam.DataToBitmap(Data)";
Debug.ShouldStop(536870912);
_bmp = RemoteObject.createNew ("anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper");
_bmp = parent.mostCurrent._cam.runClassMethod (com.mitguide.android.camex2.class, "_datatobitmap" /*RemoteObject*/ ,(Object)(_data));Debug.locals.put("bmp", _bmp);Debug.locals.put("bmp", _bmp);
 BA.debugLineNum = 319;BA.debugLine="Log(\"Picture taken: \" & bmp) 'ignore";
Debug.ShouldStop(1073741824);
parent.mostCurrent.__c.runVoidMethod ("LogImpl","72621447",RemoteObject.concat(RemoteObject.createImmutable("Picture taken: "),_bmp),0);
 BA.debugLineNum = 320;BA.debugLine="ToastMessageShow(\"Snapshot Taken\", False)";
Debug.ShouldStop(-2147483648);
parent.mostCurrent.__c.runVoidMethod ("ToastMessageShow",(Object)(BA.ObjectToCharSequence("Snapshot Taken")),(Object)(parent.mostCurrent.__c.getField(true,"False")));
 BA.debugLineNum = 322;BA.debugLine="fv1.Photo = bmp";
Debug.ShouldStop(2);
parent.mostCurrent._fv1.runVoidMethod ("setPhoto",(_bmp.getObject()));
 BA.debugLineNum = 324;BA.debugLine="fv1.CircleColor = Colors.Cyan";
Debug.ShouldStop(8);
parent.mostCurrent._fv1.runVoidMethod ("setCircleColor",parent.mostCurrent.__c.getField(false,"Colors").getField(true,"Cyan"));
 BA.debugLineNum = 325;BA.debugLine="fv1.CircleWidth = 3";
Debug.ShouldStop(16);
parent.mostCurrent._fv1.runVoidMethod ("setCircleWidth",BA.numberCast(int.class, 3));
 BA.debugLineNum = 326;BA.debugLine="fv1.CircleDiameter = 5";
Debug.ShouldStop(32);
parent.mostCurrent._fv1.runVoidMethod ("setCircleDiameter",BA.numberCast(int.class, 5));
 BA.debugLineNum = 328;BA.debugLine="fv1.MinFaceSize = 0.1";
Debug.ShouldStop(128);
parent.mostCurrent._fv1.runVoidMethod ("setMinFaceSize",BA.numberCast(float.class, 0.1));
 BA.debugLineNum = 329;BA.debugLine="fv1.ShowFaceIds = True";
Debug.ShouldStop(256);
parent.mostCurrent._fv1.runVoidMethod ("setShowFaceIds",parent.mostCurrent.__c.getField(true,"True"));
 BA.debugLineNum = 331;BA.debugLine="fv1.build";
Debug.ShouldStop(1024);
parent.mostCurrent._fv1.runVoidMethod ("build");
 Debug.CheckDeviceExceptions();
if (true) break;

case 5:
//C
this.state = 6;
this.catchState = 0;
 BA.debugLineNum = 337;BA.debugLine="HandleError(LastException)";
Debug.ShouldStop(65536);
_handleerror(parent.mostCurrent.__c.runMethod(false,"LastException",maps.mostCurrent.activityBA));
 if (true) break;
if (true) break;

case 6:
//C
this.state = -1;
this.catchState = 0;
;
 BA.debugLineNum = 340;BA.debugLine="End Sub";
Debug.ShouldStop(524288);
if (true) break;
}} 
       catch (Exception e0) {
			
if (catchState == 0)
    throw e0;
else {
    state = catchState;
BA.rdebugUtils.runVoidMethod("setLastException",maps.processBA, e0.toString());}
            }
        }
    }
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}
public static RemoteObject  _timer1_tick() throws Exception{
try {
		Debug.PushSubsStack("Timer1_Tick (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,251);
if (RapidSub.canDelegate("timer1_tick")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","timer1_tick");}
RemoteObject _btnrecordtext = RemoteObject.createImmutable("");
 BA.debugLineNum = 251;BA.debugLine="Sub Timer1_Tick";
Debug.ShouldStop(67108864);
 BA.debugLineNum = 252;BA.debugLine="Dim btnRecordText As String";
Debug.ShouldStop(134217728);
_btnrecordtext = RemoteObject.createImmutable("");Debug.locals.put("btnRecordText", _btnrecordtext);
 BA.debugLineNum = 253;BA.debugLine="If Timer1.Enabled = True Then";
Debug.ShouldStop(268435456);
if (RemoteObject.solveBoolean("=",maps._timer1.runMethod(true,"getEnabled"),maps.mostCurrent.__c.getField(true,"True"))) { 
 BA.debugLineNum = 256;BA.debugLine="ToastMessageShow(\"Frame Captured\",False)";
Debug.ShouldStop(-2147483648);
maps.mostCurrent.__c.runVoidMethod ("ToastMessageShow",(Object)(BA.ObjectToCharSequence("Frame Captured")),(Object)(maps.mostCurrent.__c.getField(true,"False")));
 BA.debugLineNum = 257;BA.debugLine="TakePicture";
Debug.ShouldStop(1);
_takepicture();
 }else {
 };
 BA.debugLineNum = 263;BA.debugLine="End Sub";
Debug.ShouldStop(64);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
public static RemoteObject  _timer2_tick() throws Exception{
try {
		Debug.PushSubsStack("Timer2_Tick (maps) ","maps",2,maps.mostCurrent.activityBA,maps.mostCurrent,157);
if (RapidSub.canDelegate("timer2_tick")) { return com.mitguide.android.maps.remoteMe.runUserSub(false, "maps","timer2_tick");}
 BA.debugLineNum = 157;BA.debugLine="Sub Timer2_Tick";
Debug.ShouldStop(268435456);
 BA.debugLineNum = 160;BA.debugLine="End Sub";
Debug.ShouldStop(-2147483648);
return RemoteObject.createImmutable("");
}
catch (Exception e) {
			throw Debug.ErrorCaught(e);
		} 
finally {
			Debug.PopSubsStack();
		}}
}