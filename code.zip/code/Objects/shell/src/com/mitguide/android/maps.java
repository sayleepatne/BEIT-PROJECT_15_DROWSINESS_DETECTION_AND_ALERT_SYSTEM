
package com.mitguide.android;

import java.io.IOException;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.pc.PCBA;
import anywheresoftware.b4a.pc.RDebug;
import anywheresoftware.b4a.pc.RemoteObject;
import anywheresoftware.b4a.pc.RDebug.IRemote;
import anywheresoftware.b4a.pc.Debug;
import anywheresoftware.b4a.pc.B4XTypes.B4XClass;
import anywheresoftware.b4a.pc.B4XTypes.DeviceClass;

public class maps implements IRemote{
	public static maps mostCurrent;
	public static RemoteObject processBA;
    public static boolean processGlobalsRun;
    public static RemoteObject myClass;
    public static RemoteObject remoteMe;
	public maps() {
		mostCurrent = this;
	}
    public RemoteObject getRemoteMe() {
        return remoteMe;    
    }
    
	public static void main (String[] args) throws Exception {
		new RDebug(args[0], Integer.parseInt(args[1]), Integer.parseInt(args[2]), args[3]);
		RDebug.INSTANCE.waitForTask();

	}
    static {
        anywheresoftware.b4a.pc.RapidSub.moduleToObject.put(new B4XClass("maps"), "com.mitguide.android.maps");
	}

public boolean isSingleton() {
		return true;
	}
     public static RemoteObject getObject() {
		return myClass;
	 }

	public RemoteObject activityBA;
	public RemoteObject _activity;
    private PCBA pcBA;

	public PCBA create(Object[] args) throws ClassNotFoundException{
		processBA = (RemoteObject) args[1];
		activityBA = (RemoteObject) args[2];
		_activity = (RemoteObject) args[3];
        anywheresoftware.b4a.keywords.Common.Density = (Float)args[4];
        remoteMe = (RemoteObject) args[5];
		pcBA = new PCBA(this, maps.class);
        main_subs_0.initializeProcessGlobals();
		return pcBA;
	}
public static RemoteObject __c = RemoteObject.declareNull("anywheresoftware.b4a.keywords.Common");
public static RemoteObject _frontcamera = RemoteObject.createImmutable(false);
public static RemoteObject _videomode = RemoteObject.createImmutable(false);
public static RemoteObject _videofiledir = RemoteObject.createImmutable("");
public static RemoteObject _videofilename = RemoteObject.createImmutable("");
public static RemoteObject _mytaskindex = RemoteObject.createImmutable(0);
public static RemoteObject _rp = RemoteObject.declareNull("anywheresoftware.b4a.objects.RuntimePermissions");
public static RemoteObject _pw = RemoteObject.declareNull("anywheresoftware.b4a.phone.Phone.PhoneWakeState");
public static RemoteObject _sql1 = RemoteObject.declareNull("anywheresoftware.b4a.sql.SQL");
public static RemoteObject _gps1 = RemoteObject.declareNull("anywheresoftware.b4a.gps.GPS");
public static RemoteObject _tts1 = RemoteObject.declareNull("anywheresoftware.b4a.obejcts.TTS");
public static RemoteObject _timer1 = RemoteObject.declareNull("anywheresoftware.b4a.objects.Timer");
public static RemoteObject _timer2 = RemoteObject.declareNull("anywheresoftware.b4a.objects.Timer");
public static RemoteObject _number1 = RemoteObject.createImmutable("");
public static RemoteObject _number2 = RemoteObject.createImmutable("");
public static RemoteObject _sms1 = RemoteObject.declareNull("anywheresoftware.b4a.phone.Phone.PhoneSms");
public static RemoteObject _phone1 = RemoteObject.declareNull("anywheresoftware.b4a.phone.Phone.PhoneCalls");
public static RemoteObject _u_name = RemoteObject.createImmutable("");
public static RemoteObject _p_status = RemoteObject.createImmutable(0);
public static RemoteObject _p_drowsiness = RemoteObject.createImmutable(0);
public static RemoteObject _cam = RemoteObject.declareNull("com.mitguide.android.camex2");
public static RemoteObject _pnlcamera = RemoteObject.declareNull("anywheresoftware.b4a.objects.PanelWrapper");
public static RemoteObject _pnlpicture = RemoteObject.declareNull("anywheresoftware.b4a.objects.PanelWrapper");
public static RemoteObject _pnlbackground = RemoteObject.declareNull("anywheresoftware.b4a.objects.PanelWrapper");
public static RemoteObject _btneffects = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _btnscene = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _buttons = RemoteObject.declareNull("anywheresoftware.b4a.objects.collections.List");
public static RemoteObject _btnautoexposure = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _btnfocus = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _progressbar1 = RemoteObject.declareNull("anywheresoftware.b4a.objects.ProgressBarWrapper");
public static RemoteObject _openstate = RemoteObject.createImmutable(false);
public static RemoteObject _busystate = RemoteObject.createImmutable(false);
public static RemoteObject _btnrecord = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _btnmode = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _btncamera = RemoteObject.declareNull("anywheresoftware.b4a.objects.ButtonWrapper");
public static RemoteObject _barzoom = RemoteObject.declareNull("anywheresoftware.b4a.objects.SeekBarWrapper");
public static RemoteObject _bm = RemoteObject.declareNull("anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper");
public static RemoteObject _fv1 = RemoteObject.declareNull("photowrapper.photoWrapper");
public static RemoteObject _lv1 = RemoteObject.declareNull("anywheresoftware.b4a.objects.ListViewWrapper");
public static RemoteObject _sf = RemoteObject.declareNull("ADR.stringdemo.stringfunctions");
public static RemoteObject _label1 = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _label2 = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _label3 = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _label10 = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _label13 = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _label9 = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _label12 = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _label14 = RemoteObject.declareNull("anywheresoftware.b4a.objects.LabelWrapper");
public static RemoteObject _httputils2service = RemoteObject.declareNull("anywheresoftware.b4a.samples.httputils2.httputils2service");
public static com.mitguide.android.main _main = null;
public static com.mitguide.android.starter _starter = null;
  public Object[] GetGlobals() {
		return new Object[] {"Activity",maps.mostCurrent._activity,"barZoom",maps.mostCurrent._barzoom,"bm",maps.mostCurrent._bm,"btnAutoExposure",maps.mostCurrent._btnautoexposure,"btnCamera",maps.mostCurrent._btncamera,"btnEffects",maps.mostCurrent._btneffects,"btnFocus",maps.mostCurrent._btnfocus,"btnMode",maps.mostCurrent._btnmode,"btnRecord",maps.mostCurrent._btnrecord,"btnScene",maps.mostCurrent._btnscene,"busystate",maps._busystate,"buttons",maps.mostCurrent._buttons,"cam",maps.mostCurrent._cam,"frontCamera",maps._frontcamera,"fv1",maps.mostCurrent._fv1,"GPS1",maps._gps1,"HttpUtils2Service",maps.mostCurrent._httputils2service,"Label1",maps.mostCurrent._label1,"Label10",maps.mostCurrent._label10,"Label12",maps.mostCurrent._label12,"Label13",maps.mostCurrent._label13,"Label14",maps.mostCurrent._label14,"Label2",maps.mostCurrent._label2,"Label3",maps.mostCurrent._label3,"Label9",maps.mostCurrent._label9,"lv1",maps.mostCurrent._lv1,"Main",Debug.moduleToString(com.mitguide.android.main.class),"MyTaskIndex",maps._mytaskindex,"number1",maps._number1,"number2",maps._number2,"openstate",maps._openstate,"p_drowsiness",maps._p_drowsiness,"p_status",maps._p_status,"phone1",maps._phone1,"pnlBackground",maps.mostCurrent._pnlbackground,"pnlCamera",maps.mostCurrent._pnlcamera,"pnlPicture",maps.mostCurrent._pnlpicture,"ProgressBar1",maps.mostCurrent._progressbar1,"pw",maps._pw,"rp",maps._rp,"sf",maps.mostCurrent._sf,"Sms1",maps._sms1,"SQL1",maps._sql1,"Starter",Debug.moduleToString(com.mitguide.android.starter.class),"Timer1",maps._timer1,"Timer2",maps._timer2,"TTS1",maps._tts1,"u_name",maps._u_name,"VideoFileDir",maps._videofiledir,"VideoFileName",maps._videofilename,"VideoMode",maps._videomode};
}
}