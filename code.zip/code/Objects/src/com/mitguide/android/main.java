package com.mitguide.android;


import anywheresoftware.b4a.B4AMenuItem;
import android.app.Activity;
import android.os.Bundle;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.B4AActivity;
import anywheresoftware.b4a.ObjectWrapper;
import anywheresoftware.b4a.objects.ActivityWrapper;
import java.lang.reflect.InvocationTargetException;
import anywheresoftware.b4a.B4AUncaughtException;
import anywheresoftware.b4a.debug.*;
import java.lang.ref.WeakReference;

public class main extends Activity implements B4AActivity{
	public static main mostCurrent;
	static boolean afterFirstLayout;
	static boolean isFirst = true;
    private static boolean processGlobalsRun = false;
	BALayout layout;
	public static BA processBA;
	BA activityBA;
    ActivityWrapper _activity;
    java.util.ArrayList<B4AMenuItem> menuItems;
	public static final boolean fullScreen = false;
	public static final boolean includeTitle = false;
    public static WeakReference<Activity> previousOne;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        mostCurrent = this;
		if (processBA == null) {
			processBA = new anywheresoftware.b4a.ShellBA(this.getApplicationContext(), null, null, "com.mitguide.android", "com.mitguide.android.main");
			processBA.loadHtSubs(this.getClass());
	        float deviceScale = getApplicationContext().getResources().getDisplayMetrics().density;
	        BALayout.setDeviceScale(deviceScale);
            
		}
		else if (previousOne != null) {
			Activity p = previousOne.get();
			if (p != null && p != this) {
                BA.LogInfo("Killing previous instance (main).");
				p.finish();
			}
		}
        processBA.setActivityPaused(true);
        processBA.runHook("oncreate", this, null);
		if (!includeTitle) {
        	this.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
        }
        if (fullScreen) {
        	getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,   
        			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
		
        processBA.sharedProcessBA.activityBA = null;
		layout = new BALayout(this);
		setContentView(layout);
		afterFirstLayout = false;
        WaitForLayout wl = new WaitForLayout();
        if (anywheresoftware.b4a.objects.ServiceHelper.StarterHelper.startFromActivity(this, processBA, wl, false))
		    BA.handler.postDelayed(wl, 5);

	}
	static class WaitForLayout implements Runnable {
		public void run() {
			if (afterFirstLayout)
				return;
			if (mostCurrent == null)
				return;
            
			if (mostCurrent.layout.getWidth() == 0) {
				BA.handler.postDelayed(this, 5);
				return;
			}
			mostCurrent.layout.getLayoutParams().height = mostCurrent.layout.getHeight();
			mostCurrent.layout.getLayoutParams().width = mostCurrent.layout.getWidth();
			afterFirstLayout = true;
			mostCurrent.afterFirstLayout();
		}
	}
	private void afterFirstLayout() {
        if (this != mostCurrent)
			return;
		activityBA = new BA(this, layout, processBA, "com.mitguide.android", "com.mitguide.android.main");
        
        processBA.sharedProcessBA.activityBA = new java.lang.ref.WeakReference<BA>(activityBA);
        anywheresoftware.b4a.objects.ViewWrapper.lastId = 0;
        _activity = new ActivityWrapper(activityBA, "activity");
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (BA.isShellModeRuntimeCheck(processBA)) {
			if (isFirst)
				processBA.raiseEvent2(null, true, "SHELL", false);
			processBA.raiseEvent2(null, true, "CREATE", true, "com.mitguide.android.main", processBA, activityBA, _activity, anywheresoftware.b4a.keywords.Common.Density, mostCurrent);
			_activity.reinitializeForShell(activityBA, "activity");
		}
        initializeProcessGlobals();		
        initializeGlobals();
        
        BA.LogInfo("** Activity (main) Create, isFirst = " + isFirst + " **");
        processBA.raiseEvent2(null, true, "activity_create", false, isFirst);
		isFirst = false;
		if (this != mostCurrent)
			return;
        processBA.setActivityPaused(false);
        BA.LogInfo("** Activity (main) Resume **");
        processBA.raiseEvent(null, "activity_resume");
        if (android.os.Build.VERSION.SDK_INT >= 11) {
			try {
				android.app.Activity.class.getMethod("invalidateOptionsMenu").invoke(this,(Object[]) null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	public void addMenuItem(B4AMenuItem item) {
		if (menuItems == null)
			menuItems = new java.util.ArrayList<B4AMenuItem>();
		menuItems.add(item);
	}
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		super.onCreateOptionsMenu(menu);
        try {
            if (processBA.subExists("activity_actionbarhomeclick")) {
                Class.forName("android.app.ActionBar").getMethod("setHomeButtonEnabled", boolean.class).invoke(
                    getClass().getMethod("getActionBar").invoke(this), true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (processBA.runHook("oncreateoptionsmenu", this, new Object[] {menu}))
            return true;
		if (menuItems == null)
			return false;
		for (B4AMenuItem bmi : menuItems) {
			android.view.MenuItem mi = menu.add(bmi.title);
			if (bmi.drawable != null)
				mi.setIcon(bmi.drawable);
            if (android.os.Build.VERSION.SDK_INT >= 11) {
				try {
                    if (bmi.addToBar) {
				        android.view.MenuItem.class.getMethod("setShowAsAction", int.class).invoke(mi, 1);
                    }
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			mi.setOnMenuItemClickListener(new B4AMenuItemsClickListener(bmi.eventName.toLowerCase(BA.cul)));
		}
        
		return true;
	}   
 @Override
 public boolean onOptionsItemSelected(android.view.MenuItem item) {
    if (item.getItemId() == 16908332) {
        processBA.raiseEvent(null, "activity_actionbarhomeclick");
        return true;
    }
    else
        return super.onOptionsItemSelected(item); 
}
@Override
 public boolean onPrepareOptionsMenu(android.view.Menu menu) {
    super.onPrepareOptionsMenu(menu);
    processBA.runHook("onprepareoptionsmenu", this, new Object[] {menu});
    return true;
    
 }
 protected void onStart() {
    super.onStart();
    processBA.runHook("onstart", this, null);
}
 protected void onStop() {
    super.onStop();
    processBA.runHook("onstop", this, null);
}
    public void onWindowFocusChanged(boolean hasFocus) {
       super.onWindowFocusChanged(hasFocus);
       if (processBA.subExists("activity_windowfocuschanged"))
           processBA.raiseEvent2(null, true, "activity_windowfocuschanged", false, hasFocus);
    }
	private class B4AMenuItemsClickListener implements android.view.MenuItem.OnMenuItemClickListener {
		private final String eventName;
		public B4AMenuItemsClickListener(String eventName) {
			this.eventName = eventName;
		}
		public boolean onMenuItemClick(android.view.MenuItem item) {
			processBA.raiseEventFromUI(item.getTitle(), eventName + "_click");
			return true;
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}
    private Boolean onKeySubExist = null;
    private Boolean onKeyUpSubExist = null;
	@Override
	public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeydown", this, new Object[] {keyCode, event}))
            return true;
		if (onKeySubExist == null)
			onKeySubExist = processBA.subExists("activity_keypress");
		if (onKeySubExist) {
			if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK &&
					android.os.Build.VERSION.SDK_INT >= 18) {
				HandleKeyDelayed hk = new HandleKeyDelayed();
				hk.kc = keyCode;
				BA.handler.post(hk);
				return true;
			}
			else {
				boolean res = new HandleKeyDelayed().runDirectly(keyCode);
				if (res)
					return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	private class HandleKeyDelayed implements Runnable {
		int kc;
		public void run() {
			runDirectly(kc);
		}
		public boolean runDirectly(int keyCode) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keypress", false, keyCode);
			if (res == null || res == true) {
                return true;
            }
            else if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK) {
				finish();
				return true;
			}
            return false;
		}
		
	}
    @Override
	public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeyup", this, new Object[] {keyCode, event}))
            return true;
		if (onKeyUpSubExist == null)
			onKeyUpSubExist = processBA.subExists("activity_keyup");
		if (onKeyUpSubExist) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keyup", false, keyCode);
			if (res == null || res == true)
				return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	@Override
	public void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
		this.setIntent(intent);
        processBA.runHook("onnewintent", this, new Object[] {intent});
	}
    @Override 
	public void onPause() {
		super.onPause();
        if (_activity == null)
            return;
        if (this != mostCurrent)
			return;
		anywheresoftware.b4a.Msgbox.dismiss(true);
        BA.LogInfo("** Activity (main) Pause, UserClosed = " + activityBA.activity.isFinishing() + " **");
        if (mostCurrent != null)
            processBA.raiseEvent2(_activity, true, "activity_pause", false, activityBA.activity.isFinishing());		
        processBA.setActivityPaused(true);
        mostCurrent = null;
        if (!activityBA.activity.isFinishing())
			previousOne = new WeakReference<Activity>(this);
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        processBA.runHook("onpause", this, null);
	}

	@Override
	public void onDestroy() {
        super.onDestroy();
		previousOne = null;
        processBA.runHook("ondestroy", this, null);
	}
    @Override 
	public void onResume() {
		super.onResume();
        mostCurrent = this;
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (activityBA != null) { //will be null during activity create (which waits for AfterLayout).
        	ResumeMessage rm = new ResumeMessage(mostCurrent);
        	BA.handler.post(rm);
        }
        processBA.runHook("onresume", this, null);
	}
    private static class ResumeMessage implements Runnable {
    	private final WeakReference<Activity> activity;
    	public ResumeMessage(Activity activity) {
    		this.activity = new WeakReference<Activity>(activity);
    	}
		public void run() {
            main mc = mostCurrent;
			if (mc == null || mc != activity.get())
				return;
			processBA.setActivityPaused(false);
            BA.LogInfo("** Activity (main) Resume **");
            if (mc != mostCurrent)
                return;
		    processBA.raiseEvent(mc._activity, "activity_resume", (Object[])null);
		}
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	      android.content.Intent data) {
		processBA.onActivityResult(requestCode, resultCode, data);
        processBA.runHook("onactivityresult", this, new Object[] {requestCode, resultCode});
	}
	private static void initializeGlobals() {
		processBA.raiseEvent2(null, true, "globals", false, (Object[])null);
	}
    public void onRequestPermissionsResult(int requestCode,
        String permissions[], int[] grantResults) {
        for (int i = 0;i < permissions.length;i++) {
            Object[] o = new Object[] {permissions[i], grantResults[i] == 0};
            processBA.raiseEventFromDifferentThread(null,null, 0, "activity_permissionresult", true, o);
        }
            
    }



public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        anywheresoftware.b4a.samples.httputils2.httputils2service._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}
public static boolean isAnyActivityVisible() {
    boolean vis = false;
vis = vis | (main.mostCurrent != null);
vis = vis | (maps.mostCurrent != null);
return vis;}

private static BA killProgramHelper(BA ba) {
    if (ba == null)
        return null;
    anywheresoftware.b4a.BA.SharedProcessBA sharedProcessBA = ba.sharedProcessBA;
    if (sharedProcessBA == null || sharedProcessBA.activityBA == null)
        return null;
    return sharedProcessBA.activityBA.get();
}
public static void killProgram() {
     {
            Activity __a = null;
            if (main.previousOne != null) {
				__a = main.previousOne.get();
			}
            else {
                BA ba = killProgramHelper(main.mostCurrent == null ? null : main.mostCurrent.processBA);
                if (ba != null) __a = ba.activity;
            }
            if (__a != null)
				__a.finish();}

BA.applicationContext.stopService(new android.content.Intent(BA.applicationContext, starter.class));
 {
            Activity __a = null;
            if (maps.previousOne != null) {
				__a = maps.previousOne.get();
			}
            else {
                BA ba = killProgramHelper(maps.mostCurrent == null ? null : maps.mostCurrent.processBA);
                if (ba != null) __a = ba.activity;
            }
            if (__a != null)
				__a.finish();}

}
public anywheresoftware.b4a.keywords.Common __c = null;
public static String _api_key1 = "";
public static anywheresoftware.b4a.sql.SQL _sql1 = null;
public static String _d_login = "";
public static String _d_pass = "";
public static String _d_mobile = "";
public static int _d_mode = 0;
public static anywheresoftware.b4a.phone.Phone.PhoneSms _sms1 = null;
public static anywheresoftware.b4a.phone.Phone.PhoneCalls _phone1 = null;
public static int _d_use = 0;
public static int _ran_no = 0;
public anywheresoftware.b4a.objects.LabelWrapper _label1 = null;
public anywheresoftware.b4a.objects.LabelWrapper _label2 = null;
public anywheresoftware.b4a.objects.LabelWrapper _label3 = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtlogin = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtpassword = null;
public anywheresoftware.b4a.objects.ButtonWrapper _cmdlogin = null;
public anywheresoftware.b4a.objects.ButtonWrapper _cmdcancel = null;
public anywheresoftware.b4a.objects.ButtonWrapper _cmdforgot = null;
public anywheresoftware.b4a.objects.ButtonWrapper _cmdregister = null;
public anywheresoftware.b4a.objects.LabelWrapper _label4 = null;
public anywheresoftware.b4a.objects.EditTextWrapper _txtmobile = null;
public anywheresoftware.b4a.samples.httputils2.httputils2service _httputils2service = null;
public com.mitguide.android.starter _starter = null;
public com.mitguide.android.maps _maps = null;
public static String  _activity_create(boolean _firsttime) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "activity_create", false))
	 {return ((String) Debug.delegate(mostCurrent.activityBA, "activity_create", new Object[] {_firsttime}));}
RDebugUtils.currentLine=131072;
 //BA.debugLineNum = 131072;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
RDebugUtils.currentLine=131073;
 //BA.debugLineNum = 131073;BA.debugLine="Activity.LoadLayout(\"login\")";
mostCurrent._activity.LoadLayout("login",mostCurrent.activityBA);
RDebugUtils.currentLine=131074;
 //BA.debugLineNum = 131074;BA.debugLine="d_mode = 0";
_d_mode = (int) (0);
RDebugUtils.currentLine=131075;
 //BA.debugLineNum = 131075;BA.debugLine="Label4.Visible = False";
mostCurrent._label4.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=131076;
 //BA.debugLineNum = 131076;BA.debugLine="txtmobile.Visible = False";
mostCurrent._txtmobile.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=131077;
 //BA.debugLineNum = 131077;BA.debugLine="If FirstTime Then";
if (_firsttime) { 
RDebugUtils.currentLine=131078;
 //BA.debugLineNum = 131078;BA.debugLine="SQL1.Initialize(File.DirDefaultExternal, \"test1.";
_sql1.Initialize(anywheresoftware.b4a.keywords.Common.File.getDirDefaultExternal(),"test1.db",anywheresoftware.b4a.keywords.Common.True);
 };
RDebugUtils.currentLine=131080;
 //BA.debugLineNum = 131080;BA.debugLine="CreateTables";
_createtables();
RDebugUtils.currentLine=131081;
 //BA.debugLineNum = 131081;BA.debugLine="End Sub";
return "";
}
public static String  _createtables() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "createtables", false))
	 {return ((String) Debug.delegate(mostCurrent.activityBA, "createtables", null));}
RDebugUtils.currentLine=851968;
 //BA.debugLineNum = 851968;BA.debugLine="Sub CreateTables";
RDebugUtils.currentLine=851969;
 //BA.debugLineNum = 851969;BA.debugLine="SQL1.ExecNonQuery(\"CREATE TABLE IF NOT EXISTS tab";
_sql1.ExecNonQuery("CREATE TABLE IF NOT EXISTS table3 (mob3 TEXT)");
RDebugUtils.currentLine=851970;
 //BA.debugLineNum = 851970;BA.debugLine="SQL1.ExecNonQuery(\"CREATE TABLE IF NOT EXISTS tab";
_sql1.ExecNonQuery("CREATE TABLE IF NOT EXISTS table4 (mob4 TEXT)");
RDebugUtils.currentLine=851971;
 //BA.debugLineNum = 851971;BA.debugLine="SQL1.ExecNonQuery(\"CREATE TABLE IF NOT EXISTS tab";
_sql1.ExecNonQuery("CREATE TABLE IF NOT EXISTS table5 (mob5 TEXT)");
RDebugUtils.currentLine=851974;
 //BA.debugLineNum = 851974;BA.debugLine="End Sub";
return "";
}
public static String  _activity_pause(boolean _userclosed) throws Exception{
RDebugUtils.currentModule="main";
RDebugUtils.currentLine=262144;
 //BA.debugLineNum = 262144;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
RDebugUtils.currentLine=262146;
 //BA.debugLineNum = 262146;BA.debugLine="End Sub";
return "";
}
public static String  _activity_resume() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "activity_resume", false))
	 {return ((String) Debug.delegate(mostCurrent.activityBA, "activity_resume", null));}
RDebugUtils.currentLine=196608;
 //BA.debugLineNum = 196608;BA.debugLine="Sub Activity_Resume";
RDebugUtils.currentLine=196609;
 //BA.debugLineNum = 196609;BA.debugLine="txtlogin.Text = \"\"";
mostCurrent._txtlogin.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=196610;
 //BA.debugLineNum = 196610;BA.debugLine="txtpassword.Text = \"\"";
mostCurrent._txtpassword.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=196611;
 //BA.debugLineNum = 196611;BA.debugLine="End Sub";
return "";
}
public static String  _cmdcancel_click() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "cmdcancel_click", false))
	 {return ((String) Debug.delegate(mostCurrent.activityBA, "cmdcancel_click", null));}
RDebugUtils.currentLine=983040;
 //BA.debugLineNum = 983040;BA.debugLine="Sub cmdcancel_Click";
RDebugUtils.currentLine=983044;
 //BA.debugLineNum = 983044;BA.debugLine="If d_mode = 0 Then";
if (_d_mode==0) { 
RDebugUtils.currentLine=983045;
 //BA.debugLineNum = 983045;BA.debugLine="Activity.Finish";
mostCurrent._activity.Finish();
 }else {
RDebugUtils.currentLine=983047;
 //BA.debugLineNum = 983047;BA.debugLine="txtlogin.Text = \"\"";
mostCurrent._txtlogin.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=983048;
 //BA.debugLineNum = 983048;BA.debugLine="txtpassword.Text = \"\"";
mostCurrent._txtpassword.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=983049;
 //BA.debugLineNum = 983049;BA.debugLine="txtmobile.Text = \"\"";
mostCurrent._txtmobile.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=983050;
 //BA.debugLineNum = 983050;BA.debugLine="d_mode = 0";
_d_mode = (int) (0);
RDebugUtils.currentLine=983051;
 //BA.debugLineNum = 983051;BA.debugLine="Label4.Visible = False";
mostCurrent._label4.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=983052;
 //BA.debugLineNum = 983052;BA.debugLine="txtmobile.Visible = False";
mostCurrent._txtmobile.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=983053;
 //BA.debugLineNum = 983053;BA.debugLine="cmdlogin.Text = \"Login\"";
mostCurrent._cmdlogin.setText(BA.ObjectToCharSequence("Login"));
RDebugUtils.currentLine=983054;
 //BA.debugLineNum = 983054;BA.debugLine="cmdcancel.Text = \"Cancel\"";
mostCurrent._cmdcancel.setText(BA.ObjectToCharSequence("Cancel"));
RDebugUtils.currentLine=983055;
 //BA.debugLineNum = 983055;BA.debugLine="cmdforgot.Visible = True";
mostCurrent._cmdforgot.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=983056;
 //BA.debugLineNum = 983056;BA.debugLine="cmdregister.Visible = True";
mostCurrent._cmdregister.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=983057;
 //BA.debugLineNum = 983057;BA.debugLine="Label2.Visible = True";
mostCurrent._label2.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=983058;
 //BA.debugLineNum = 983058;BA.debugLine="txtlogin.Visible = True";
mostCurrent._txtlogin.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=983059;
 //BA.debugLineNum = 983059;BA.debugLine="cmdlogin.Visible = True";
mostCurrent._cmdlogin.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=983060;
 //BA.debugLineNum = 983060;BA.debugLine="Label3.Visible = True";
mostCurrent._label3.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=983061;
 //BA.debugLineNum = 983061;BA.debugLine="txtpassword.Visible = True";
mostCurrent._txtpassword.setVisible(anywheresoftware.b4a.keywords.Common.True);
 };
RDebugUtils.currentLine=983063;
 //BA.debugLineNum = 983063;BA.debugLine="End Sub";
return "";
}
public static String  _cmdcancel_longclick() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "cmdcancel_longclick", false))
	 {return ((String) Debug.delegate(mostCurrent.activityBA, "cmdcancel_longclick", null));}
RDebugUtils.currentLine=1245184;
 //BA.debugLineNum = 1245184;BA.debugLine="Sub cmdcancel_LongClick";
RDebugUtils.currentLine=1245185;
 //BA.debugLineNum = 1245185;BA.debugLine="StartActivity(maps)";
anywheresoftware.b4a.keywords.Common.StartActivity(processBA,(Object)(mostCurrent._maps.getObject()));
RDebugUtils.currentLine=1245186;
 //BA.debugLineNum = 1245186;BA.debugLine="End Sub";
return "";
}
public static String  _cmdforgot_click() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "cmdforgot_click", false))
	 {return ((String) Debug.delegate(mostCurrent.activityBA, "cmdforgot_click", null));}
RDebugUtils.currentLine=1114112;
 //BA.debugLineNum = 1114112;BA.debugLine="Sub cmdforgot_Click";
RDebugUtils.currentLine=1114113;
 //BA.debugLineNum = 1114113;BA.debugLine="If txtlogin.Text = \"\"  Then";
if ((mostCurrent._txtlogin.getText()).equals("")) { 
RDebugUtils.currentLine=1114114;
 //BA.debugLineNum = 1114114;BA.debugLine="Msgbox(\"Enter Valid Username\",\"Alert!!!\")";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence("Enter Valid Username"),BA.ObjectToCharSequence("Alert!!!"),mostCurrent.activityBA);
 }else {
RDebugUtils.currentLine=1114117;
 //BA.debugLineNum = 1114117;BA.debugLine="LogTable1";
_logtable1();
RDebugUtils.currentLine=1114118;
 //BA.debugLineNum = 1114118;BA.debugLine="If d_use = 0 Then";
if (_d_use==0) { 
RDebugUtils.currentLine=1114119;
 //BA.debugLineNum = 1114119;BA.debugLine="If txtlogin.Text = d_login Then";
if ((mostCurrent._txtlogin.getText()).equals(_d_login)) { 
RDebugUtils.currentLine=1114120;
 //BA.debugLineNum = 1114120;BA.debugLine="ran_no = Rnd(1000,9999)";
_ran_no = anywheresoftware.b4a.keywords.Common.Rnd((int) (1000),(int) (9999));
RDebugUtils.currentLine=1114121;
 //BA.debugLineNum = 1114121;BA.debugLine="Log(ran_no)";
anywheresoftware.b4a.keywords.Common.LogImpl("71114121",BA.NumberToString(_ran_no),0);
RDebugUtils.currentLine=1114122;
 //BA.debugLineNum = 1114122;BA.debugLine="Sms1.Send(d_mobile,\"OTP: \" & ran_no)";
_sms1.Send(_d_mobile,"OTP: "+BA.NumberToString(_ran_no));
RDebugUtils.currentLine=1114123;
 //BA.debugLineNum = 1114123;BA.debugLine="ToastMessageShow(\"OTP sent.\",False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("OTP sent."),anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1114124;
 //BA.debugLineNum = 1114124;BA.debugLine="txtlogin.Text = \"\"";
mostCurrent._txtlogin.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=1114125;
 //BA.debugLineNum = 1114125;BA.debugLine="txtpassword.Text = \"\"";
mostCurrent._txtpassword.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=1114126;
 //BA.debugLineNum = 1114126;BA.debugLine="txtmobile.Text = \"\"";
mostCurrent._txtmobile.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=1114127;
 //BA.debugLineNum = 1114127;BA.debugLine="Label2.Visible = False";
mostCurrent._label2.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1114128;
 //BA.debugLineNum = 1114128;BA.debugLine="txtlogin.Visible = False";
mostCurrent._txtlogin.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1114129;
 //BA.debugLineNum = 1114129;BA.debugLine="Label3.Visible = False";
mostCurrent._label3.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1114130;
 //BA.debugLineNum = 1114130;BA.debugLine="txtpassword.Visible = False";
mostCurrent._txtpassword.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1114131;
 //BA.debugLineNum = 1114131;BA.debugLine="cmdregister.Visible = False";
mostCurrent._cmdregister.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1114132;
 //BA.debugLineNum = 1114132;BA.debugLine="cmdforgot.Visible = False";
mostCurrent._cmdforgot.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1114133;
 //BA.debugLineNum = 1114133;BA.debugLine="Label4.Visible = True";
mostCurrent._label4.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=1114134;
 //BA.debugLineNum = 1114134;BA.debugLine="txtmobile.Visible = True";
mostCurrent._txtmobile.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=1114135;
 //BA.debugLineNum = 1114135;BA.debugLine="Label4.Text = \"OTP:\"";
mostCurrent._label4.setText(BA.ObjectToCharSequence("OTP:"));
RDebugUtils.currentLine=1114136;
 //BA.debugLineNum = 1114136;BA.debugLine="ToastMessageShow(\"Enter OTP\",False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Enter OTP"),anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1114137;
 //BA.debugLineNum = 1114137;BA.debugLine="d_mode = 2";
_d_mode = (int) (2);
RDebugUtils.currentLine=1114138;
 //BA.debugLineNum = 1114138;BA.debugLine="cmdlogin.Text = \"Enter\"";
mostCurrent._cmdlogin.setText(BA.ObjectToCharSequence("Enter"));
 }else {
RDebugUtils.currentLine=1114140;
 //BA.debugLineNum = 1114140;BA.debugLine="Msgbox 	(\"Login ID is Incorrect\",\"Alert!\")";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence("Login ID is Incorrect"),BA.ObjectToCharSequence("Alert!"),mostCurrent.activityBA);
 };
 };
 };
RDebugUtils.currentLine=1114146;
 //BA.debugLineNum = 1114146;BA.debugLine="End Sub";
return "";
}
public static String  _logtable1() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "logtable1", false))
	 {return ((String) Debug.delegate(mostCurrent.activityBA, "logtable1", null));}
anywheresoftware.b4a.sql.SQL.CursorWrapper _cursor1 = null;
int _i = 0;
RDebugUtils.currentLine=720896;
 //BA.debugLineNum = 720896;BA.debugLine="Sub LogTable1";
RDebugUtils.currentLine=720897;
 //BA.debugLineNum = 720897;BA.debugLine="Dim Cursor1 As Cursor";
_cursor1 = new anywheresoftware.b4a.sql.SQL.CursorWrapper();
RDebugUtils.currentLine=720898;
 //BA.debugLineNum = 720898;BA.debugLine="Cursor1 = SQL1.ExecQuery(\"SELECT mob3 FROM table3";
_cursor1.setObject((android.database.Cursor)(_sql1.ExecQuery("SELECT mob3 FROM table3")));
RDebugUtils.currentLine=720899;
 //BA.debugLineNum = 720899;BA.debugLine="If Cursor1.RowCount > 0 Then";
if (_cursor1.getRowCount()>0) { 
RDebugUtils.currentLine=720900;
 //BA.debugLineNum = 720900;BA.debugLine="d_use = 0";
_d_use = (int) (0);
RDebugUtils.currentLine=720901;
 //BA.debugLineNum = 720901;BA.debugLine="For i = 0 To Cursor1.RowCount - 1";
{
final int step5 = 1;
final int limit5 = (int) (_cursor1.getRowCount()-1);
_i = (int) (0) ;
for (;_i <= limit5 ;_i = _i + step5 ) {
RDebugUtils.currentLine=720902;
 //BA.debugLineNum = 720902;BA.debugLine="Cursor1.Position = i";
_cursor1.setPosition(_i);
RDebugUtils.currentLine=720903;
 //BA.debugLineNum = 720903;BA.debugLine="Log(\"************************\")";
anywheresoftware.b4a.keywords.Common.LogImpl("7720903","************************",0);
RDebugUtils.currentLine=720904;
 //BA.debugLineNum = 720904;BA.debugLine="Log(Cursor1.GetString(\"mob3\"))";
anywheresoftware.b4a.keywords.Common.LogImpl("7720904",_cursor1.GetString("mob3"),0);
 }
};
RDebugUtils.currentLine=720908;
 //BA.debugLineNum = 720908;BA.debugLine="d_login = Cursor1.GetString(\"mob3\")";
_d_login = _cursor1.GetString("mob3");
RDebugUtils.currentLine=720909;
 //BA.debugLineNum = 720909;BA.debugLine="Cursor1.Close";
_cursor1.Close();
RDebugUtils.currentLine=720911;
 //BA.debugLineNum = 720911;BA.debugLine="Cursor1 = SQL1.ExecQuery(\"SELECT mob4 FROM table4";
_cursor1.setObject((android.database.Cursor)(_sql1.ExecQuery("SELECT mob4 FROM table4")));
RDebugUtils.currentLine=720912;
 //BA.debugLineNum = 720912;BA.debugLine="For i = 0 To Cursor1.RowCount - 1";
{
final int step13 = 1;
final int limit13 = (int) (_cursor1.getRowCount()-1);
_i = (int) (0) ;
for (;_i <= limit13 ;_i = _i + step13 ) {
RDebugUtils.currentLine=720913;
 //BA.debugLineNum = 720913;BA.debugLine="Cursor1.Position = i";
_cursor1.setPosition(_i);
RDebugUtils.currentLine=720914;
 //BA.debugLineNum = 720914;BA.debugLine="Log(\"************************\")";
anywheresoftware.b4a.keywords.Common.LogImpl("7720914","************************",0);
RDebugUtils.currentLine=720915;
 //BA.debugLineNum = 720915;BA.debugLine="Log(Cursor1.GetString(\"mob4\"))";
anywheresoftware.b4a.keywords.Common.LogImpl("7720915",_cursor1.GetString("mob4"),0);
 }
};
RDebugUtils.currentLine=720919;
 //BA.debugLineNum = 720919;BA.debugLine="d_pass = Cursor1.GetString(\"mob4\")";
_d_pass = _cursor1.GetString("mob4");
RDebugUtils.currentLine=720920;
 //BA.debugLineNum = 720920;BA.debugLine="Cursor1.Close";
_cursor1.Close();
RDebugUtils.currentLine=720922;
 //BA.debugLineNum = 720922;BA.debugLine="Cursor1 = SQL1.ExecQuery(\"SELECT mob5 FROM table5";
_cursor1.setObject((android.database.Cursor)(_sql1.ExecQuery("SELECT mob5 FROM table5")));
RDebugUtils.currentLine=720923;
 //BA.debugLineNum = 720923;BA.debugLine="For i = 0 To Cursor1.RowCount - 1";
{
final int step21 = 1;
final int limit21 = (int) (_cursor1.getRowCount()-1);
_i = (int) (0) ;
for (;_i <= limit21 ;_i = _i + step21 ) {
RDebugUtils.currentLine=720924;
 //BA.debugLineNum = 720924;BA.debugLine="Cursor1.Position = i";
_cursor1.setPosition(_i);
RDebugUtils.currentLine=720925;
 //BA.debugLineNum = 720925;BA.debugLine="Log(\"************************\")";
anywheresoftware.b4a.keywords.Common.LogImpl("7720925","************************",0);
RDebugUtils.currentLine=720926;
 //BA.debugLineNum = 720926;BA.debugLine="Log(Cursor1.GetString(\"mob5\"))";
anywheresoftware.b4a.keywords.Common.LogImpl("7720926",_cursor1.GetString("mob5"),0);
 }
};
RDebugUtils.currentLine=720930;
 //BA.debugLineNum = 720930;BA.debugLine="d_mobile = Cursor1.GetString(\"mob5\")";
_d_mobile = _cursor1.GetString("mob5");
RDebugUtils.currentLine=720931;
 //BA.debugLineNum = 720931;BA.debugLine="Cursor1.Close";
_cursor1.Close();
 }else {
RDebugUtils.currentLine=720933;
 //BA.debugLineNum = 720933;BA.debugLine="d_use = 1";
_d_use = (int) (1);
RDebugUtils.currentLine=720934;
 //BA.debugLineNum = 720934;BA.debugLine="Msgbox(\"No Entries of User found\",\"Alert!!!\")";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence("No Entries of User found"),BA.ObjectToCharSequence("Alert!!!"),mostCurrent.activityBA);
 };
RDebugUtils.currentLine=720936;
 //BA.debugLineNum = 720936;BA.debugLine="End Sub";
return "";
}
public static String  _cmdlogin_click() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "cmdlogin_click", false))
	 {return ((String) Debug.delegate(mostCurrent.activityBA, "cmdlogin_click", null));}
RDebugUtils.currentLine=917504;
 //BA.debugLineNum = 917504;BA.debugLine="Sub cmdlogin_Click";
RDebugUtils.currentLine=917505;
 //BA.debugLineNum = 917505;BA.debugLine="If d_mode = 0 Then";
if (_d_mode==0) { 
RDebugUtils.currentLine=917506;
 //BA.debugLineNum = 917506;BA.debugLine="LogTable1";
_logtable1();
RDebugUtils.currentLine=917507;
 //BA.debugLineNum = 917507;BA.debugLine="Log (\"Login:\")";
anywheresoftware.b4a.keywords.Common.LogImpl("7917507","Login:",0);
RDebugUtils.currentLine=917508;
 //BA.debugLineNum = 917508;BA.debugLine="Log (d_login)";
anywheresoftware.b4a.keywords.Common.LogImpl("7917508",_d_login,0);
RDebugUtils.currentLine=917509;
 //BA.debugLineNum = 917509;BA.debugLine="Log (\"Password:\")";
anywheresoftware.b4a.keywords.Common.LogImpl("7917509","Password:",0);
RDebugUtils.currentLine=917510;
 //BA.debugLineNum = 917510;BA.debugLine="Log (d_pass)";
anywheresoftware.b4a.keywords.Common.LogImpl("7917510",_d_pass,0);
RDebugUtils.currentLine=917511;
 //BA.debugLineNum = 917511;BA.debugLine="Log (\"Mobile:\")";
anywheresoftware.b4a.keywords.Common.LogImpl("7917511","Mobile:",0);
RDebugUtils.currentLine=917512;
 //BA.debugLineNum = 917512;BA.debugLine="Log (d_mobile)";
anywheresoftware.b4a.keywords.Common.LogImpl("7917512",_d_mobile,0);
RDebugUtils.currentLine=917513;
 //BA.debugLineNum = 917513;BA.debugLine="If d_use = 0 Then";
if (_d_use==0) { 
RDebugUtils.currentLine=917514;
 //BA.debugLineNum = 917514;BA.debugLine="If txtlogin.Text = d_login Then";
if ((mostCurrent._txtlogin.getText()).equals(_d_login)) { 
RDebugUtils.currentLine=917515;
 //BA.debugLineNum = 917515;BA.debugLine="If txtpassword.Text = d_pass Then";
if ((mostCurrent._txtpassword.getText()).equals(_d_pass)) { 
RDebugUtils.currentLine=917516;
 //BA.debugLineNum = 917516;BA.debugLine="maps.u_name = d_login";
mostCurrent._maps._u_name /*String*/  = _d_login;
RDebugUtils.currentLine=917517;
 //BA.debugLineNum = 917517;BA.debugLine="StartActivity(maps)";
anywheresoftware.b4a.keywords.Common.StartActivity(processBA,(Object)(mostCurrent._maps.getObject()));
 }else {
RDebugUtils.currentLine=917519;
 //BA.debugLineNum = 917519;BA.debugLine="Msgbox 	(\"Password Incorrect\",\"Alert!\")";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence("Password Incorrect"),BA.ObjectToCharSequence("Alert!"),mostCurrent.activityBA);
 };
 }else {
RDebugUtils.currentLine=917522;
 //BA.debugLineNum = 917522;BA.debugLine="Msgbox 	(\"Login ID is Incorrect\",\"Alert!\")";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence("Login ID is Incorrect"),BA.ObjectToCharSequence("Alert!"),mostCurrent.activityBA);
 };
 };
 }else 
{RDebugUtils.currentLine=917525;
 //BA.debugLineNum = 917525;BA.debugLine="Else If d_mode = 1 Then";
if (_d_mode==1) { 
RDebugUtils.currentLine=917526;
 //BA.debugLineNum = 917526;BA.debugLine="If txtlogin.Text = \"\" Or txtpassword.Text = \"\" O";
if ((mostCurrent._txtlogin.getText()).equals("") || (mostCurrent._txtpassword.getText()).equals("") || (mostCurrent._txtmobile.getText()).equals("")) { 
RDebugUtils.currentLine=917527;
 //BA.debugLineNum = 917527;BA.debugLine="Msgbox(\"Enter Proper Details\",\"Alert!!!\")";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence("Enter Proper Details"),BA.ObjectToCharSequence("Alert!!!"),mostCurrent.activityBA);
 }else {
RDebugUtils.currentLine=917529;
 //BA.debugLineNum = 917529;BA.debugLine="SQL1.ExecNonQuery(\"INSERT INTO table3 VALUES('\"";
_sql1.ExecNonQuery("INSERT INTO table3 VALUES('"+mostCurrent._txtlogin.getText()+"')");
RDebugUtils.currentLine=917530;
 //BA.debugLineNum = 917530;BA.debugLine="SQL1.ExecNonQuery(\"INSERT INTO table4 VALUES('\"";
_sql1.ExecNonQuery("INSERT INTO table4 VALUES('"+mostCurrent._txtpassword.getText()+"')");
RDebugUtils.currentLine=917531;
 //BA.debugLineNum = 917531;BA.debugLine="SQL1.ExecNonQuery(\"INSERT INTO table5 VALUES('\"";
_sql1.ExecNonQuery("INSERT INTO table5 VALUES('"+mostCurrent._txtmobile.getText()+"')");
RDebugUtils.currentLine=917532;
 //BA.debugLineNum = 917532;BA.debugLine="ToastMessageShow(\"Registration Completed.\",Fals";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Registration Completed."),anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=917533;
 //BA.debugLineNum = 917533;BA.debugLine="d_mode = 0";
_d_mode = (int) (0);
RDebugUtils.currentLine=917534;
 //BA.debugLineNum = 917534;BA.debugLine="Label4.Visible = False";
mostCurrent._label4.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=917535;
 //BA.debugLineNum = 917535;BA.debugLine="txtmobile.Visible = False";
mostCurrent._txtmobile.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=917536;
 //BA.debugLineNum = 917536;BA.debugLine="cmdlogin.Text = \"Login\"";
mostCurrent._cmdlogin.setText(BA.ObjectToCharSequence("Login"));
RDebugUtils.currentLine=917537;
 //BA.debugLineNum = 917537;BA.debugLine="cmdcancel.Text = \"Cancel\"";
mostCurrent._cmdcancel.setText(BA.ObjectToCharSequence("Cancel"));
RDebugUtils.currentLine=917538;
 //BA.debugLineNum = 917538;BA.debugLine="cmdforgot.Visible = True";
mostCurrent._cmdforgot.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=917539;
 //BA.debugLineNum = 917539;BA.debugLine="cmdregister.Visible = True";
mostCurrent._cmdregister.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=917540;
 //BA.debugLineNum = 917540;BA.debugLine="txtlogin.Text = \"\"";
mostCurrent._txtlogin.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=917541;
 //BA.debugLineNum = 917541;BA.debugLine="txtpassword.Text = \"\"";
mostCurrent._txtpassword.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=917542;
 //BA.debugLineNum = 917542;BA.debugLine="txtmobile.Text = \"\"";
mostCurrent._txtmobile.setText(BA.ObjectToCharSequence(""));
 };
 }else 
{RDebugUtils.currentLine=917544;
 //BA.debugLineNum = 917544;BA.debugLine="Else If d_mode = 2 Then";
if (_d_mode==2) { 
RDebugUtils.currentLine=917545;
 //BA.debugLineNum = 917545;BA.debugLine="If txtmobile.Text = ran_no Then";
if ((mostCurrent._txtmobile.getText()).equals(BA.NumberToString(_ran_no))) { 
RDebugUtils.currentLine=917546;
 //BA.debugLineNum = 917546;BA.debugLine="d_mode = 3";
_d_mode = (int) (3);
RDebugUtils.currentLine=917547;
 //BA.debugLineNum = 917547;BA.debugLine="txtlogin.Text = \"\"";
mostCurrent._txtlogin.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=917548;
 //BA.debugLineNum = 917548;BA.debugLine="txtpassword.Text = \"\"";
mostCurrent._txtpassword.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=917549;
 //BA.debugLineNum = 917549;BA.debugLine="txtmobile.Text = \"\"";
mostCurrent._txtmobile.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=917550;
 //BA.debugLineNum = 917550;BA.debugLine="Label2.Visible = False";
mostCurrent._label2.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=917551;
 //BA.debugLineNum = 917551;BA.debugLine="txtlogin.Visible = False";
mostCurrent._txtlogin.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=917552;
 //BA.debugLineNum = 917552;BA.debugLine="Label3.Visible = True";
mostCurrent._label3.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=917553;
 //BA.debugLineNum = 917553;BA.debugLine="txtpassword.Visible = True";
mostCurrent._txtpassword.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=917554;
 //BA.debugLineNum = 917554;BA.debugLine="Label4.Visible = False";
mostCurrent._label4.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=917555;
 //BA.debugLineNum = 917555;BA.debugLine="txtmobile.Visible = False";
mostCurrent._txtmobile.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=917556;
 //BA.debugLineNum = 917556;BA.debugLine="cmdlogin.Text = \"Update\"";
mostCurrent._cmdlogin.setText(BA.ObjectToCharSequence("Update"));
RDebugUtils.currentLine=917557;
 //BA.debugLineNum = 917557;BA.debugLine="cmdcancel.Text = \"Cancel\"";
mostCurrent._cmdcancel.setText(BA.ObjectToCharSequence("Cancel"));
RDebugUtils.currentLine=917558;
 //BA.debugLineNum = 917558;BA.debugLine="cmdforgot.Visible = False";
mostCurrent._cmdforgot.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=917559;
 //BA.debugLineNum = 917559;BA.debugLine="cmdregister.Visible = False";
mostCurrent._cmdregister.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=917560;
 //BA.debugLineNum = 917560;BA.debugLine="ToastMessageShow(\"Enter New Password\",False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Enter New Password"),anywheresoftware.b4a.keywords.Common.False);
 }else {
RDebugUtils.currentLine=917562;
 //BA.debugLineNum = 917562;BA.debugLine="Msgbox(\"INVALID OTP\",\"Alert!!!\")";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence("INVALID OTP"),BA.ObjectToCharSequence("Alert!!!"),mostCurrent.activityBA);
 };
 }else 
{RDebugUtils.currentLine=917564;
 //BA.debugLineNum = 917564;BA.debugLine="Else If d_mode = 3 Then";
if (_d_mode==3) { 
RDebugUtils.currentLine=917565;
 //BA.debugLineNum = 917565;BA.debugLine="SQL1.ExecNonQuery(\"INSERT INTO table4 VALUES('\"";
_sql1.ExecNonQuery("INSERT INTO table4 VALUES('"+mostCurrent._txtpassword.getText()+"')");
RDebugUtils.currentLine=917566;
 //BA.debugLineNum = 917566;BA.debugLine="ToastMessageShow(\"Password Updated.\",True)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence("Password Updated."),anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=917567;
 //BA.debugLineNum = 917567;BA.debugLine="txtlogin.Text = \"\"";
mostCurrent._txtlogin.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=917568;
 //BA.debugLineNum = 917568;BA.debugLine="txtpassword.Text = \"\"";
mostCurrent._txtpassword.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=917569;
 //BA.debugLineNum = 917569;BA.debugLine="txtmobile.Text = \"\"";
mostCurrent._txtmobile.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=917570;
 //BA.debugLineNum = 917570;BA.debugLine="d_mode = 0";
_d_mode = (int) (0);
RDebugUtils.currentLine=917571;
 //BA.debugLineNum = 917571;BA.debugLine="Label4.Visible = False";
mostCurrent._label4.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=917572;
 //BA.debugLineNum = 917572;BA.debugLine="txtmobile.Visible = False";
mostCurrent._txtmobile.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=917573;
 //BA.debugLineNum = 917573;BA.debugLine="cmdlogin.Text = \"Login\"";
mostCurrent._cmdlogin.setText(BA.ObjectToCharSequence("Login"));
RDebugUtils.currentLine=917574;
 //BA.debugLineNum = 917574;BA.debugLine="cmdcancel.Text = \"Cancel\"";
mostCurrent._cmdcancel.setText(BA.ObjectToCharSequence("Cancel"));
RDebugUtils.currentLine=917575;
 //BA.debugLineNum = 917575;BA.debugLine="cmdforgot.Visible = True";
mostCurrent._cmdforgot.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=917576;
 //BA.debugLineNum = 917576;BA.debugLine="cmdregister.Visible = True";
mostCurrent._cmdregister.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=917577;
 //BA.debugLineNum = 917577;BA.debugLine="Label2.Visible = True";
mostCurrent._label2.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=917578;
 //BA.debugLineNum = 917578;BA.debugLine="cmdlogin.Visible = True";
mostCurrent._cmdlogin.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=917579;
 //BA.debugLineNum = 917579;BA.debugLine="Label3.Visible = True";
mostCurrent._label3.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=917580;
 //BA.debugLineNum = 917580;BA.debugLine="txtpassword.Visible = True";
mostCurrent._txtpassword.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=917581;
 //BA.debugLineNum = 917581;BA.debugLine="txtlogin.Visible = True";
mostCurrent._txtlogin.setVisible(anywheresoftware.b4a.keywords.Common.True);
 }}}}
;
RDebugUtils.currentLine=917584;
 //BA.debugLineNum = 917584;BA.debugLine="End Sub";
return "";
}
public static String  _cmdregister_click() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "cmdregister_click", false))
	 {return ((String) Debug.delegate(mostCurrent.activityBA, "cmdregister_click", null));}
RDebugUtils.currentLine=1179648;
 //BA.debugLineNum = 1179648;BA.debugLine="Sub cmdregister_Click";
RDebugUtils.currentLine=1179649;
 //BA.debugLineNum = 1179649;BA.debugLine="If d_mode = 0 Then";
if (_d_mode==0) { 
RDebugUtils.currentLine=1179650;
 //BA.debugLineNum = 1179650;BA.debugLine="txtlogin.Text = \"\"";
mostCurrent._txtlogin.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=1179651;
 //BA.debugLineNum = 1179651;BA.debugLine="txtpassword.Text = \"\"";
mostCurrent._txtpassword.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=1179652;
 //BA.debugLineNum = 1179652;BA.debugLine="txtmobile.Text = \"\"";
mostCurrent._txtmobile.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=1179653;
 //BA.debugLineNum = 1179653;BA.debugLine="d_mode = 1";
_d_mode = (int) (1);
RDebugUtils.currentLine=1179654;
 //BA.debugLineNum = 1179654;BA.debugLine="Label4.Visible = True";
mostCurrent._label4.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=1179655;
 //BA.debugLineNum = 1179655;BA.debugLine="Label4.Text = \"Mobile:\"";
mostCurrent._label4.setText(BA.ObjectToCharSequence("Mobile:"));
RDebugUtils.currentLine=1179656;
 //BA.debugLineNum = 1179656;BA.debugLine="txtmobile.Visible = True";
mostCurrent._txtmobile.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=1179657;
 //BA.debugLineNum = 1179657;BA.debugLine="cmdlogin.Text = \"Register\"";
mostCurrent._cmdlogin.setText(BA.ObjectToCharSequence("Register"));
RDebugUtils.currentLine=1179658;
 //BA.debugLineNum = 1179658;BA.debugLine="cmdcancel.Text = \"Back\"";
mostCurrent._cmdcancel.setText(BA.ObjectToCharSequence("Back"));
RDebugUtils.currentLine=1179659;
 //BA.debugLineNum = 1179659;BA.debugLine="cmdforgot.Visible = False";
mostCurrent._cmdforgot.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1179660;
 //BA.debugLineNum = 1179660;BA.debugLine="cmdregister.Visible = False";
mostCurrent._cmdregister.setVisible(anywheresoftware.b4a.keywords.Common.False);
 }else {
RDebugUtils.currentLine=1179662;
 //BA.debugLineNum = 1179662;BA.debugLine="d_mode = 0";
_d_mode = (int) (0);
RDebugUtils.currentLine=1179663;
 //BA.debugLineNum = 1179663;BA.debugLine="txtlogin.Text = \"\"";
mostCurrent._txtlogin.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=1179664;
 //BA.debugLineNum = 1179664;BA.debugLine="txtpassword.Text = \"\"";
mostCurrent._txtpassword.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=1179665;
 //BA.debugLineNum = 1179665;BA.debugLine="txtmobile.Text = \"\"";
mostCurrent._txtmobile.setText(BA.ObjectToCharSequence(""));
RDebugUtils.currentLine=1179666;
 //BA.debugLineNum = 1179666;BA.debugLine="Label4.Visible = False";
mostCurrent._label4.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1179667;
 //BA.debugLineNum = 1179667;BA.debugLine="txtmobile.Visible = False";
mostCurrent._txtmobile.setVisible(anywheresoftware.b4a.keywords.Common.False);
RDebugUtils.currentLine=1179668;
 //BA.debugLineNum = 1179668;BA.debugLine="cmdlogin.Text = \"Login\"";
mostCurrent._cmdlogin.setText(BA.ObjectToCharSequence("Login"));
RDebugUtils.currentLine=1179669;
 //BA.debugLineNum = 1179669;BA.debugLine="cmdcancel.Text = \"Cancel\"";
mostCurrent._cmdcancel.setText(BA.ObjectToCharSequence("Cancel"));
RDebugUtils.currentLine=1179670;
 //BA.debugLineNum = 1179670;BA.debugLine="cmdforgot.Visible = True";
mostCurrent._cmdforgot.setVisible(anywheresoftware.b4a.keywords.Common.True);
RDebugUtils.currentLine=1179671;
 //BA.debugLineNum = 1179671;BA.debugLine="cmdregister.Visible = True";
mostCurrent._cmdregister.setVisible(anywheresoftware.b4a.keywords.Common.True);
 };
RDebugUtils.currentLine=1179673;
 //BA.debugLineNum = 1179673;BA.debugLine="End Sub";
return "";
}
public static String  _delay(long _nmillisecond) throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "delay", false))
	 {return ((String) Debug.delegate(mostCurrent.activityBA, "delay", new Object[] {_nmillisecond}));}
long _nbegintime = 0L;
long _nendtime = 0L;
RDebugUtils.currentLine=1048576;
 //BA.debugLineNum = 1048576;BA.debugLine="Sub Delay(nMilliSecond As Long)";
RDebugUtils.currentLine=1048577;
 //BA.debugLineNum = 1048577;BA.debugLine="Dim nBeginTime As Long";
_nbegintime = 0L;
RDebugUtils.currentLine=1048578;
 //BA.debugLineNum = 1048578;BA.debugLine="Dim nEndTime As Long";
_nendtime = 0L;
RDebugUtils.currentLine=1048579;
 //BA.debugLineNum = 1048579;BA.debugLine="nEndTime = DateTime.Now + nMilliSecond";
_nendtime = (long) (anywheresoftware.b4a.keywords.Common.DateTime.getNow()+_nmillisecond);
RDebugUtils.currentLine=1048580;
 //BA.debugLineNum = 1048580;BA.debugLine="nBeginTime = DateTime.Now";
_nbegintime = anywheresoftware.b4a.keywords.Common.DateTime.getNow();
RDebugUtils.currentLine=1048581;
 //BA.debugLineNum = 1048581;BA.debugLine="Do While nBeginTime < nEndTime";
while (_nbegintime<_nendtime) {
RDebugUtils.currentLine=1048582;
 //BA.debugLineNum = 1048582;BA.debugLine="nBeginTime = DateTime.Now";
_nbegintime = anywheresoftware.b4a.keywords.Common.DateTime.getNow();
RDebugUtils.currentLine=1048583;
 //BA.debugLineNum = 1048583;BA.debugLine="Log(nBeginTime)";
anywheresoftware.b4a.keywords.Common.LogImpl("71048583",BA.NumberToString(_nbegintime),0);
RDebugUtils.currentLine=1048584;
 //BA.debugLineNum = 1048584;BA.debugLine="If nEndTime < nBeginTime Then";
if (_nendtime<_nbegintime) { 
RDebugUtils.currentLine=1048585;
 //BA.debugLineNum = 1048585;BA.debugLine="Return";
if (true) return "";
 };
RDebugUtils.currentLine=1048587;
 //BA.debugLineNum = 1048587;BA.debugLine="DoEvents";
anywheresoftware.b4a.keywords.Common.DoEvents();
 }
;
RDebugUtils.currentLine=1048589;
 //BA.debugLineNum = 1048589;BA.debugLine="End Sub";
return "";
}
public static String  _logtable2() throws Exception{
RDebugUtils.currentModule="main";
if (Debug.shouldDelegate(mostCurrent.activityBA, "logtable2", false))
	 {return ((String) Debug.delegate(mostCurrent.activityBA, "logtable2", null));}
anywheresoftware.b4a.sql.SQL.CursorWrapper _cursor1 = null;
int _i = 0;
RDebugUtils.currentLine=786432;
 //BA.debugLineNum = 786432;BA.debugLine="Sub LogTable2";
RDebugUtils.currentLine=786433;
 //BA.debugLineNum = 786433;BA.debugLine="Dim Cursor1 As Cursor";
_cursor1 = new anywheresoftware.b4a.sql.SQL.CursorWrapper();
RDebugUtils.currentLine=786434;
 //BA.debugLineNum = 786434;BA.debugLine="Cursor1 = SQL1.ExecQuery(\"SELECT mob2 FROM table2";
_cursor1.setObject((android.database.Cursor)(_sql1.ExecQuery("SELECT mob2 FROM table2")));
RDebugUtils.currentLine=786435;
 //BA.debugLineNum = 786435;BA.debugLine="For i = 0 To Cursor1.RowCount - 1";
{
final int step3 = 1;
final int limit3 = (int) (_cursor1.getRowCount()-1);
_i = (int) (0) ;
for (;_i <= limit3 ;_i = _i + step3 ) {
RDebugUtils.currentLine=786436;
 //BA.debugLineNum = 786436;BA.debugLine="Cursor1.Position = i";
_cursor1.setPosition(_i);
RDebugUtils.currentLine=786437;
 //BA.debugLineNum = 786437;BA.debugLine="Log(\"************************\")";
anywheresoftware.b4a.keywords.Common.LogImpl("7786437","************************",0);
RDebugUtils.currentLine=786438;
 //BA.debugLineNum = 786438;BA.debugLine="Log(Cursor1.GetString(\"mob2\"))";
anywheresoftware.b4a.keywords.Common.LogImpl("7786438",_cursor1.GetString("mob2"),0);
 }
};
RDebugUtils.currentLine=786443;
 //BA.debugLineNum = 786443;BA.debugLine="Cursor1.Close";
_cursor1.Close();
RDebugUtils.currentLine=786444;
 //BA.debugLineNum = 786444;BA.debugLine="End Sub";
return "";
}
}